// محاكاة الاقتصاد: شحال من طاقة كتخصص باش تكمل الغرف
const E = require('../www/js/engine.js');
const S = E.newState(0); S.energy = 1e9;
const rand = E.rng(7);
let taps = 0, stuck = 0;
const log = [];
for(let step = 0; step < 200000 && E.currentRoom(S) < 3; step++){
  // خدم الطلبات الجاهزين
  for(let k = 0; k < 3; k++) if(E.findForOrder(S, S.orders[k])) E.serve(S, k);
  while(E.nextTask(S) && S.stars >= E.nextTask(S).cost){ const r = E.doTask(S); log.push([S.done.length, taps, S.served]); }
  E.placePending(S);
  // دمج: أي زوج متشابه ماشي مطلوب كما هو
  const need = new Set(S.orders.flatMap(o => o.req));
  let merged = false;
  for(let a = 0; a < E.CELLS && !merged; a++){ const it = S.board[a]; if(!it || E.isGen(it) || E.tierOf(it) >= 6) continue;
    if(need.has(it) && S.board.filter(x => x === it).length <= 2) { /* خليه */ }
    for(let b = a + 1; b < E.CELLS; b++) if(S.board[b] === it){ E.move(S, a, b); merged = true; break; } }
  if(merged) continue;
  // ولد من سلسلة مطلوبة
  const chains = S.orders.flatMap(o => o.req.map(E.chainOf));
  const c = chains[Math.floor(rand() * chains.length)];
  const g = S.board.indexOf('G' + c);
  const res = E.tapGen(S, g, rand, 0);
  if(res.ok) taps++;
  else { // البورد عامر: بيع أصغر حاجة
    let mi = -1, mt = 9; S.board.forEach((x, i) => { if(x && !E.isGen(x) && E.tierOf(x) < mt){ mt = E.tierOf(x); mi = i; } }); E.sell(S, mi); stuck++; }
}
console.log('taps', taps, 'served', S.served, 'sold', stuck, 'coins', S.coins);
for(const [d, t, s] of log) if([1,4,8,12,16,20,24].includes(d)) console.log('task', d, 'energy', t, 'orders', s, '~hours@regen', (t/30).toFixed(1));
