package com.devfoxmy.desertdash;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
