package com.devfoxmy.twistout;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
