package com.devfoxmy.idlechef;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
