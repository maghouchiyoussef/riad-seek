package com.devfoxmy.memorymatch;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
