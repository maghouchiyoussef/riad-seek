package com.devfoxmy.million;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
