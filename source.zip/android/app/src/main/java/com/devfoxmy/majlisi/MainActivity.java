package com.devfoxmy.majlisi;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
