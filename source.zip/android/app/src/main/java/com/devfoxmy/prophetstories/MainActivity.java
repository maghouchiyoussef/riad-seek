package com.devfoxmy.prophetstories;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
