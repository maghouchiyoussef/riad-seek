package com.devfoxmy.bubblebloom;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
