package com.devfoxmy.sweetpop;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
