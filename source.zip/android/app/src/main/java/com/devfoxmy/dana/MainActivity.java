package com.devfoxmy.dana;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
