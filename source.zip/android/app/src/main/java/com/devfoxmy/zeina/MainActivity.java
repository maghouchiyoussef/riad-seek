package com.devfoxmy.zeina;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
