package com.devfoxmy.kalimat;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
