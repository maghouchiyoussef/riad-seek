package com.devfoxmy.sadu;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
