package com.devfoxmy.riadseek;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
