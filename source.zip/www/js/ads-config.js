// إعدادات AdMob ديال «دانة» (IDs حقيقية). لا تضغط على إعلاناتك أبدا.
window.ADS_CONFIG = {
  TEST_MODE: false,
  BANNER_ID: 'ca-app-pub-2986107222837015/9680886149',
  INTERSTITIAL_ID: 'ca-app-pub-2986107222837015/9433474132',
  REWARDED_ID: 'ca-app-pub-2986107222837015/8120392468',
  INTERSTITIAL_EVERY_N_ROUNDS: 3,
};
