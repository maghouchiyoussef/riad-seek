// إعدادات AdMob ديال «مجلسي». ⚠️ مؤقتاً IDs ديال الاختبار — غادي يتبدلو بالـIDs الحقيقية قبل النشر.
window.ADS_CONFIG = {
  TEST_MODE: false,
  BANNER_ID: 'ca-app-pub-2986107222837015/1748081888',
  INTERSTITIAL_ID: 'ca-app-pub-2986107222837015/3144924032',
  REWARDED_ID: 'ca-app-pub-2986107222837015/6808836872',
  INTERSTITIAL_EVERY_N_ROUNDS: 3,
};
