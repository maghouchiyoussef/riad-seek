// إعدادات AdMob ديال Riad Seek (IDs حقيقية). لا تضغط على إعلاناتك أبدا.
window.ADS_CONFIG = {
  TEST_MODE: false,
  BANNER_ID: 'ca-app-pub-2986107222837015/6732907143',
  INTERSTITIAL_ID: 'ca-app-pub-2986107222837015/9814366059',
  REWARDED_ID: 'ca-app-pub-2986107222837015/7990148494',
  INTERSTITIAL_EVERY_N_ROUNDS: 2,
};
