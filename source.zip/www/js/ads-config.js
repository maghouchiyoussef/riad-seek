// إعدادات AdMob ديال «زينة». ⚠️ مؤقتاً IDs ديال الاختبار — غادي يتبدلو بالـIDs الحقيقية قبل النشر.
window.ADS_CONFIG = {
  TEST_MODE: false,
  BANNER_ID: 'ca-app-pub-2986107222837015/8559058933',
  INTERSTITIAL_ID: 'ca-app-pub-2986107222837015/9797038852',
  REWARDED_ID: 'ca-app-pub-2986107222837015/3670614209',
  INTERSTITIAL_EVERY_N_ROUNDS: 3,
};
