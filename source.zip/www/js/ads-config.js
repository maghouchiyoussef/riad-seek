// إعدادات AdMob ديال «حروف وكلمات» (IDs حقيقية). لا تضغط على إعلاناتك أبدا.
window.ADS_CONFIG = {
  TEST_MODE: false,
  BANNER_ID: 'ca-app-pub-2986107222837015/4929599838',
  INTERSTITIAL_ID: 'ca-app-pub-2986107222837015/9359799433',
  REWARDED_ID: 'ca-app-pub-2986107222837015/1551346190',
  INTERSTITIAL_EVERY_N_ROUNDS: 3,
};
