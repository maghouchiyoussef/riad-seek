// إعدادات AdMob ديال «تحدي المليون» (IDs حقيقية). لا تضغط على إعلاناتك أبدا.
window.ADS_CONFIG = {
  TEST_MODE: false,
  BANNER_ID: 'ca-app-pub-2986107222837015/7210866983',
  INTERSTITIAL_ID: 'ca-app-pub-2986107222837015/9798783130',
  REWARDED_ID: 'ca-app-pub-2986107222837015/1355160215',
  INTERSTITIAL_EVERY_N_ROUNDS: 2,
};
