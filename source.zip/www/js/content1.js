// Content part 1. Each text is [English, Arabic].
window.CH = window.CH || [];
CH.push(
{ id:'adam', icon:'🌱', c1:'#2e7d4f', c2:'#145a32', name:['Adam','آدم'],
  story:[
   ['Allah created Adam from clay and breathed a soul into him. He taught Adam the names of all things.','خلق الله آدم من طين ونفخ فيه من روحه، وعلّمه أسماء الأشياء كلها.'],
   ['Allah told the angels to bow to Adam. All of them obeyed, except Iblis, who refused out of pride.','أمر الله الملائكة بالسجود لآدم، فسجدوا كلهم إلا إبليس أبى واستكبر.'],
   ['Adam and his wife lived in Paradise. They could enjoy everything there, but were told not to go near one tree.','سكن آدم وزوجه الجنة وأكلا منها حيث شاءا، ونُهيا عن الاقتراب من شجرة واحدة.'],
   ['Satan whispered to them and they forgot the command. Adam felt sorry, asked for forgiveness, and Allah forgave him.','وسوس لهما الشيطان فنسيا الأمر، فندم آدم وتاب، فتاب الله عليه.']],
  qs:[
   {q:['What was Adam created from?','مم خُلق آدم؟'],o:[['Clay','طين'],['Fire','نار'],['Light','نور'],['Water only','ماء فقط']],c:0},
   {q:['Who refused to bow to Adam?','من الذي رفض السجود لآدم؟'],o:[['Iblis','إبليس'],['Jibril','جبريل'],['Mikail','ميكائيل'],['Harut','هاروت']],c:0},
   {q:['What was Adam told not to do?','عن ماذا نُهي آدم؟'],o:[['Go near one tree','الاقتراب من شجرة'],['Leave Paradise','الخروج من الجنة'],['Speak to the angels','الكلام مع الملائكة'],['Eat any fruit','أكل أي ثمرة']],c:0},
   {q:['What did Adam do after his mistake?','ماذا فعل آدم بعد خطئه؟'],o:[['Asked Allah for forgiveness','طلب المغفرة من الله'],['Blamed others','لام غيره'],['Hid away','اختبأ'],['Ignored it','تجاهله']],c:0},
   {q:['What did Allah teach Adam?','ماذا علّم الله آدم؟'],o:[['The names of all things','أسماء الأشياء كلها'],['How to build ships','بناء السفن'],['How to fly','الطيران'],['Only numbers','الأرقام فقط']],c:0}]},

{ id:'nuh', icon:'🚢', c1:'#2b6cb0', c2:'#153e75', name:['Nuh (Noah)','نوح'],
  story:[
   ['Nuh called his people to worship Allah alone. He stayed among them for 950 years, inviting them with patience.','دعا نوح قومه إلى عبادة الله وحده، ولبث فيهم ألف سنة إلا خمسين عامًا يدعوهم بصبر.'],
   ['Only a few people believed. Most of them laughed at him and refused to listen.','لم يؤمن معه إلا قليل، وسخر منه أكثر قومه وأعرضوا عنه.'],
   ['Allah told Nuh to build an ark. He took the believers and a pair of every kind of animal on board.','أمر الله نوحًا ببناء السفينة، فحمل فيها المؤمنين وزوجين من كل نوع من الحيوان.'],
   ['The great flood came. The ark floated safely and finally rested on Mount Judi.','جاء الطوفان العظيم، فجرت السفينة بأمان ثم استقرت على جبل الجودي.']],
  qs:[
   {q:['How long did Nuh call his people?','كم مدة دعوة نوح لقومه؟'],o:[['950 years','950 سنة'],['10 years','10 سنوات'],['100 years','100 سنة'],['40 years','40 سنة']],c:0},
   {q:['What did Allah tell Nuh to build?','ماذا أمر الله نوحًا أن يبني؟'],o:[['An ark','سفينة'],['A tower','برجًا'],['A bridge','جسرًا'],['A wall','سدًّا']],c:0},
   {q:['Who went on the ark?','من ركب السفينة؟'],o:[['Believers and pairs of animals','المؤمنون وأزواج الحيوانات'],['Only Nuh','نوح وحده'],['All the people','كل الناس'],['Only animals','الحيوانات فقط']],c:0},
   {q:['Where did the ark come to rest?','أين استقرت السفينة؟'],o:[['Mount Judi','جبل الجودي'],['Mount Uhud','جبل أحد'],['Mount Sinai','جبل سيناء'],['Mount Arafat','جبل عرفات']],c:0},
   {q:['How did most of his people treat him?','كيف عامله أكثر قومه؟'],o:[['They mocked him','سخروا منه'],['They obeyed him','أطاعوه'],['They helped him','ساعدوه'],['They honored him','كرّموه']],c:0}]},

{ id:'hud', icon:'🏜️', c1:'#c9822b', c2:'#8a4d0f', name:['Hud','هود'],
  story:[
   ['The people of Ad were strong and built very tall buildings. But they became proud and forgot Who gave them their strength.','كان قوم عاد أقوياء يبنون الأبنية العالية، لكنهم تكبروا ونسوا من أعطاهم القوة.'],
   ['Allah sent them Hud, one of their own people. He told them to worship Allah alone and ask for forgiveness.','أرسل الله إليهم هودًا من أنفسهم، فدعاهم إلى عبادة الله وحده والاستغفار.'],
   ['They said, "Who is stronger than us?" and refused to listen to him.','قالوا: من أشد منا قوة؟ وأعرضوا عن دعوته.'],
   ['A powerful wind blew for seven nights and eight days. Hud and the believers were saved.','فأرسل الله عليهم ريحًا شديدة سبع ليالٍ وثمانية أيام، ونجّى هودًا والذين آمنوا معه.']],
  qs:[
   {q:['Which people was Hud sent to?','إلى أي قوم أُرسل هود؟'],o:[['Ad','عاد'],['Thamud','ثمود'],['Madyan','مدين'],['Saba','سبأ']],c:0},
   {q:['What were the people of Ad known for?','بماذا اشتهر قوم عاد؟'],o:[['Strength and tall buildings','القوة والأبنية العالية'],['Farming only','الزراعة فقط'],['Sailing','الإبحار'],['Poverty','الفقر']],c:0},
   {q:['What did Hud ask them to do?','ماذا طلب منهم هود؟'],o:[['Worship Allah alone','عبادة الله وحده'],['Move away','الرحيل'],['Fight him','قتاله'],['Build a ship','بناء سفينة']],c:0},
   {q:['What came upon the people of Ad?','ماذا أصاب قوم عاد؟'],o:[['A strong wind','ريح شديدة'],['A flood','فيضان'],['A drought','جفاف'],['A fire','حريق']],c:0},
   {q:['Who was saved?','من نجا؟'],o:[['Hud and the believers','هود والمؤمنون'],['Everyone','الجميع'],['No one','لا أحد'],['Only the rich','الأغنياء فقط']],c:0}]},

{ id:'salih', icon:'🐪', c1:'#a0522d', c2:'#6b3414', name:['Salih','صالح'],
  story:[
   ['The people of Thamud carved homes out of mountains and lived in comfort. They worshipped idols instead of Allah.','نحت قوم ثمود بيوتهم في الجبال وعاشوا في رخاء، وعبدوا الأصنام من دون الله.'],
   ['Salih called them to worship Allah. They asked for a sign, so Allah sent a she-camel out of a rock.','دعاهم صالح إلى عبادة الله، فطلبوا آية، فأخرج الله لهم ناقة من الصخرة.'],
   ['Salih told them to share water with her, one day for her, one day for them, and not to harm her.','قال لهم صالح: لها شِرب ولكم شِرب يوم معلوم، ولا تمسوها بسوء.'],
   ['They harmed the camel. After three days a mighty blast struck them, and Salih and the believers were saved.','عقروا الناقة، فأخذتهم الصيحة بعد ثلاثة أيام، ونجّى الله صالحًا والمؤمنين.']],
  qs:[
   {q:['Which people was Salih sent to?','إلى أي قوم أُرسل صالح؟'],o:[['Thamud','ثمود'],['Ad','عاد'],['Quraysh','قريش'],['Madyan','مدين']],c:0},
   {q:['Where did Thamud carve their homes?','أين نحت ثمود بيوتهم؟'],o:[['In the mountains','في الجبال'],['Under the sea','تحت البحر'],['In trees','في الأشجار'],['In the desert sand','في رمال الصحراء']],c:0},
   {q:['What was the sign sent to them?','ما الآية التي أُرسلت إليهم؟'],o:[['A she-camel','ناقة'],['A staff','عصا'],['A flood','طوفان'],['A star','نجم']],c:0},
   {q:['What was the rule about water?','ما الحكم في الماء؟'],o:[['Share it on separate days','يتقاسمونه في أيام معلومة'],['Keep it all','يحتكرونه'],['Never drink','لا يشربون'],['Sell it','يبيعونه']],c:0},
   {q:['What happened after they harmed the camel?','ماذا حدث بعد أن عقروا الناقة؟'],o:[['A mighty blast struck them','أخذتهم الصيحة'],['Nothing happened','لم يحدث شيء'],['They became kings','صاروا ملوكًا'],['They moved away','رحلوا']],c:0}]},

{ id:'ibrahim', icon:'🔥', c1:'#d9480f', c2:'#8f2a00', name:['Ibrahim (Abraham)','إبراهيم'],
  story:[
   ['Ibrahim looked at the star, the moon and the sun. He saw that they all disappear, so he said, "I turn to the One who created the heavens and earth."','نظر إبراهيم إلى الكوكب والقمر والشمس فرآها تغيب، فقال: إني وجهت وجهي للذي فطر السماوات والأرض.'],
   ['He asked his people why they worshipped idols. Then he broke them, leaving only the biggest one.','سأل قومه لماذا يعبدون الأصنام، ثم حطمها وترك كبيرها.'],
   ['His people threw him into a great fire. Allah said, "O fire, be cool and safe for Ibrahim." and he was not burned.','ألقاه قومه في نار عظيمة، فقال الله: يا نار كوني بردًا وسلامًا على إبراهيم، فلم يحترق.'],
   ['Later, Ibrahim and his son Ismail raised the foundations of the Kaaba in Makkah.','وفيما بعد رفع إبراهيم وابنه إسماعيل قواعد الكعبة في مكة.']],
  qs:[
   {q:['What did Ibrahim observe to find the truth?','ماذا تأمل إبراهيم ليصل للحقيقة؟'],o:[['Star, moon and sun','الكوكب والقمر والشمس'],['Mountains','الجبال'],['Rivers','الأنهار'],['Birds','الطيور']],c:0},
   {q:['Which idol did Ibrahim leave unbroken?','أي صنم ترك إبراهيم دون تحطيم؟'],o:[['The biggest one','أكبرها'],['The smallest one','أصغرها'],['None','لا شيء'],['The golden one','الذهبي']],c:0},
   {q:['What happened when Ibrahim was thrown into the fire?','ماذا حدث حين ألقي إبراهيم في النار؟'],o:[['It became cool and safe','صارت بردًا وسلامًا'],['He escaped','هرب'],['It burned him','أحرقته'],['It disappeared','اختفت']],c:0},
   {q:['Who helped Ibrahim build the Kaaba?','من ساعد إبراهيم في بناء الكعبة؟'],o:[['His son Ismail','ابنه إسماعيل'],['Musa','موسى'],['Nuh','نوح'],['Yusuf','يوسف']],c:0},
   {q:['In which city is the Kaaba?','في أي مدينة الكعبة؟'],o:[['Makkah','مكة'],['Madinah','المدينة'],['Jerusalem','القدس'],['Damascus','دمشق']],c:0}]}
);
