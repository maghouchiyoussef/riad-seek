// رسومات القطع (كلها مرسومة بالكود، بلا صور)
(function(){
'use strict';
const TAU = Math.PI * 2;

function shadow(g, s, w){
  g.save(); g.fillStyle = 'rgba(80,20,50,.18)';
  g.beginPath(); g.ellipse(0, s * .36, s * (w || .26), s * .06, 0, 0, TAU); g.fill(); g.restore();
}
function shine(g, x, y, rx, ry, a, rot){
  g.save(); g.fillStyle = `rgba(255,255,255,${a})`;
  g.beginPath(); g.ellipse(x, y, rx, ry, rot || 0, 0, TAU); g.fill(); g.restore();
}

// 0 — دانة (لؤلؤة)
function pearl(g, s){
  shadow(g, s, .25);
  const R = s * .35;
  let gr = g.createRadialGradient(-R * .35, -R * .4, R * .1, 0, 0, R);
  gr.addColorStop(0, '#ffffff'); gr.addColorStop(.4, '#f8e6ef'); gr.addColorStop(.8, '#dcb3c9'); gr.addColorStop(1, '#a9789a');
  g.fillStyle = gr; g.beginPath(); g.arc(0, 0, R, 0, TAU); g.fill();
  gr = g.createLinearGradient(-R, R, R, -R);
  gr.addColorStop(0, 'rgba(160,210,255,.28)'); gr.addColorStop(.5, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(255,190,230,.3)');
  g.fillStyle = gr; g.beginPath(); g.arc(0, 0, R, 0, TAU); g.fill();
  g.strokeStyle = 'rgba(120,60,100,.6)'; g.lineWidth = s * .025; g.beginPath(); g.arc(0, 0, R, 0, TAU); g.stroke();
  shine(g, -R * .38, -R * .42, R * .26, R * .16, .95, -.6);
  shine(g, R * .35, R * .45, R * .12, R * .06, .5, -.6);
}

// 1 — تمرة
function date(g, s){
  shadow(g, s, .2);
  g.save(); g.rotate(-.45);
  const rx = s * .24, ry = s * .37;
  const gr = g.createLinearGradient(-rx, -ry, rx, ry);
  gr.addColorStop(0, '#d9843d'); gr.addColorStop(.45, '#9a4a18'); gr.addColorStop(1, '#4f1f06');
  g.fillStyle = gr; g.beginPath(); g.ellipse(0, 0, rx, ry, 0, 0, TAU); g.fill();
  g.strokeStyle = 'rgba(50,18,4,.55)'; g.lineWidth = s * .022; g.stroke();
  g.strokeStyle = 'rgba(60,22,6,.45)'; g.lineWidth = s * .018; g.lineCap = 'round';
  [[-.05, -.15, .06, -.05], [.02, .05, -.07, .14], [.08, -.22, .12, -.1]].forEach(([a, b, c, d]) => {
    g.beginPath(); g.moveTo(a * s, b * s); g.quadraticCurveTo((a + c) / 2 * s + s * .05, (b + d) / 2 * s, c * s, d * s); g.stroke();
  });
  shine(g, -rx * .45, -ry * .3, rx * .22, ry * .42, .45, 0);
  g.fillStyle = '#e9c27a'; g.beginPath(); g.ellipse(0, -ry * .96, rx * .38, ry * .12, 0, 0, TAU); g.fill();
  g.strokeStyle = '#a07030'; g.lineWidth = s * .015; g.stroke();
  g.restore();
}

// 2 — دلّة (دلة القهوة)
function dallah(g, s){
  shadow(g, s, .26);
  const P = (x, y) => [x * s, y * s];
  const gold = g.createLinearGradient(-s * .3, 0, s * .3, 0);
  gold.addColorStop(0, '#9c6a14'); gold.addColorStop(.3, '#ffe9a3'); gold.addColorStop(.55, '#f1c14b'); gold.addColorStop(1, '#a8741a');
  g.lineJoin = 'round'; g.lineCap = 'round';
  // الصنبور (المنقار)
  g.strokeStyle = '#8a5a10'; g.lineWidth = s * .075;
  g.beginPath(); g.moveTo(...P(-.16, .1)); g.quadraticCurveTo(...P(-.3, .02), ...P(-.36, -.24)); g.stroke();
  g.strokeStyle = '#f0c454'; g.lineWidth = s * .045;
  g.beginPath(); g.moveTo(...P(-.16, .1)); g.quadraticCurveTo(...P(-.3, .02), ...P(-.36, -.24)); g.stroke();
  g.fillStyle = '#f6d36c'; g.beginPath(); g.moveTo(...P(-.42, -.26)); g.lineTo(...P(-.3, -.27)); g.lineTo(...P(-.35, -.2)); g.closePath(); g.fill();
  // المقبض
  g.strokeStyle = '#8a5a10'; g.lineWidth = s * .06;
  g.beginPath(); g.moveTo(...P(.1, -.2)); g.bezierCurveTo(...P(.34, -.2), ...P(.36, .12), ...P(.18, .2)); g.stroke();
  g.strokeStyle = '#e9b840'; g.lineWidth = s * .03;
  g.beginPath(); g.moveTo(...P(.1, -.2)); g.bezierCurveTo(...P(.34, -.2), ...P(.36, .12), ...P(.18, .2)); g.stroke();
  // الجسم
  g.fillStyle = gold; g.strokeStyle = '#7a4e0c'; g.lineWidth = s * .022;
  g.beginPath();
  g.moveTo(...P(-.2, .34));
  g.bezierCurveTo(...P(-.3, .22), ...P(-.26, .02), ...P(-.1, -.04));
  g.lineTo(...P(-.07, -.17));
  g.lineTo(...P(-.14, -.22));
  g.lineTo(...P(.14, -.22));
  g.lineTo(...P(.07, -.17));
  g.lineTo(...P(.1, -.04));
  g.bezierCurveTo(...P(.26, .02), ...P(.3, .22), ...P(.2, .34));
  g.closePath(); g.fill(); g.stroke();
  // الغطاء
  g.beginPath(); g.moveTo(...P(-.12, -.22)); g.quadraticCurveTo(...P(0, -.36), ...P(.12, -.22)); g.closePath(); g.fill(); g.stroke();
  g.beginPath(); g.arc(...P(0, -.36), s * .045, 0, TAU); g.fill(); g.stroke();
  // زخرفة
  g.strokeStyle = 'rgba(122,78,12,.7)'; g.lineWidth = s * .018;
  g.beginPath(); g.moveTo(...P(-.21, .15)); g.quadraticCurveTo(...P(0, .2), ...P(.21, .15)); g.stroke();
  g.beginPath(); g.moveTo(...P(-.085, -.08)); g.lineTo(...P(.085, -.08)); g.stroke();
  shine(g, -s * .13, s * .13, s * .035, s * .11, .55, .2);
}

// 3 — قارورة عطر
function perfume(g, s){
  shadow(g, s, .23);
  const P = (x, y) => [x * s, y * s];
  const gr = g.createLinearGradient(-s * .3, -s * .1, s * .3, s * .35);
  gr.addColorStop(0, '#e3c4ff'); gr.addColorStop(.4, '#a466f0'); gr.addColorStop(1, '#4e1c99');
  g.lineJoin = 'round';
  g.fillStyle = gr; g.strokeStyle = '#3d1478'; g.lineWidth = s * .022;
  g.beginPath();
  g.moveTo(...P(-.1, -.12)); g.lineTo(...P(.1, -.12)); g.lineTo(...P(.28, .06)); g.lineTo(...P(.2, .34)); g.lineTo(...P(-.2, .34)); g.lineTo(...P(-.28, .06));
  g.closePath(); g.fill(); g.stroke();
  // أوجه
  g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = s * .016;
  g.beginPath(); g.moveTo(...P(-.1, -.12)); g.lineTo(...P(-.12, .06)); g.lineTo(...P(-.28, .06)); g.moveTo(...P(-.12, .06)); g.lineTo(...P(-.08, .34));
  g.moveTo(...P(.1, -.12)); g.lineTo(...P(.12, .06)); g.lineTo(...P(.28, .06)); g.moveTo(...P(.12, .06)); g.lineTo(...P(.08, .34));
  g.moveTo(...P(-.12, .06)); g.lineTo(...P(.12, .06)); g.stroke();
  // العنق والسدادة
  const gd = g.createLinearGradient(-s * .1, 0, s * .1, 0);
  gd.addColorStop(0, '#a8741a'); gd.addColorStop(.4, '#ffe9a3'); gd.addColorStop(1, '#b8841f');
  g.fillStyle = gd; g.strokeStyle = '#7a4e0c'; g.lineWidth = s * .018;
  g.beginPath(); g.rect(...P(-.06, -.2), s * .12, s * .08); g.fill(); g.stroke();
  g.beginPath(); g.moveTo(...P(0, -.42)); g.bezierCurveTo(...P(.12, -.34), ...P(.09, -.2), ...P(0, -.2)); g.bezierCurveTo(...P(-.09, -.2), ...P(-.12, -.34), ...P(0, -.42)); g.fill(); g.stroke();
  shine(g, -s * .15, s * .16, s * .03, s * .1, .6, .15);
  shine(g, -s * .02, -s * .32, s * .02, s * .04, .7, 0);
}

// 4 — وردة طائفية
function rose(g, s){
  shadow(g, s, .24);
  const P = (x, y) => [x * s, y * s];
  // أوراق
  const lg = g.createLinearGradient(0, 0, 0, s * .4);
  lg.addColorStop(0, '#5cc46a'); lg.addColorStop(1, '#1f7a34');
  g.fillStyle = lg;
  [[-.22, .2, -.7], [.22, .2, .7]].forEach(([x, y, r]) => { g.save(); g.translate(...P(x, y)); g.rotate(r); g.beginPath(); g.ellipse(0, 0, s * .08, s * .17, 0, 0, TAU); g.fill(); g.restore(); });
  const R = s * .29;
  const pet = (x, y, r, c1, c2) => { const gr = g.createRadialGradient(x - r * .3, y - r * .3, r * .1, x, y, r); gr.addColorStop(0, c1); gr.addColorStop(1, c2); g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); };
  for(let i = 0; i < 6; i++){ const a = i / 6 * TAU - .3; pet(Math.cos(a) * R * .55, Math.sin(a) * R * .55 - s * .02, R * .55, '#ff8fab', '#c2185b'); }
  g.strokeStyle = 'rgba(120,0,50,.35)'; g.lineWidth = s * .014;
  for(let i = 0; i < 6; i++){ const a = i / 6 * TAU - .3; g.beginPath(); g.arc(Math.cos(a) * R * .55, Math.sin(a) * R * .55 - s * .02, R * .55, a - 1.1, a + 1.1); g.stroke(); }
  pet(0, -s * .02, R * .62, '#ff9cb6', '#d81b60');
  g.strokeStyle = 'rgba(110,0,45,.55)'; g.lineWidth = s * .02; g.lineCap = 'round';
  g.beginPath();
  for(let a = 0; a < TAU * 2.2; a += .2){ const r = R * .07 + a * R * .042; const x = Math.cos(a) * r, y = Math.sin(a) * r - s * .02; a === 0 ? g.moveTo(x, y) : g.lineTo(x, y); }
  g.stroke();
  shine(g, -R * .45, -R * .55, R * .16, R * .09, .55, -.6);
}

// 5 — زمرد
function emerald(g, s){
  shadow(g, s, .25);
  const R = s * .35, r = s * .19, n = 8, off = Math.PI / 8;
  const pts = (rad) => Array.from({ length: n }, (_, i) => [Math.cos(i / n * TAU + off) * rad, Math.sin(i / n * TAU + off) * rad]);
  const O = pts(R), I = pts(r);
  const gr = g.createLinearGradient(-R, -R, R, R);
  gr.addColorStop(0, '#8ff5c4'); gr.addColorStop(.45, '#1fbf73'); gr.addColorStop(1, '#05613a');
  g.fillStyle = gr; g.strokeStyle = '#04502f'; g.lineWidth = s * .022; g.lineJoin = 'round';
  g.beginPath(); O.forEach((p, i) => i ? g.lineTo(...p) : g.moveTo(...p)); g.closePath(); g.fill(); g.stroke();
  for(let i = 0; i < n; i++){
    const j = (i + 1) % n, light = [.28, .2, .08, .02, .0, .05, .14, .24][i];
    g.fillStyle = `rgba(255,255,255,${light})`;
    g.beginPath(); g.moveTo(...O[i]); g.lineTo(...O[j]); g.lineTo(...I[j]); g.lineTo(...I[i]); g.closePath(); g.fill();
  }
  const tg = g.createLinearGradient(-r, -r, r, r); tg.addColorStop(0, '#c9ffe4'); tg.addColorStop(1, '#2ad186');
  g.fillStyle = tg; g.beginPath(); I.forEach((p, i) => i ? g.lineTo(...p) : g.moveTo(...p)); g.closePath(); g.fill();
  g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = s * .012;
  for(let i = 0; i < n; i++){ g.beginPath(); g.moveTo(...O[i]); g.lineTo(...I[i]); g.stroke(); }
  sparkle(g, -r * .5, -r * .6, s * .07, .95);
}

function sparkle(g, x, y, r, a){
  g.save(); g.translate(x, y); g.fillStyle = `rgba(255,255,255,${a})`;
  g.beginPath(); g.moveTo(0, -r); g.quadraticCurveTo(0, 0, r, 0); g.quadraticCurveTo(0, 0, 0, r); g.quadraticCurveTo(0, 0, -r, 0); g.quadraticCurveTo(0, 0, 0, -r); g.fill();
  g.restore();
}

// الدانة الكبرى (القطعة السحرية)
function bigPearl(g, s){
  shadow(g, s, .28);
  const R = s * .38;
  let gr;
  if(g.createConicGradient){
    gr = g.createConicGradient(0, 0, 0);
    ['#ffd1e6', '#ffe9a8', '#c9f7d8', '#bfe3ff', '#e2ccff', '#ffd1e6'].forEach((c, i, a) => gr.addColorStop(i / (a.length - 1), c));
  } else { gr = g.createRadialGradient(0, 0, 0, 0, 0, R); gr.addColorStop(0, '#fff'); gr.addColorStop(1, '#e2ccff'); }
  g.fillStyle = gr; g.beginPath(); g.arc(0, 0, R, 0, TAU); g.fill();
  const rg = g.createRadialGradient(-R * .3, -R * .35, R * .05, 0, 0, R);
  rg.addColorStop(0, 'rgba(255,255,255,.95)'); rg.addColorStop(.5, 'rgba(255,255,255,.2)'); rg.addColorStop(1, 'rgba(120,60,140,.35)');
  g.fillStyle = rg; g.beginPath(); g.arc(0, 0, R, 0, TAU); g.fill();
  g.strokeStyle = '#d4a234'; g.lineWidth = s * .035; g.beginPath(); g.arc(0, 0, R, 0, TAU); g.stroke();
  g.strokeStyle = '#fff3c4'; g.lineWidth = s * .012; g.beginPath(); g.arc(0, 0, R - s * .02, 0, TAU); g.stroke();
  shine(g, -R * .35, -R * .42, R * .24, R * .14, .95, -.6);
  sparkle(g, R * .4, R * .25, s * .07, .9);
}

const FN = [pearl, date, dallah, perfume, rose, emerald];
function draw(g, t, s){ if(t < 0) bigPearl(g, s); else FN[t](g, s); }

// صورة جاهزة لقطعة
function image(t, px){
  const c = document.createElement('canvas'); c.width = c.height = px;
  const g = c.getContext('2d'); g.translate(px / 2, px / 2); draw(g, t, px);
  return c;
}
// أيقونة الرمل
function sandImage(px){
  const c = document.createElement('canvas'); c.width = c.height = px;
  const g = c.getContext('2d');
  const r = px * .18, x = px * .1, y = px * .1, w = px * .8;
  g.fillStyle = '#efcf8f'; g.strokeStyle = '#c89a4a'; g.lineWidth = px * .05;
  g.beginPath(); g.roundRect ? g.roundRect(x, y, w, w, r) : g.rect(x, y, w, w); g.fill(); g.stroke();
  g.fillStyle = '#c99a50';
  for(let i = 0; i < 9; i++){ g.beginPath(); g.arc(x + w * (.2 + (i % 3) * .3), y + w * (.2 + Math.floor(i / 3) * .3), px * .035, 0, TAU); g.fill(); }
  return c;
}

window.Art = { draw, image, sandImage, sparkle, NAMES: ['لؤلؤة', 'تمرة', 'دلّة', 'عطر', 'وردة', 'زمرد'] };
})();
