// زينة — رسومات القطع (كلها مرسومة بالكود)
(function(){
'use strict';
const TAU = Math.PI * 2;

function shadow(g, s, w){
  g.save(); g.fillStyle = 'rgba(80,20,50,.18)';
  g.beginPath(); g.ellipse(0, s * .36, s * (w || .26), s * .06, 0, 0, TAU); g.fill(); g.restore();
}
function shine(g, x, y, rx, ry, a, rot){
  g.save(); g.fillStyle = `rgba(255,255,255,${a})`;
  g.beginPath(); g.ellipse(x, y, rx, ry, rot || 0, 0, TAU); g.fill(); g.restore();
}

// 0 — دانة (لؤلؤة)
function pearl(g, s){
  shadow(g, s, .25);
  const R = s * .35;
  let gr = g.createRadialGradient(-R * .35, -R * .4, R * .1, 0, 0, R);
  gr.addColorStop(0, '#ffffff'); gr.addColorStop(.4, '#f8e6ef'); gr.addColorStop(.8, '#dcb3c9'); gr.addColorStop(1, '#a9789a');
  g.fillStyle = gr; g.beginPath(); g.arc(0, 0, R, 0, TAU); g.fill();
  gr = g.createLinearGradient(-R, R, R, -R);
  gr.addColorStop(0, 'rgba(160,210,255,.28)'); gr.addColorStop(.5, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(255,190,230,.3)');
  g.fillStyle = gr; g.beginPath(); g.arc(0, 0, R, 0, TAU); g.fill();
  g.strokeStyle = 'rgba(120,60,100,.6)'; g.lineWidth = s * .025; g.beginPath(); g.arc(0, 0, R, 0, TAU); g.stroke();
  shine(g, -R * .38, -R * .42, R * .26, R * .16, .95, -.6);
  shine(g, R * .35, R * .45, R * .12, R * .06, .5, -.6);
}

// 1 — تمرة
function date(g, s){
  shadow(g, s, .2);
  g.save(); g.rotate(-.45);
  const rx = s * .24, ry = s * .37;
  const gr = g.createLinearGradient(-rx, -ry, rx, ry);
  gr.addColorStop(0, '#d9843d'); gr.addColorStop(.45, '#9a4a18'); gr.addColorStop(1, '#4f1f06');
  g.fillStyle = gr; g.beginPath(); g.ellipse(0, 0, rx, ry, 0, 0, TAU); g.fill();
  g.strokeStyle = 'rgba(50,18,4,.55)'; g.lineWidth = s * .022; g.stroke();
  g.strokeStyle = 'rgba(60,22,6,.45)'; g.lineWidth = s * .018; g.lineCap = 'round';
  [[-.05, -.15, .06, -.05], [.02, .05, -.07, .14], [.08, -.22, .12, -.1]].forEach(([a, b, c, d]) => {
    g.beginPath(); g.moveTo(a * s, b * s); g.quadraticCurveTo((a + c) / 2 * s + s * .05, (b + d) / 2 * s, c * s, d * s); g.stroke();
  });
  shine(g, -rx * .45, -ry * .3, rx * .22, ry * .42, .45, 0);
  g.fillStyle = '#e9c27a'; g.beginPath(); g.ellipse(0, -ry * .96, rx * .38, ry * .12, 0, 0, TAU); g.fill();
  g.strokeStyle = '#a07030'; g.lineWidth = s * .015; g.stroke();
  g.restore();
}

// 2 — دلّة (دلة القهوة)
function dallah(g, s){
  shadow(g, s, .26);
  const P = (x, y) => [x * s, y * s];
  const gold = g.createLinearGradient(-s * .3, 0, s * .3, 0);
  gold.addColorStop(0, '#9c6a14'); gold.addColorStop(.3, '#ffe9a3'); gold.addColorStop(.55, '#f1c14b'); gold.addColorStop(1, '#a8741a');
  g.lineJoin = 'round'; g.lineCap = 'round';
  // الصنبور (المنقار)
  g.strokeStyle = '#8a5a10'; g.lineWidth = s * .075;
  g.beginPath(); g.moveTo(...P(-.16, .1)); g.quadraticCurveTo(...P(-.3, .02), ...P(-.36, -.24)); g.stroke();
  g.strokeStyle = '#f0c454'; g.lineWidth = s * .045;
  g.beginPath(); g.moveTo(...P(-.16, .1)); g.quadraticCurveTo(...P(-.3, .02), ...P(-.36, -.24)); g.stroke();
  g.fillStyle = '#f6d36c'; g.beginPath(); g.moveTo(...P(-.42, -.26)); g.lineTo(...P(-.3, -.27)); g.lineTo(...P(-.35, -.2)); g.closePath(); g.fill();
  // المقبض
  g.strokeStyle = '#8a5a10'; g.lineWidth = s * .06;
  g.beginPath(); g.moveTo(...P(.1, -.2)); g.bezierCurveTo(...P(.34, -.2), ...P(.36, .12), ...P(.18, .2)); g.stroke();
  g.strokeStyle = '#e9b840'; g.lineWidth = s * .03;
  g.beginPath(); g.moveTo(...P(.1, -.2)); g.bezierCurveTo(...P(.34, -.2), ...P(.36, .12), ...P(.18, .2)); g.stroke();
  // الجسم
  g.fillStyle = gold; g.strokeStyle = '#7a4e0c'; g.lineWidth = s * .022;
  g.beginPath();
  g.moveTo(...P(-.2, .34));
  g.bezierCurveTo(...P(-.3, .22), ...P(-.26, .02), ...P(-.1, -.04));
  g.lineTo(...P(-.07, -.17));
  g.lineTo(...P(-.14, -.22));
  g.lineTo(...P(.14, -.22));
  g.lineTo(...P(.07, -.17));
  g.lineTo(...P(.1, -.04));
  g.bezierCurveTo(...P(.26, .02), ...P(.3, .22), ...P(.2, .34));
  g.closePath(); g.fill(); g.stroke();
  // الغطاء
  g.beginPath(); g.moveTo(...P(-.12, -.22)); g.quadraticCurveTo(...P(0, -.36), ...P(.12, -.22)); g.closePath(); g.fill(); g.stroke();
  g.beginPath(); g.arc(...P(0, -.36), s * .045, 0, TAU); g.fill(); g.stroke();
  // زخرفة
  g.strokeStyle = 'rgba(122,78,12,.7)'; g.lineWidth = s * .018;
  g.beginPath(); g.moveTo(...P(-.21, .15)); g.quadraticCurveTo(...P(0, .2), ...P(.21, .15)); g.stroke();
  g.beginPath(); g.moveTo(...P(-.085, -.08)); g.lineTo(...P(.085, -.08)); g.stroke();
  shine(g, -s * .13, s * .13, s * .035, s * .11, .55, .2);
}

// 3 — قارورة عطر
function perfume(g, s){
  shadow(g, s, .23);
  const P = (x, y) => [x * s, y * s];
  const gr = g.createLinearGradient(-s * .3, -s * .1, s * .3, s * .35);
  gr.addColorStop(0, '#e3c4ff'); gr.addColorStop(.4, '#a466f0'); gr.addColorStop(1, '#4e1c99');
  g.lineJoin = 'round';
  g.fillStyle = gr; g.strokeStyle = '#3d1478'; g.lineWidth = s * .022;
  g.beginPath();
  g.moveTo(...P(-.1, -.12)); g.lineTo(...P(.1, -.12)); g.lineTo(...P(.28, .06)); g.lineTo(...P(.2, .34)); g.lineTo(...P(-.2, .34)); g.lineTo(...P(-.28, .06));
  g.closePath(); g.fill(); g.stroke();
  // أوجه
  g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = s * .016;
  g.beginPath(); g.moveTo(...P(-.1, -.12)); g.lineTo(...P(-.12, .06)); g.lineTo(...P(-.28, .06)); g.moveTo(...P(-.12, .06)); g.lineTo(...P(-.08, .34));
  g.moveTo(...P(.1, -.12)); g.lineTo(...P(.12, .06)); g.lineTo(...P(.28, .06)); g.moveTo(...P(.12, .06)); g.lineTo(...P(.08, .34));
  g.moveTo(...P(-.12, .06)); g.lineTo(...P(.12, .06)); g.stroke();
  // العنق والسدادة
  const gd = g.createLinearGradient(-s * .1, 0, s * .1, 0);
  gd.addColorStop(0, '#a8741a'); gd.addColorStop(.4, '#ffe9a3'); gd.addColorStop(1, '#b8841f');
  g.fillStyle = gd; g.strokeStyle = '#7a4e0c'; g.lineWidth = s * .018;
  g.beginPath(); g.rect(...P(-.06, -.2), s * .12, s * .08); g.fill(); g.stroke();
  g.beginPath(); g.moveTo(...P(0, -.42)); g.bezierCurveTo(...P(.12, -.34), ...P(.09, -.2), ...P(0, -.2)); g.bezierCurveTo(...P(-.09, -.2), ...P(-.12, -.34), ...P(0, -.42)); g.fill(); g.stroke();
  shine(g, -s * .15, s * .16, s * .03, s * .1, .6, .15);
  shine(g, -s * .02, -s * .32, s * .02, s * .04, .7, 0);
}

// 4 — وردة طائفية
function rose(g, s){
  shadow(g, s, .24);
  const P = (x, y) => [x * s, y * s];
  // أوراق
  const lg = g.createLinearGradient(0, 0, 0, s * .4);
  lg.addColorStop(0, '#5cc46a'); lg.addColorStop(1, '#1f7a34');
  g.fillStyle = lg;
  [[-.22, .2, -.7], [.22, .2, .7]].forEach(([x, y, r]) => { g.save(); g.translate(...P(x, y)); g.rotate(r); g.beginPath(); g.ellipse(0, 0, s * .08, s * .17, 0, 0, TAU); g.fill(); g.restore(); });
  const R = s * .29;
  const pet = (x, y, r, c1, c2) => { const gr = g.createRadialGradient(x - r * .3, y - r * .3, r * .1, x, y, r); gr.addColorStop(0, c1); gr.addColorStop(1, c2); g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); };
  for(let i = 0; i < 6; i++){ const a = i / 6 * TAU - .3; pet(Math.cos(a) * R * .55, Math.sin(a) * R * .55 - s * .02, R * .55, '#ff8fab', '#c2185b'); }
  g.strokeStyle = 'rgba(120,0,50,.35)'; g.lineWidth = s * .014;
  for(let i = 0; i < 6; i++){ const a = i / 6 * TAU - .3; g.beginPath(); g.arc(Math.cos(a) * R * .55, Math.sin(a) * R * .55 - s * .02, R * .55, a - 1.1, a + 1.1); g.stroke(); }
  pet(0, -s * .02, R * .62, '#ff9cb6', '#d81b60');
  g.strokeStyle = 'rgba(110,0,45,.55)'; g.lineWidth = s * .02; g.lineCap = 'round';
  g.beginPath();
  for(let a = 0; a < TAU * 2.2; a += .2){ const r = R * .07 + a * R * .042; const x = Math.cos(a) * r, y = Math.sin(a) * r - s * .02; a === 0 ? g.moveTo(x, y) : g.lineTo(x, y); }
  g.stroke();
  shine(g, -R * .45, -R * .55, R * .16, R * .09, .55, -.6);
}

// 5 — زمرد
function emerald(g, s){
  shadow(g, s, .25);
  const R = s * .35, r = s * .19, n = 8, off = Math.PI / 8;
  const pts = (rad) => Array.from({ length: n }, (_, i) => [Math.cos(i / n * TAU + off) * rad, Math.sin(i / n * TAU + off) * rad]);
  const O = pts(R), I = pts(r);
  const gr = g.createLinearGradient(-R, -R, R, R);
  gr.addColorStop(0, '#8ff5c4'); gr.addColorStop(.45, '#1fbf73'); gr.addColorStop(1, '#05613a');
  g.fillStyle = gr; g.strokeStyle = '#04502f'; g.lineWidth = s * .022; g.lineJoin = 'round';
  g.beginPath(); O.forEach((p, i) => i ? g.lineTo(...p) : g.moveTo(...p)); g.closePath(); g.fill(); g.stroke();
  for(let i = 0; i < n; i++){
    const j = (i + 1) % n, light = [.28, .2, .08, .02, .0, .05, .14, .24][i];
    g.fillStyle = `rgba(255,255,255,${light})`;
    g.beginPath(); g.moveTo(...O[i]); g.lineTo(...O[j]); g.lineTo(...I[j]); g.lineTo(...I[i]); g.closePath(); g.fill();
  }
  const tg = g.createLinearGradient(-r, -r, r, r); tg.addColorStop(0, '#c9ffe4'); tg.addColorStop(1, '#2ad186');
  g.fillStyle = tg; g.beginPath(); I.forEach((p, i) => i ? g.lineTo(...p) : g.moveTo(...p)); g.closePath(); g.fill();
  g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = s * .012;
  for(let i = 0; i < n; i++){ g.beginPath(); g.moveTo(...O[i]); g.lineTo(...I[i]); g.stroke(); }
  sparkle(g, -r * .5, -r * .6, s * .07, .95);
}

function sparkle(g, x, y, r, a){
  g.save(); g.translate(x, y); g.fillStyle = `rgba(255,255,255,${a})`;
  g.beginPath(); g.moveTo(0, -r); g.quadraticCurveTo(0, 0, r, 0); g.quadraticCurveTo(0, 0, 0, r); g.quadraticCurveTo(0, 0, -r, 0); g.quadraticCurveTo(0, 0, 0, -r); g.fill();
  g.restore();
}


// 6 — فنجان قهوة
function finjan(g, s){
  shadow(g, s, .26);
  const P = (x, y) => [x * s, y * s];
  // الصحن
  g.fillStyle = '#e8d6b0'; g.strokeStyle = '#9a7a3a'; g.lineWidth = s * .02;
  g.beginPath(); g.ellipse(0, s * .25, s * .33, s * .08, 0, 0, TAU); g.fill(); g.stroke();
  // الفنجان
  const gr = g.createLinearGradient(-s * .25, 0, s * .25, 0);
  gr.addColorStop(0, '#d9e9f5'); gr.addColorStop(.4, '#ffffff'); gr.addColorStop(1, '#a9c3d8');
  g.fillStyle = gr; g.strokeStyle = '#4c6c86'; g.lineWidth = s * .022;
  g.beginPath(); g.moveTo(...P(-.25, -.12)); g.lineTo(...P(.25, -.12)); g.bezierCurveTo(...P(.24, .14), ...P(.14, .24), ...P(0, .24)); g.bezierCurveTo(...P(-.14, .24), ...P(-.24, .14), ...P(-.25, -.12)); g.closePath(); g.fill(); g.stroke();
  // القهوة
  g.fillStyle = '#c9963d'; g.beginPath(); g.ellipse(0, -s * .12, s * .23, s * .05, 0, 0, TAU); g.fill();
  // زخرفة ذهبية
  g.strokeStyle = '#d4a234'; g.lineWidth = s * .03;
  g.beginPath(); g.moveTo(...P(-.24, -.04)); g.quadraticCurveTo(...P(0, .02), ...P(.24, -.04)); g.stroke();
  g.fillStyle = '#d4a234';
  [-.12, 0, .12].forEach(x => { g.beginPath(); g.arc(...P(x, .1), s * .025, 0, TAU); g.fill(); });
  // بخار
  g.strokeStyle = 'rgba(150,120,90,.55)'; g.lineWidth = s * .025; g.lineCap = 'round';
  [-.08, .06].forEach(x => { g.beginPath(); g.moveTo(...P(x, -.2)); g.bezierCurveTo(...P(x - .06, -.27), ...P(x + .06, -.32), ...P(x, -.4)); g.stroke(); });
  shine(g, -s * .15, s * .02, s * .03, s * .08, .7, .2);
}

// 7 — مبخرة
function mabkhara(g, s){
  shadow(g, s, .24);
  const P = (x, y) => [x * s, y * s];
  const wood = g.createLinearGradient(-s * .25, 0, s * .25, 0);
  wood.addColorStop(0, '#5a2a12'); wood.addColorStop(.45, '#a2582a'); wood.addColorStop(1, '#4a200c');
  g.fillStyle = wood; g.strokeStyle = '#2e1206'; g.lineWidth = s * .02; g.lineJoin = 'round';
  // القاعدة
  g.beginPath(); g.moveTo(...P(-.2, .34)); g.lineTo(...P(.2, .34)); g.lineTo(...P(.12, .14)); g.lineTo(...P(-.12, .14)); g.closePath(); g.fill(); g.stroke();
  // العنق
  g.beginPath(); g.rect(...P(-.08, .02), s * .16, s * .12); g.fill(); g.stroke();
  // الكأس
  g.beginPath(); g.moveTo(...P(-.24, -.14)); g.lineTo(...P(.24, -.14)); g.lineTo(...P(.14, .02)); g.lineTo(...P(-.14, .02)); g.closePath(); g.fill(); g.stroke();
  // ذهب
  g.fillStyle = '#f0c454'; g.strokeStyle = '#8a5a10'; g.lineWidth = s * .012;
  [[-.13, .24], [0, .24], [.13, .24], [-.12, -.07], [.12, -.07], [0, -.07]].forEach(([x, y]) => { g.beginPath(); g.arc(...P(x, y), s * .028, 0, TAU); g.fill(); g.stroke(); });
  g.fillStyle = '#f0c454'; g.fillRect(...P(-.2, .13), s * .4, s * .025);
  // جمر ودخان
  g.fillStyle = '#ff6a2a'; g.beginPath(); g.ellipse(0, -s * .15, s * .16, s * .035, 0, 0, TAU); g.fill();
  g.strokeStyle = 'rgba(140,120,140,.6)'; g.lineWidth = s * .03; g.lineCap = 'round';
  g.beginPath(); g.moveTo(...P(0, -.18)); g.bezierCurveTo(...P(-.1, -.26), ...P(.1, -.32), ...P(-.02, -.42)); g.stroke();
  g.lineWidth = s * .02;
  g.beginPath(); g.moveTo(...P(.08, -.18)); g.bezierCurveTo(...P(.16, -.25), ...P(.04, -.3), ...P(.12, -.37)); g.stroke();
}

// 8 — خاتم ذهب
function ring(g, s){
  shadow(g, s, .24);
  const gold = g.createLinearGradient(-s * .3, -s * .3, s * .3, s * .3);
  gold.addColorStop(0, '#fff1b8'); gold.addColorStop(.35, '#f1c14b'); gold.addColorStop(.7, '#b8841f'); gold.addColorStop(1, '#f7d77a');
  g.strokeStyle = '#7a4e0c'; g.lineWidth = s * .13;
  g.beginPath(); g.ellipse(0, s * .08, s * .24, s * .22, 0, 0, TAU); g.stroke();
  g.strokeStyle = gold; g.lineWidth = s * .09;
  g.beginPath(); g.ellipse(0, s * .08, s * .24, s * .22, 0, 0, TAU); g.stroke();
  // الحجرة
  g.fillStyle = '#f1c14b'; g.strokeStyle = '#7a4e0c'; g.lineWidth = s * .02;
  g.beginPath(); g.moveTo(-s * .12, -s * .14); g.lineTo(s * .12, -s * .14); g.lineTo(s * .08, -s * .2); g.lineTo(-s * .08, -s * .2); g.closePath(); g.fill(); g.stroke();
  const rb = g.createLinearGradient(-s * .12, -s * .38, s * .12, -s * .14);
  rb.addColorStop(0, '#ffb3c7'); rb.addColorStop(.5, '#e0245e'); rb.addColorStop(1, '#7a0a30');
  g.fillStyle = rb; g.strokeStyle = '#5a0624';
  g.beginPath(); g.moveTo(0, -s * .42); g.lineTo(s * .13, -s * .3); g.lineTo(0, -s * .18); g.lineTo(-s * .13, -s * .3); g.closePath(); g.fill(); g.stroke();
  g.strokeStyle = 'rgba(255,255,255,.45)'; g.lineWidth = s * .012;
  g.beginPath(); g.moveTo(0, -s * .42); g.lineTo(0, -s * .18); g.moveTo(-s * .13, -s * .3); g.lineTo(s * .13, -s * .3); g.stroke();
  sparkle(g, -s * .05, -s * .34, s * .05, .95);
  shine(g, -s * .2, s * .02, s * .03, s * .08, .7, .3);
}

// 9 — فانوس
function lantern(g, s){
  shadow(g, s, .22);
  const P = (x, y) => [x * s, y * s];
  g.lineJoin = 'round';
  // الضوء
  const glow = g.createRadialGradient(0, s * .05, s * .02, 0, s * .05, s * .22);
  glow.addColorStop(0, '#fff6c2'); glow.addColorStop(.5, '#ffcc4d'); glow.addColorStop(1, '#e08a1e');
  g.fillStyle = glow;
  g.beginPath(); g.moveTo(...P(-.16, -.14)); g.lineTo(...P(.16, -.14)); g.lineTo(...P(.2, .1)); g.lineTo(...P(.12, .26)); g.lineTo(...P(-.12, .26)); g.lineTo(...P(-.2, .1)); g.closePath(); g.fill();
  // الإطار
  g.strokeStyle = '#1f6a63'; g.lineWidth = s * .035;
  g.stroke();
  g.lineWidth = s * .022;
  g.beginPath(); g.moveTo(...P(0, -.14)); g.lineTo(...P(0, .26)); g.moveTo(...P(-.2, .1)); g.lineTo(...P(.2, .1)); g.stroke();
  // القبة
  const tg = g.createLinearGradient(-s * .2, 0, s * .2, 0);
  tg.addColorStop(0, '#145049'); tg.addColorStop(.45, '#3fb3a3'); tg.addColorStop(1, '#0f3d38');
  g.fillStyle = tg; g.strokeStyle = '#0b2e2a'; g.lineWidth = s * .02;
  g.beginPath(); g.moveTo(...P(-.2, -.14)); g.quadraticCurveTo(...P(-.16, -.3), ...P(0, -.34)); g.quadraticCurveTo(...P(.16, -.3), ...P(.2, -.14)); g.closePath(); g.fill(); g.stroke();
  g.beginPath(); g.rect(...P(-.14, .26), s * .28, s * .07); g.fill(); g.stroke();
  // الحلقة
  g.strokeStyle = '#d4a234'; g.lineWidth = s * .03;
  g.beginPath(); g.arc(...P(0, -.39), s * .05, 0, TAU); g.stroke();
  // هلال
  g.fillStyle = '#f1c14b';
  g.beginPath(); g.arc(...P(0, -.25), s * .045, 0, TAU); g.fill();
  g.fillStyle = '#2a8a7e'; g.beginPath(); g.arc(...P(.02, -.26), s * .038, 0, TAU); g.fill();
}

// 10 — نخلة
function palm(g, s){
  shadow(g, s, .22);
  const P = (x, y) => [x * s, y * s];
  // الجذع
  const tr = g.createLinearGradient(-s * .06, 0, s * .06, 0);
  tr.addColorStop(0, '#6b3e15'); tr.addColorStop(.5, '#b07a3a'); tr.addColorStop(1, '#5a3210');
  g.fillStyle = tr; g.strokeStyle = '#3b2008'; g.lineWidth = s * .015;
  g.beginPath(); g.moveTo(...P(-.07, .34)); g.quadraticCurveTo(...P(-.02, .05), ...P(-.03, -.16)); g.lineTo(...P(.04, -.16)); g.quadraticCurveTo(...P(.05, .05), ...P(.07, .34)); g.closePath(); g.fill(); g.stroke();
  g.strokeStyle = 'rgba(60,30,8,.5)'; g.lineWidth = s * .015;
  for(let y = -.1; y < .32; y += .07){ g.beginPath(); g.moveTo(...P(-.05, y)); g.lineTo(...P(.05, y + .02)); g.stroke(); }
  // السعف
  const leaf = (a, len) => {
    g.save(); g.translate(0, -s * .17); g.rotate(a);
    const lg = g.createLinearGradient(0, 0, len * s, 0); lg.addColorStop(0, '#1f8a3a'); lg.addColorStop(1, '#6cd37a');
    g.fillStyle = lg; g.strokeStyle = '#11552a'; g.lineWidth = s * .012;
    g.beginPath(); g.moveTo(0, 0); g.quadraticCurveTo(len * s * .5, -s * .1, len * s, s * .04); g.quadraticCurveTo(len * s * .5, s * .02, 0, 0); g.fill(); g.stroke();
    g.restore();
  };
  [[-2.7, .32], [-2.1, .3], [-1.57, .26], [-1.0, .3], [-.4, .32], [-3.3, .26], [.2, .26]].forEach(([a, l]) => leaf(a, l));
  // تمر
  g.fillStyle = '#c0601e';
  [[-.05, -.1], [.03, -.08], [-.01, -.04]].forEach(([x, y]) => { g.beginPath(); g.ellipse(...P(x, y), s * .03, s * .04, 0, 0, TAU); g.fill(); });
}

// 11 — إسوارة
function bangle(g, s){
  shadow(g, s, .26);
  g.save(); g.scale(1, .62); g.translate(0, s * .05);
  const gold = g.createLinearGradient(-s * .34, -s * .34, s * .34, s * .34);
  gold.addColorStop(0, '#fff3c4'); gold.addColorStop(.3, '#f1c14b'); gold.addColorStop(.65, '#a8741a'); gold.addColorStop(1, '#f7d77a');
  g.strokeStyle = '#6e4508'; g.lineWidth = s * .16;
  g.beginPath(); g.arc(0, 0, s * .3, 0, TAU); g.stroke();
  g.strokeStyle = gold; g.lineWidth = s * .12;
  g.beginPath(); g.arc(0, 0, s * .3, 0, TAU); g.stroke();
  g.restore();
  // فصوص
  const cols = ['#1fbf73', '#e0245e', '#3a7bd5', '#1fbf73', '#e0245e', '#3a7bd5'];
  for(let i = 0; i < 6; i++){
    const a = Math.PI * (.12 + i * .15);
    const x = Math.cos(a) * s * .3, y = Math.sin(a) * s * .3 * .62 + s * .05 * .62;
    g.fillStyle = cols[i]; g.strokeStyle = '#5a3a06'; g.lineWidth = s * .01;
    g.beginPath(); g.arc(x, y, s * .035, 0, TAU); g.fill(); g.stroke();
    shine(g, x - s * .01, y - s * .012, s * .012, s * .008, .8, 0);
  }
  shine(g, -s * .22, -s * .1, s * .06, s * .02, .7, -.3);
}

// 12 — صدفة
function shell(g, s){
  shadow(g, s, .26);
  const P = (x, y) => [x * s, y * s];
  const gr = g.createRadialGradient(0, s * .3, s * .02, 0, s * .1, s * .42);
  gr.addColorStop(0, '#fff4ec'); gr.addColorStop(.5, '#ffc6b0'); gr.addColorStop(1, '#e8806a');
  g.fillStyle = gr; g.strokeStyle = '#a24a36'; g.lineWidth = s * .022; g.lineJoin = 'round';
  g.beginPath(); g.moveTo(...P(-.08, .3));
  const n = 7;
  for(let i = 0; i <= n; i++){
    const a = Math.PI * (1.05 + i / n * .9);
    const x = Math.cos(a) * s * .36, y = Math.sin(a) * s * .36 + s * .1;
    const am = Math.PI * (1.05 + (i - .5) / n * .9);
    if(i) g.quadraticCurveTo(Math.cos(am) * s * .42, Math.sin(am) * s * .42 + s * .1, x, y); else g.lineTo(x, y);
  }
  g.lineTo(...P(.08, .3)); g.closePath(); g.fill(); g.stroke();
  // خطوط
  g.strokeStyle = 'rgba(162,74,54,.55)'; g.lineWidth = s * .016;
  for(let i = 1; i < n; i++){
    const a = Math.PI * (1.05 + i / n * .9);
    g.beginPath(); g.moveTo(...P(0, .28)); g.lineTo(Math.cos(a) * s * .33, Math.sin(a) * s * .33 + s * .1); g.stroke();
  }
  // القاعدة
  g.fillStyle = '#ffb59e'; g.strokeStyle = '#a24a36';
  g.beginPath(); g.moveTo(...P(-.12, .27)); g.lineTo(...P(.12, .27)); g.lineTo(...P(.08, .35)); g.lineTo(...P(-.08, .35)); g.closePath(); g.fill(); g.stroke();
  shine(g, -s * .12, -s * .1, s * .06, s * .03, .6, -.5);
}

// 13 — لقيمات (حلوى بالعسل)
function luqaimat(g, s){
  shadow(g, s, .28);
  const P = (x, y) => [x * s, y * s];
  // صحن
  g.fillStyle = '#e9f4f2'; g.strokeStyle = '#2a8a7e'; g.lineWidth = s * .025;
  g.beginPath(); g.ellipse(0, s * .2, s * .38, s * .12, 0, 0, TAU); g.fill(); g.stroke();
  g.strokeStyle = 'rgba(42,138,126,.5)'; g.lineWidth = s * .012;
  g.beginPath(); g.ellipse(0, s * .2, s * .3, s * .085, 0, 0, TAU); g.stroke();
  const ball = (x, y, r) => {
    const gr = g.createRadialGradient(x - r * .35, y - r * .4, r * .1, x, y, r);
    gr.addColorStop(0, '#ffe59a'); gr.addColorStop(.6, '#e09a2a'); gr.addColorStop(1, '#9a5a0e');
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill();
    g.strokeStyle = 'rgba(110,60,6,.5)'; g.lineWidth = s * .012; g.stroke();
    shine(g, x - r * .35, y - r * .4, r * .25, r * .15, .8, -.5);
  };
  ball(...P(-.15, .1), s * .12); ball(...P(.15, .1), s * .12); ball(...P(0, .14), s * .12);
  ball(...P(-.07, -.06), s * .12); ball(...P(.08, -.05), s * .12); ball(...P(0, -.2), s * .11);
  // عسل وسمسم
  g.strokeStyle = 'rgba(160,80,0,.75)'; g.lineWidth = s * .025; g.lineCap = 'round';
  g.beginPath(); g.moveTo(...P(-.2, .02)); g.bezierCurveTo(...P(-.05, -.12), ...P(.05, .12), ...P(.2, -.02)); g.stroke();
  g.fillStyle = '#fff8e0';
  [[-.1, -.12], [.06, -.18], [.12, .02], [-.04, .06], [.02, -.28]].forEach(([x, y]) => { g.beginPath(); g.ellipse(...P(x, y), s * .015, s * .008, .5, 0, TAU); g.fill(); });
}

const FN = [pearl, date, dallah, perfume, rose, emerald, finjan, mabkhara, ring, lantern, palm, bangle, shell, luqaimat];
const NAMES = ['لؤلؤة', 'تمرة', 'دلّة', 'عطر', 'وردة', 'زمرد', 'فنجان', 'مبخرة', 'خاتم', 'فانوس', 'نخلة', 'إسوارة', 'صدفة', 'لقيمات'];
function draw(g, t, s){ FN[t % FN.length](g, s); }
function image(t, px){
  const c = document.createElement('canvas'); c.width = c.height = px;
  const g = c.getContext('2d'); g.translate(px / 2, px / 2); draw(g, t, px);
  return c;
}
window.Art = { draw, image, sparkle, NAMES, COUNT: FN.length };
})();
