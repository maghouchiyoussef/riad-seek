window.CH = window.CH || [];
CH.push(
{ id:'musa', icon:'🌊', c1:'#1565c0', c2:'#0a3a7a', name:['Musa (Moses)','موسى'],
  story:[
   ['Pharaoh was a cruel ruler. When Musa was born, Allah inspired his mother to place him in the river for his safety.','كان فرعون حاكمًا ظالمًا. ولما وُلد موسى ألهم الله أمه أن تضعه في النهر حفظًا له.'],
   ['Musa was raised in Pharaoh\'s palace, and Allah returned him to his mother. Later he left Egypt and went to Madyan.','نشأ موسى في قصر فرعون، وردّه الله إلى أمه. ثم خرج من مصر إلى مدين.'],
   ['At Mount Tur, Allah spoke to him and gave him a staff and clear signs. His brother Harun was sent to help him.','عند جبل الطور كلّمه الله وأعطاه العصا وآيات واضحة، وأرسل معه أخاه هارون.'],
   ['Allah told Musa to strike the sea with his staff. The sea split, Musa and his people crossed, and Pharaoh was drowned.','أمر الله موسى أن يضرب البحر بعصاه فانفلق، فعبر موسى وقومه وغرق فرعون.']],
  qs:[
   {q:['Where did Musa\'s mother place him?','أين وضعت أم موسى ابنها؟'],o:[['In the river','في النهر'],['In a cave','في كهف'],['On a mountain','على جبل'],['In a tent','في خيمة']],c:0},
   {q:['Who helped Musa as a prophet?','من عاون موسى في الرسالة؟'],o:[['His brother Harun','أخوه هارون'],['Ibrahim','إبراهيم'],['Yusuf','يوسف'],['Yaqub','يعقوب']],c:0},
   {q:['What did Musa hold as a sign?','ماذا حمل موسى كآية؟'],o:[['A staff','عصا'],['A sword','سيف'],['A lamp','مصباح'],['A book','كتاب']],c:0},
   {q:['What happened when he struck the sea?','ماذا حدث حين ضرب البحر؟'],o:[['It split open','انفلق'],['It froze','تجمد'],['It dried up','جف'],['It turned red','احمر']],c:0},
   {q:['What happened to Pharaoh?','ماذا حدث لفرعون؟'],o:[['He drowned','غرق'],['He escaped','نجا'],['He believed and left','آمن وهاجر'],['He became king of Sinai','حكم سيناء']],c:0}]},

{ id:'dawud', icon:'🎵', c1:'#6d4c9f', c2:'#3b2670', name:['Dawud (David)','داود'],
  story:[
   ['As a young man, Dawud faced Jalut (Goliath), a mighty warrior, with faith in Allah.','واجه داود وهو فتى الجبار جالوت متوكلًا على الله.'],
   ['With Allah\'s help, he defeated Jalut. Later Allah gave him kingship and wisdom.','وبعون الله هزم جالوت، ثم آتاه الله الملك والحكمة.'],
   ['Allah gave him the Zabur (Psalms), and made iron soft in his hands so he could make armor.','وآتاه الله الزبور، وأَلان له الحديد ليصنع منه الدروع.'],
   ['The mountains and the birds glorified Allah along with him. He was always turning back to Allah.','وسخّر معه الجبال والطير يسبّحن، وكان كثير الرجوع إلى الله.']],
  qs:[
   {q:['Whom did Dawud defeat?','من هزم داود؟'],o:[['Jalut (Goliath)','جالوت'],['Pharaoh','فرعون'],['Qarun','قارون'],['Haman','هامان']],c:0},
   {q:['Which book was given to Dawud?','أي كتاب أُوتي داود؟'],o:[['The Zabur','الزبور'],['The Injil','الإنجيل'],['The Torah','التوراة'],['The Quran','القرآن']],c:0},
   {q:['What did Allah soften for him?','ماذا ألان الله له؟'],o:[['Iron','الحديد'],['Stone','الحجر'],['Wood','الخشب'],['Gold','الذهب']],c:0},
   {q:['Who glorified Allah along with him?','من سبّح مع داود؟'],o:[['Mountains and birds','الجبال والطير'],['Rivers','الأنهار'],['Stars','النجوم'],['Winds','الرياح']],c:0},
   {q:['What gift did Allah give him besides kingship?','ما العطية بجانب الملك؟'],o:[['Wisdom','الحكمة'],['A palace of glass','قصر من زجاج'],['A flying carpet','بساط يطير'],['A second sun','شمس ثانية']],c:0}]},

{ id:'sulayman', icon:'🐜', c1:'#0e7c86', c2:'#064e56', name:['Sulayman (Solomon)','سليمان'],
  story:[
   ['Sulayman, the son of Dawud, was a king and a prophet. Allah taught him the speech of birds and gave him the wind and the jinn to serve him.','كان سليمان بن داود ملكًا ونبيًّا، علّمه الله منطق الطير وسخّر له الريح والجن.'],
   ['Once, he passed by a valley of ants. An ant told the others to enter their homes so they would not be crushed. Sulayman smiled and thanked Allah.','مرّ مرة بوادي النمل، فقالت نملة: ادخلوا مساكنكم لا يحطمنكم سليمان وجنوده، فتبسم وشكر الله.'],
   ['The hoopoe bird brought news of the Queen of Saba, whose people worshipped the sun. Sulayman sent her a letter inviting her to Allah.','جاء الهدهد بخبر ملكة سبأ التي يسجد قومها للشمس، فأرسل إليها سليمان كتابًا يدعوها إلى الله.'],
   ['The Queen saw his wisdom and submitted to Allah, the Lord of all the worlds.','رأت الملكة حكمته فأسلمت مع سليمان لله رب العالمين.']],
  qs:[
   {q:['What language did Sulayman understand?','ماذا فهم سليمان؟'],o:[['The speech of birds','منطق الطير'],['Only Hebrew','العبرية فقط'],['Sign language','لغة الإشارة'],['None','لا شيء']],c:0},
   {q:['Which small creature warned the others about him?','أي مخلوق صغير حذّر الآخرين منه؟'],o:[['An ant','نملة'],['A bee','نحلة'],['A spider','عنكبوت'],['A fly','ذبابة']],c:0},
   {q:['Which bird brought news of Saba?','أي طائر أتى بخبر سبأ؟'],o:[['The hoopoe','الهدهد'],['The crow','الغراب'],['The eagle','النسر'],['The dove','الحمامة']],c:0},
   {q:['What did the Queen\'s people worship?','ماذا عبد قوم الملكة؟'],o:[['The sun','الشمس'],['The moon','القمر'],['Idols of stone','أصنامًا'],['Fire','النار']],c:0},
   {q:['How did Sulayman respond to his blessings?','كيف قابل سليمان النعم؟'],o:[['He thanked Allah','شكر الله'],['He became proud','تكبر'],['He hid them','أخفاها'],['He forgot them','نسيها']],c:0}]},

{ id:'yunus', icon:'🐋', c1:'#1e5aa8', c2:'#0b2f66', name:['Yunus (Jonah)','يونس'],
  story:[
   ['Yunus was sent to the people of Nineveh. After calling them for a long time, he became upset and left before Allah allowed him.','أُرسل يونس إلى أهل نينوى، وبعد أن دعاهم طويلًا غضب وغادر قبل أن يأذن الله له.'],
   ['He boarded a ship. A storm came, and lots were cast. He was thrown into the sea, and a big fish swallowed him.','ركب سفينة فهبّت عاصفة، فأُقرع بينهم فألقي في البحر، فالتقمه الحوت.'],
   ['In the darkness he called: "There is no god but You, glory be to You, I was among the wrongdoers."','فنادى في الظلمات: لا إله إلا أنت سبحانك إني كنت من الظالمين.'],
   ['Allah accepted his prayer and saved him. His people believed, and Allah gave them comfort for a time.','فاستجاب الله له ونجّاه، وآمن قومه فمتّعهم الله إلى حين.']],
  qs:[
   {q:['Which city was Yunus sent to?','إلى أي مدينة أُرسل يونس؟'],o:[['Nineveh','نينوى'],['Babylon','بابل'],['Makkah','مكة'],['Cairo','القاهرة']],c:0},
   {q:['What swallowed Yunus?','ماذا ابتلع يونس؟'],o:[['A big fish','حوت'],['A snake','ثعبان'],['A wave','موجة'],['A cave','كهف']],c:0},
   {q:['What did he say in the darkness?','ماذا قال في الظلمات؟'],o:[['There is no god but You, glory be to You','لا إله إلا أنت سبحانك'],['Save me, people','أنقذوني يا قوم'],['I do not care','لا أبالي'],['Nothing','لم يقل شيئًا']],c:0},
   {q:['What was the result of his prayer?','ما نتيجة دعائه؟'],o:[['Allah saved him','نجّاه الله'],['It was refused','لم يُستجب'],['He stayed inside','بقي في الحوت'],['He lost his voice','فقد صوته']],c:0},
   {q:['What did Yunus\'s people do in the end?','ماذا فعل قوم يونس في النهاية؟'],o:[['They believed','آمنوا'],['They left','رحلوا'],['They fought','قاتلوا'],['They sailed away','أبحروا']],c:0}]},

{ id:'zakariya', icon:'🤲', c1:'#7a5c2e', c2:'#46300f', name:['Zakariya (Zechariah)','زكريا'],
  story:[
   ['Zakariya was an old man, and his wife was unable to have children. He had no heir.','كان زكريا شيخًا كبيرًا، وكانت امرأته عاقرًا، ولم يكن له ولد.'],
   ['He took care of Maryam in the prayer room. He saw that Allah provided her with food out of season.','كفل مريم في المحراب، ورأى أن الله يرزقها بفاكهة في غير أوانها.'],
   ['That made him hopeful. He prayed quietly to Allah: "My Lord, grant me a pure child from You."','فطمع في رحمة الله، ودعا ربه سرًّا: رب هب لي من لدنك ذرية طيبة.'],
   ['Angels gave him the good news of a son named Yahya. His sign was that he would not speak to people for three days, except by gestures.','بشّرته الملائكة بغلام اسمه يحيى، وآيته ألا يكلم الناس ثلاثة أيام إلا رمزًا.']],
  qs:[
   {q:['Whom did Zakariya take care of?','من كفل زكريا؟'],o:[['Maryam','مريم'],['Hajar','هاجر'],['Asiya','آسية'],['Sarah','سارة']],c:0},
   {q:['What did he ask Allah for?','ماذا طلب من الله؟'],o:[['A pure child','ذرية طيبة'],['Wealth','مالًا'],['A kingdom','ملكًا'],['A house','بيتًا']],c:0},
   {q:['How did he pray?','كيف دعا؟'],o:[['Quietly','سرًّا'],['Loudly in the market','جهرًا في السوق'],['Without words','بلا كلمات'],['In a crowd','في جمع كبير']],c:0},
   {q:['What was the name of his son?','ما اسم ابنه؟'],o:[['Yahya','يحيى'],['Isa','عيسى'],['Yusuf','يوسف'],['Ismail','إسماعيل']],c:0},
   {q:['What was his sign?','ما كانت آيته؟'],o:[['Not speaking to people for three days','ألا يكلم الناس ثلاثًا'],['Seeing in the dark','يرى في الظلام'],['Flying','يطير'],['Becoming young','يعود شابًّا']],c:0}]},

{ id:'yahya', icon:'📜', c1:'#2f7d6d', c2:'#14463c', name:['Yahya (John)','يحيى'],
  story:[
   ['Yahya was given as a gift to Zakariya. No one before him had been given that name.','كان يحيى هبة لزكريا، ولم يُسمَّ أحد قبله بهذا الاسم.'],
   ['Allah said to him, "Hold firmly to the Book." He gave him wisdom while he was still a child.','قال الله له: يا يحيى خذ الكتاب بقوة، وآتاه الحكم صبيًّا.'],
   ['He was kind, pure and very good to his parents. He was never arrogant or disobedient.','وكان رحيمًا طاهرًا بارًّا بوالديه، ولم يكن جبارًا عصيًّا.'],
   ['Peace was upon him the day he was born, the day he dies and the day he is raised again.','وسلام عليه يوم وُلد ويوم يموت ويوم يُبعث حيًّا.']],
  qs:[
   {q:['Who was Yahya\'s father?','من أبو يحيى؟'],o:[['Zakariya','زكريا'],['Ibrahim','إبراهيم'],['Dawud','داود'],['Imran','عمران']],c:0},
   {q:['What was given to him as a child?','ماذا أُعطي وهو صبي؟'],o:[['Wisdom','الحكم'],['A kingdom','ملك'],['A ship','سفينة'],['Great wealth','ثروة']],c:0},
   {q:['How was he towards his parents?','كيف كان مع والديه؟'],o:[['Dutiful and kind','بارًّا رحيمًا'],['Rude','فظًّا'],['Distant','بعيدًا'],['Strict','قاسيًا']],c:0},
   {q:['What did Allah tell him to hold firmly?','ما الذي أمره الله أن يأخذه بقوة؟'],o:[['The Book','الكتاب'],['The staff','العصا'],['A sword','سيفًا'],['The rope','الحبل']],c:0},
   {q:['What was special about his name?','ما الميزة في اسمه؟'],o:[['No one before him had it','لم يُسمَّ به أحد قبله'],['It was Nuh\'s old name','كان اسمًا قديمًا لنوح'],['It was a city name','كان اسم مدينة'],['It meant a king','كان يعني ملكًا']],c:0}]},

{ id:'isa', icon:'🕊️', c1:'#4f6fb0', c2:'#27427d', name:['Isa (Jesus)','عيسى'],
  story:[
   ['Maryam was a pure and devout woman. By Allah\'s command, she gave birth to Isa without a father, as a sign for the people.','كانت مريم طاهرة عابدة، فولدت عيسى بأمر الله بلا أب آيةً للناس.'],
   ['As a baby in the cradle, Isa spoke: "I am the servant of Allah. He has given me the Book and made me a prophet."','تكلم عيسى في المهد: إني عبد الله آتاني الكتاب وجعلني نبيًّا.'],
   ['By Allah\'s permission, he healed the blind and the sick, brought the dead back to life and shaped a bird from clay that flew.','وبإذن الله أبرأ الأكمه والأبرص وأحيا الموتى وصنع من الطين طيرًا فنفخ فيه فصار طيرًا.'],
   ['His disciples asked for a table of food from heaven, and Allah sent it. Isa called people to worship Allah alone.','وطلب الحواريون مائدة من السماء فأنزلها الله، ودعا عيسى الناس إلى عبادة الله وحده.']],
  qs:[
   {q:['Who was Isa\'s mother?','من أم عيسى؟'],o:[['Maryam','مريم'],['Hajar','هاجر'],['Asiya','آسية'],['Khadija','خديجة']],c:0},
   {q:['When did Isa first speak?','متى تكلم عيسى لأول مرة؟'],o:[['As a baby in the cradle','وهو طفل في المهد'],['At 10 years old','في العاشرة'],['At 30 years old','في الثلاثين'],['He never spoke','لم يتكلم']],c:0},
   {q:['What did Isa shape from clay?','ماذا صنع عيسى من الطين؟'],o:[['A bird','طيرًا'],['A statue','تمثالًا'],['A house','بيتًا'],['A camel','جملًا']],c:0},
   {q:['What did Isa\'s disciples ask for?','ماذا طلب الحواريون؟'],o:[['A table of food from heaven','مائدة من السماء'],['A kingdom','ملكًا'],['A new city','مدينة جديدة'],['Gold','ذهبًا']],c:0},
   {q:['Whom did Isa call people to worship?','إلى عبادة من دعا عيسى؟'],o:[['Allah alone','الله وحده'],['The sun','الشمس'],['Idols','الأصنام'],['Kings','الملوك']],c:0}]},

{ id:'muhammad', icon:'🕌', c1:'#0b6b4d', c2:'#053e2c', name:['Muhammad','محمد'],
  story:[
   ['Muhammad was born in Makkah and grew up an orphan. People knew him as Al-Amin, the trustworthy, and As-Sadiq, the truthful.','وُلد محمد في مكة ونشأ يتيمًا، وعُرف بين الناس بالأمين والصادق.'],
   ['In the Cave of Hira, the angel Jibril came to him with the first word: "Read!" That was the beginning of the revelation of the Quran.','في غار حراء جاءه جبريل بأول كلمة: اقرأ، فكانت بداية نزول القرآن.'],
   ['The Quran was revealed to him over about 23 years. He called people to worship Allah alone and to be kind and honest.','نزل عليه القرآن نحو ثلاث وعشرين سنة، ودعا إلى عبادة الله وحده وإلى الرحمة والأمانة.'],
   ['He migrated from Makkah to Madinah. He was sent as a mercy to all the worlds and is the last of the prophets.','هاجر من مكة إلى المدينة، وأُرسل رحمةً للعالمين، وهو خاتم الأنبياء.']],
  qs:[
   {q:['What was Muhammad known as?','بماذا عُرف محمد؟'],o:[['Al-Amin (the trustworthy)','الأمين'],['The warrior','المحارب'],['The rich one','الغني'],['The traveler','المسافر']],c:0},
   {q:['In which cave did the first revelation come?','في أي غار نزل الوحي الأول؟'],o:[['Hira','حراء'],['Thawr','ثور'],['Kahf','الكهف'],['Tur','الطور']],c:0},
   {q:['Which was the first word revealed?','ما أول كلمة نزلت؟'],o:[['Read (Iqra)','اقرأ'],['Pray','صلِّ'],['Fast','صُم'],['Give','أعطِ']],c:0},
   {q:['To which city did he migrate?','إلى أي مدينة هاجر؟'],o:[['Madinah','المدينة'],['Jerusalem','القدس'],['Damascus','دمشق'],['Taif','الطائف']],c:0},
   {q:['What is he to the prophets?','ما مكانته بين الأنبياء؟'],o:[['The last of them','خاتمهم'],['The first of them','أولهم'],['The only one','الوحيد'],['The middle one','أوسطهم']],c:0}]}
);
