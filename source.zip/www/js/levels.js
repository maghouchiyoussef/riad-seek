// المستويات: صورة + الأشياء المخبّية (الإحداثيات بالبيكسل فصورة 1024×1536)
window.LEVELS = [
{
"id": "kitchen",
"img": "scenes/kitchen.jpg",
"thumb": "scenes/kitchen-thumb.jpg",
"name": {
"ar": "المطبخ",
"fr": "La cuisine",
"en": "The Kitchen"
},
"objects": [
{
"id": "cat",
"n": {
"ar": "قطة",
"fr": "Chat",
"en": "Cat"
},
"boxes": [
[
770,
770,
985,
885
]
]
},
{
"id": "lantern",
"n": {
"ar": "فانوس",
"fr": "Lanterne",
"en": "Lantern"
},
"boxes": [
[
872,
485,
930,
585
],
[
215,
165,
290,
310
]
]
},
{
"id": "garlic",
"n": {
"ar": "ضفيرة ثوم",
"fr": "Tresse d'ail",
"en": "Garlic braid"
},
"boxes": [
[
425,
240,
480,
440
]
]
},
{
"id": "chili",
"n": {
"ar": "فلفل حار معلّق",
"fr": "Piments suspendus",
"en": "Hanging chilies"
},
"boxes": [
[
385,
225,
425,
490
]
]
},
{
"id": "mortar",
"n": {
"ar": "مهراس",
"fr": "Mortier",
"en": "Mortar"
},
"boxes": [
[
315,
825,
445,
950
]
]
},
{
"id": "rolling",
"n": {
"ar": "نشّابة العجين",
"fr": "Rouleau à pâtisserie",
"en": "Rolling pin"
},
"boxes": [
[
690,
1040,
780,
1092
],
[
780,
1085,
880,
1150
],
[
880,
1130,
980,
1190
]
]
},
{
"id": "steamer",
"n": {
"ar": "كسكاس",
"fr": "Couscoussier",
"en": "Couscous steamer"
},
"boxes": [
[
650,
470,
790,
660
]
]
},
{
"id": "pan",
"n": {
"ar": "مقلاة نحاسية",
"fr": "Poêle en cuivre",
"en": "Copper pan"
},
"boxes": [
[
480,
205,
575,
400
]
]
},
{
"id": "teapot",
"n": {
"ar": "براد أتاي",
"fr": "Théière",
"en": "Teapot"
},
"boxes": [
[
30,
570,
150,
735
]
]
},
{
"id": "olives",
"n": {
"ar": "زيتون",
"fr": "Olives",
"en": "Olives"
},
"boxes": [
[
440,
1105,
590,
1185
]
]
},
{
"id": "almonds",
"n": {
"ar": "لوز",
"fr": "Amandes",
"en": "Almonds"
},
"boxes": [
[
370,
1185,
510,
1270
]
]
},
{
"id": "chebakia",
"n": {
"ar": "شباكية",
"fr": "Chebakia",
"en": "Chebakia"
},
"boxes": [
[
575,
1070,
765,
1180
]
]
},
{
"id": "glass",
"n": {
"ar": "كأس أتاي",
"fr": "Verre à thé",
"en": "Tea glass"
},
"boxes": [
[
325,
1410,
385,
1495
]
]
},
{
"id": "lemon",
"n": {
"ar": "ليمونة",
"fr": "Citron",
"en": "Lemon"
},
"boxes": [
[
415,
1385,
478,
1460
]
]
},
{
"id": "sifter",
"n": {
"ar": "غربال",
"fr": "Tamis",
"en": "Sifter"
},
"boxes": [
[
805,
985,
990,
1092
]
]
},
{
"id": "ladle",
"n": {
"ar": "مغرفة مثقوبة",
"fr": "Écumoire",
"en": "Skimmer"
},
"boxes": [
[
700,
370,
770,
440
]
]
}
]
},
{
"id": "salon",
"img": "scenes/salon.jpg",
"thumb": "scenes/salon-thumb.jpg",
"name": {
"ar": "الصالون",
"fr": "Le salon",
"en": "The Living Room"
},
"objects": [
{
"id": "clock",
"n": {
"ar": "ساعة",
"fr": "Horloge",
"en": "Clock"
},
"boxes": [
[
140,
205,
255,
340
]
]
},
{
"id": "chandelier",
"n": {
"ar": "ثريا",
"fr": "Lustre",
"en": "Chandelier"
},
"boxes": [
[
480,
0,
610,
290
]
]
},
{
"id": "walllamp",
"n": {
"ar": "فانوس الحائط",
"fr": "Lanterne murale",
"en": "Wall lantern"
},
"boxes": [
[
648,
265,
700,
405
]
]
},
{
"id": "frame",
"n": {
"ar": "لوحة خط عربي",
"fr": "Calligraphie",
"en": "Calligraphy frame"
},
"boxes": [
[
730,
225,
880,
450
]
]
},
{
"id": "mirror",
"n": {
"ar": "مرآة",
"fr": "Miroir",
"en": "Mirror"
},
"boxes": [
[
908,
150,
1024,
605
]
]
},
{
"id": "fan",
"n": {
"ar": "مروحة يدوية",
"fr": "Éventail",
"en": "Hand fan"
},
"boxes": [
[
770,
495,
880,
610
]
]
},
{
"id": "tambourine",
"n": {
"ar": "طعريجة",
"fr": "Tambourin",
"en": "Tambourine"
},
"boxes": [
[
855,
575,
940,
675
]
]
},
{
"id": "oud",
"n": {
"ar": "عود",
"fr": "Oud",
"en": "Oud"
},
"boxes": [
[
820,
670,
1024,
980
]
]
},
{
"id": "cat",
"n": {
"ar": "قطة",
"fr": "Chat",
"en": "Cat"
},
"boxes": [
[
650,
770,
805,
855
]
]
},
{
"id": "teapot",
"n": {
"ar": "براد أتاي",
"fr": "Théière",
"en": "Teapot"
},
"boxes": [
[
385,
830,
470,
960
]
]
},
{
"id": "dates",
"n": {
"ar": "تمر",
"fr": "Dattes",
"en": "Dates"
},
"boxes": [
[
578,
885,
680,
970
]
]
},
{
"id": "babouches",
"n": {
"ar": "بلغة",
"fr": "Babouches",
"en": "Slippers"
},
"boxes": [
[
205,
1215,
380,
1350
]
]
},
{
"id": "chess",
"n": {
"ar": "شطرنج",
"fr": "Échecs",
"en": "Chess"
},
"boxes": [
[
372,
1280,
640,
1495
]
]
},
{
"id": "oillamp",
"n": {
"ar": "قنديل زيت",
"fr": "Lampe à huile",
"en": "Oil lamp"
},
"boxes": [
[
0,
1085,
130,
1420
]
]
},
{
"id": "candle",
"n": {
"ar": "شمعة",
"fr": "Bougie",
"en": "Candle"
},
"boxes": [
[
123,
762,
150,
815
],
[
140,
1370,
190,
1450
]
]
},
{
"id": "quran",
"n": {
"ar": "حامل المصحف",
"fr": "Support de Coran",
"en": "Book stand"
},
"boxes": [
[
388,
622,
480,
695
]
]
},
{
"id": "books",
"n": {
"ar": "كتب",
"fr": "Livres",
"en": "Books"
},
"boxes": [
[
670,
1190,
865,
1480
]
]
},
{
"id": "jug",
"n": {
"ar": "إبريق فخار",
"fr": "Cruche",
"en": "Jug"
},
"boxes": [
[
848,
1235,
1020,
1460
]
]
}
]
},
{
"id": "bedroom",
"img": "scenes/bedroom.jpg",
"thumb": "scenes/bedroom-thumb.jpg",
"name": {
"ar": "بيت النعاس",
"fr": "La chambre",
"en": "The Bedroom"
},
"objects": [
{
"id": "suitcase",
"n": {
"ar": "حقيبة سفر",
"fr": "Valise",
"en": "Suitcase"
},
"boxes": [
[
65,
20,
270,
130
]
]
},
{
"id": "caftan",
"n": {
"ar": "قفطان",
"fr": "Caftan",
"en": "Caftan"
},
"boxes": [
[
75,
305,
250,
730
]
]
},
{
"id": "shawl",
"n": {
"ar": "شال",
"fr": "Châle",
"en": "Shawl"
},
"boxes": [
[
240,
160,
335,
550
]
]
},
{
"id": "basket",
"n": {
"ar": "سلة الغسيل",
"fr": "Panier à linge",
"en": "Laundry basket"
},
"boxes": [
[
75,
720,
270,
880
]
]
},
{
"id": "teddy",
"n": {
"ar": "دبدوب",
"fr": "Ours en peluche",
"en": "Teddy bear"
},
"boxes": [
[
25,
835,
145,
1010
]
]
},
{
"id": "alarm",
"n": {
"ar": "منبّه",
"fr": "Réveil",
"en": "Alarm clock"
},
"boxes": [
[
440,
475,
500,
570
]
]
},
{
"id": "lamp",
"n": {
"ar": "مصباح",
"fr": "Lampe",
"en": "Lamp"
},
"boxes": [
[
480,
385,
580,
565
]
]
},
{
"id": "candle",
"n": {
"ar": "شمعة",
"fr": "Bougie",
"en": "Candle"
},
"boxes": [
[
565,
500,
605,
575
]
]
},
{
"id": "wallmirror",
"n": {
"ar": "مرآة الحائط",
"fr": "Miroir mural",
"en": "Wall mirror"
},
"boxes": [
[
525,
60,
645,
290
]
]
},
{
"id": "handmirror",
"n": {
"ar": "مرآة يدوية",
"fr": "Miroir à main",
"en": "Hand mirror"
},
"boxes": [
[
555,
735,
640,
800
]
]
},
{
"id": "jewelbox",
"n": {
"ar": "علبة المجوهرات",
"fr": "Boîte à bijoux",
"en": "Jewelry box"
},
"boxes": [
[
640,
775,
760,
910
]
]
},
{
"id": "perfume",
"n": {
"ar": "قارورة عطر",
"fr": "Flacon de parfum",
"en": "Perfume"
},
"boxes": [
[
738,
895,
805,
985
]
]
},
{
"id": "brush",
"n": {
"ar": "فرشاة الشعر",
"fr": "Brosse",
"en": "Hairbrush"
},
"boxes": [
[
565,
835,
625,
940
]
]
},
{
"id": "glasses",
"n": {
"ar": "نظارات",
"fr": "Lunettes",
"en": "Glasses"
},
"boxes": [
[
455,
780,
570,
870
]
]
},
{
"id": "book",
"n": {
"ar": "كتاب",
"fr": "Livre",
"en": "Book"
},
"boxes": [
[
335,
770,
470,
850
]
]
},
{
"id": "cat",
"n": {
"ar": "قطة",
"fr": "Chat",
"en": "Cat"
},
"boxes": [
[
770,
740,
940,
850
]
]
},
{
"id": "flowers",
"n": {
"ar": "باقة ورد",
"fr": "Bouquet",
"en": "Flowers"
},
"boxes": [
[
840,
895,
1010,
1040
]
]
},
{
"id": "slippers",
"n": {
"ar": "بلغة",
"fr": "Babouches",
"en": "Slippers"
},
"boxes": [
[
205,
1200,
445,
1390
]
]
},
{
"id": "teapot",
"n": {
"ar": "براد أتاي",
"fr": "Théière",
"en": "Teapot"
},
"boxes": [
[
605,
1005,
810,
1150
]
]
},
{
"id": "car",
"n": {
"ar": "سيارة لعبة",
"fr": "Voiture jouet",
"en": "Toy car"
},
"boxes": [
[
430,
1305,
535,
1425
]
]
}
]
},
{
"id": "souk",
"img": "scenes/souk.jpg",
"thumb": "scenes/souk-thumb.jpg",
"name": {
"ar": "السوق",
"fr": "Le souk",
"en": "The Souk"
},
"objects": [
{
"id": "cat",
"n": {
"ar": "قطة",
"fr": "Chat",
"en": "Cat"
},
"boxes": [
[
15,
1030,
345,
1190
]
]
},
{
"id": "greenlamp",
"n": {
"ar": "فانوس أخضر",
"fr": "Lanterne verte",
"en": "Green lantern"
},
"boxes": [
[
878,
245,
948,
345
]
]
},
{
"id": "redspice",
"n": {
"ar": "توابل حمراء",
"fr": "Épices rouges",
"en": "Red spice"
},
"boxes": [
[
335,
780,
470,
870
]
]
},
{
"id": "perfume",
"n": {
"ar": "قوارير العطر",
"fr": "Flacons de parfum",
"en": "Perfume bottles"
},
"boxes": [
[
355,
880,
655,
1060
]
]
},
{
"id": "beads",
"n": {
"ar": "مسبحة",
"fr": "Chapelet",
"en": "Prayer beads"
},
"boxes": [
[
470,
1060,
545,
1100
]
]
},
{
"id": "tagine",
"n": {
"ar": "طاجين",
"fr": "Tajine",
"en": "Tagine"
},
"boxes": [
[
260,
1230,
380,
1385
]
]
},
{
"id": "bluevase",
"n": {
"ar": "مزهرية زرقاء",
"fr": "Vase bleu",
"en": "Blue vase"
},
"boxes": [
[
350,
1210,
470,
1360
]
]
},
{
"id": "teapot",
"n": {
"ar": "براد أتاي",
"fr": "Théière",
"en": "Teapot"
},
"boxes": [
[
30,
780,
200,
985
]
]
},
{
"id": "dates",
"n": {
"ar": "تمر",
"fr": "Dattes",
"en": "Dates"
},
"boxes": [
[
495,
1150,
695,
1275
]
]
},
{
"id": "roses",
"n": {
"ar": "ورد مجفف",
"fr": "Pétales de rose",
"en": "Dried roses"
},
"boxes": [
[
515,
1310,
750,
1450
]
]
},
{
"id": "figs",
"n": {
"ar": "تين مجفف",
"fr": "Figues sèches",
"en": "Dried figs"
},
"boxes": [
[
770,
1360,
1000,
1480
]
]
},
{
"id": "chest",
"n": {
"ar": "صندوق أخضر",
"fr": "Coffre vert",
"en": "Green chest"
},
"boxes": [
[
828,
1010,
1024,
1130
]
]
},
{
"id": "tray",
"n": {
"ar": "طبق مجدول",
"fr": "Plateau tressé",
"en": "Woven plate"
},
"boxes": [
[
920,
770,
1024,
980
]
]
},
{
"id": "biglamp",
"n": {
"ar": "فانوس ذهبي",
"fr": "Grande lanterne",
"en": "Gold lantern"
},
"boxes": [
[
210,
50,
380,
250
]
]
},
{
"id": "starlamp",
"n": {
"ar": "فانوس نجمة",
"fr": "Lanterne étoile",
"en": "Star lantern"
},
"boxes": [
[
360,
365,
440,
455
]
]
},
{
"id": "babouche",
"n": {
"ar": "بلغة زرقاء",
"fr": "Babouche turquoise",
"en": "Teal slipper"
},
"boxes": [
[
108,
440,
175,
540
]
]
},
{
"id": "amulet",
"n": {
"ar": "فانوس صغير",
"fr": "Petite lanterne",
"en": "Small lantern"
},
"boxes": [
[
105,
1305,
210,
1470
]
]
}
]
},
{
"id": "hammam",
"img": "scenes/hammam.jpg",
"thumb": "scenes/hammam-thumb.jpg",
"name": {
"ar": "الحمّام",
"fr": "Le hammam",
"en": "The Hammam"
},
"objects": [
{
"id": "walllamp",
"n": {
"ar": "فانوس الحائط",
"fr": "Lanterne murale",
"en": "Wall lantern"
},
"boxes": [
[
110,
165,
195,
360
]
]
},
{
"id": "towels",
"n": {
"ar": "فوطات خضراء",
"fr": "Serviettes vertes",
"en": "Teal towels"
},
"boxes": [
[
220,
95,
425,
700
]
]
},
{
"id": "jug",
"n": {
"ar": "إبريق نحاسي",
"fr": "Cruche en cuivre",
"en": "Copper jug"
},
"boxes": [
[
68,
605,
200,
760
]
]
},
{
"id": "bucket",
"n": {
"ar": "سطل خشبي",
"fr": "Seau en bois",
"en": "Wooden bucket"
},
"boxes": [
[
0,
760,
270,
1090
]
]
},
{
"id": "candle",
"n": {
"ar": "شمعة",
"fr": "Bougie",
"en": "Candle"
},
"boxes": [
[
365,
730,
400,
790
]
]
},
{
"id": "oils",
"n": {
"ar": "قوارير الزيت",
"fr": "Flacons d'huile",
"en": "Oil bottles"
},
"boxes": [
[
375,
675,
525,
810
]
]
},
{
"id": "soap",
"n": {
"ar": "صابون بلدي",
"fr": "Savon noir",
"en": "Black soap"
},
"boxes": [
[
562,
780,
640,
835
]
]
},
{
"id": "cat",
"n": {
"ar": "قطة",
"fr": "Chat",
"en": "Cat"
},
"boxes": [
[
700,
690,
830,
910
]
]
},
{
"id": "stack",
"n": {
"ar": "فوطات مطوية",
"fr": "Serviettes roulées",
"en": "Rolled towels"
},
"boxes": [
[
845,
645,
1024,
900
]
]
},
{
"id": "basin",
"n": {
"ar": "طشت نحاسي",
"fr": "Bassin en cuivre",
"en": "Copper basin"
},
"boxes": [
[
462,
970,
755,
1190
]
]
},
{
"id": "greenbottle",
"n": {
"ar": "قارورة خضراء",
"fr": "Bouteille verte",
"en": "Green bottle"
},
"boxes": [
[
890,
1015,
985,
1225
]
]
},
{
"id": "redbottle",
"n": {
"ar": "قارورة حمراء",
"fr": "Petit flacon rouge",
"en": "Red bottle"
},
"boxes": [
[
657,
1085,
735,
1215
]
]
},
{
"id": "box",
"n": {
"ar": "علبة",
"fr": "Boîte",
"en": "Box"
},
"boxes": [
[
360,
1110,
525,
1255
]
]
},
{
"id": "soapbowl",
"n": {
"ar": "صحن الصابون",
"fr": "Bol de savon",
"en": "Soap bowl"
},
"boxes": [
[
515,
1210,
690,
1305
]
]
},
{
"id": "glove",
"n": {
"ar": "كيس الحمّام",
"fr": "Gant kessa",
"en": "Kessa glove"
},
"boxes": [
[
685,
1235,
870,
1355
]
]
},
{
"id": "loofah",
"n": {
"ar": "ليفة",
"fr": "Éponge",
"en": "Loofah"
},
"boxes": [
[
672,
1380,
865,
1495
]
]
},
{
"id": "rosepetal",
"n": {
"ar": "وردة",
"fr": "Pétale de rose",
"en": "Rose petal"
},
"boxes": [
[
865,
1345,
935,
1395
]
]
},
{
"id": "shelf",
"n": {
"ar": "قلل على الرف",
"fr": "Pots sur l'étagère",
"en": "Shelf jars"
},
"boxes": [
[
8,
325,
140,
465
]
]
}
]
},
{
"id": "rooftop",
"img": "scenes/rooftop.jpg",
"thumb": "scenes/rooftop-thumb.jpg",
"name": {
"ar": "السطح",
"fr": "La terrasse",
"en": "The Rooftop"
},
"objects": [
{
"id": "birdcage",
"n": {
"ar": "قفص عصفور",
"fr": "Cage à oiseau",
"en": "Birdcage"
},
"boxes": [
[
70,
60,
190,
350
]
]
},
{
"id": "pigeon",
"n": {
"ar": "حمامة",
"fr": "Pigeon",
"en": "Pigeon"
},
"boxes": [
[
35,
510,
130,
615
]
]
},
{
"id": "hanglamp",
"n": {
"ar": "فانوس معلّق",
"fr": "Lanterne suspendue",
"en": "Hanging lantern"
},
"boxes": [
[
708,
95,
770,
295
]
]
},
{
"id": "minaret",
"n": {
"ar": "صومعة",
"fr": "Minaret",
"en": "Minaret"
},
"boxes": [
[
232,
165,
338,
510
]
]
},
{
"id": "jar",
"n": {
"ar": "جرة فخار",
"fr": "Jarre",
"en": "Clay jar"
},
"boxes": [
[
545,
470,
610,
585
]
]
},
{
"id": "floorlamp",
"n": {
"ar": "فانوس الأرض",
"fr": "Lanterne au sol",
"en": "Floor lantern"
},
"boxes": [
[
600,
735,
700,
945
]
]
},
{
"id": "guitar",
"n": {
"ar": "كيتار",
"fr": "Guitare",
"en": "Guitar"
},
"boxes": [
[
695,
900,
850,
1160
]
]
},
{
"id": "hat",
"n": {
"ar": "قبعة قش",
"fr": "Chapeau de paille",
"en": "Straw hat"
},
"boxes": [
[
865,
875,
995,
975
]
]
},
{
"id": "cats",
"n": {
"ar": "قطط نايمة",
"fr": "Chats endormis",
"en": "Sleeping cats"
},
"boxes": [
[
82,
1020,
238,
1120
]
]
},
{
"id": "teapot",
"n": {
"ar": "براد أتاي",
"fr": "Théière",
"en": "Teapot"
},
"boxes": [
[
435,
950,
605,
1135
]
]
},
{
"id": "glass",
"n": {
"ar": "كأس أتاي",
"fr": "Verre à thé",
"en": "Tea glass"
},
"boxes": [
[
345,
1065,
400,
1160
],
[
405,
1090,
458,
1185
],
[
570,
1090,
628,
1180
]
]
},
{
"id": "nuts",
"n": {
"ar": "صحن مكسّرات",
"fr": "Bol de noix",
"en": "Nut bowl"
},
"boxes": [
[
455,
1135,
550,
1205
]
]
},
{
"id": "books",
"n": {
"ar": "كتب",
"fr": "Livres",
"en": "Books"
},
"boxes": [
[
650,
1245,
840,
1380
]
]
},
{
"id": "cards",
"n": {
"ar": "ورق اللعب",
"fr": "Cartes",
"en": "Cards"
},
"boxes": [
[
190,
1455,
305,
1520
]
]
},
{
"id": "chest",
"n": {
"ar": "صندوق",
"fr": "Coffre",
"en": "Chest"
},
"boxes": [
[
0,
1250,
225,
1490
]
]
},
{
"id": "oranges",
"n": {
"ar": "برتقال",
"fr": "Oranges",
"en": "Oranges"
},
"boxes": [
[
875,
1225,
1024,
1385
]
]
},
{
"id": "plate",
"n": {
"ar": "صحن زخرفي",
"fr": "Assiette décorée",
"en": "Wall plate"
},
"boxes": [
[
950,
495,
1020,
600
]
]
},
{
"id": "finial",
"n": {
"ar": "مبخرة صغيرة",
"fr": "Petite lampe en laiton",
"en": "Brass lamp"
},
"boxes": [
[
215,
1195,
290,
1345
]
]
}
]
}
];
