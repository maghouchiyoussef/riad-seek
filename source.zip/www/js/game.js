// سدو — لعبة ألغاز الأشكال (Block Puzzle) بطابع خليجي
(function(){
'use strict';
const N8 = 8;
const N = window.Native;
const $ = s => document.querySelector(s);
const SHAPES = [
 [[1]],[[1,1]],[[1],[1]],[[1,1,1]],[[1],[1],[1]],[[1,1,1,1]],[[1],[1],[1],[1]],[[1,1,1,1,1]],[[1],[1],[1],[1],[1]],
 [[1,1],[1,1]],[[1,1,1],[1,1,1],[1,1,1]],[[1,1,1],[1,1,1]],[[1,1],[1,1],[1,1]],
 [[1,0],[1,0],[1,1]],[[0,1],[0,1],[1,1]],[[1,1,1],[1,0,0]],[[1,1,1],[0,0,1]],
 [[1,1],[1,0]],[[1,1],[0,1]],[[0,1],[1,1]],[[1,0],[1,1]],
 [[1,1,1],[0,1,0]],[[0,1,0],[1,1,1]],
 [[1,1,0],[0,1,1]],[[0,1,1],[1,1,0]]
];
const UNLOCK = [0, 300, 800];           // نقاط الأفضل المطلوبة لفتح كل ثيم
const store = {
  get(k, d){ try{ const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} },
};

let grid, pieces, score = 0, streak = 0, over = false, revived = false, dragging = null;
let best = store.get('sadu_best', 0);
let theme = store.get('sadu_theme', 0);
let sound = store.get('sadu_sound', true);
const cells = [];
const boardEl = $('#board'), trayEl = $('#tray');
for(let i = 0; i < N8 * N8; i++){ const d = document.createElement('div'); d.className = 'cell'; boardEl.appendChild(d); cells.push(d); }

/* ---------- مساعدات ---------- */
function toast(t){ const e = $('#toast'); e.textContent = t; e.classList.add('show'); clearTimeout(toast._t); toast._t = setTimeout(() => e.classList.remove('show'), 1600); }
function haptic(kind){
  try{
    if(!(N && N.isNative)) return;
    if(kind === 'ok') N.Haptics.notification({ type: N.NotificationType.Success });
    else N.Haptics.impact({ style: kind === 'big' ? N.ImpactStyle.Medium : N.ImpactStyle.Light });
  }catch(e){}
}
let actx;
function sfx(t){
  if(!sound) return;
  try{
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    if(actx.state === 'suspended') actx.resume();
    const o = actx.createOscillator(), g = actx.createGain();
    const f = { place:[330,.08], clear:[660,.25], combo:[880,.3], over:[180,.5], pick:[440,.04] }[t];
    o.frequency.value = f[0]; o.type = 'triangle';
    g.gain.setValueAtTime(.15, actx.currentTime);
    g.gain.exponentialRampToValueAtTime(.001, actx.currentTime + f[1]);
    o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + f[1]);
  }catch(e){}
}
function show(id){ document.querySelectorAll('.screen').forEach(s => s.classList.toggle('show', s.id === id)); }
function modal(html){ const m = $('#modal'); m.innerHTML = html; m.classList.add('show'); }
function closeModal(){ $('#modal').classList.remove('show'); }
function modalOpen(){ return $('#modal').classList.contains('show'); }

/* ---------- منطق اللعبة ---------- */
function emptyGrid(){ return Array.from({ length: N8 }, () => Array(N8).fill(-1)); }
function fits(s, r0, c0){
  for(let r = 0; r < s.length; r++) for(let c = 0; c < s[0].length; c++) if(s[r][c]){
    const rr = r0 + r, cc = c0 + c;
    if(rr < 0 || cc < 0 || rr >= N8 || cc >= N8 || grid[rr][cc] >= 0) return false;
  }
  return true;
}
function canPlaceAnywhere(s){
  for(let r = 0; r < N8; r++) for(let c = 0; c < N8; c++) if(fits(s, r, c)) return true;
  return false;
}
function randPiece(){ return { s: SHAPES[Math.floor(Math.random() * SHAPES.length)], c: Math.floor(Math.random() * 5), used: false }; }
function refill(){
  let p, tries = 0;
  do{ p = [randPiece(), randPiece(), randPiece()]; tries++; }
  while(tries < 40 && !p.some(x => canPlaceAnywhere(x.s)));   // دايماً قطعة وحدة على الأقل كاتدخل
  pieces = p; drawTray();
}
function newGame(){
  grid = emptyGrid(); score = 0; streak = 0; over = false; revived = false;
  closeModal(); refill(); render(); saveGame();
}
function saveGame(){
  if(over){ store.set('sadu_save', null); return; }
  store.set('sadu_save', { grid, pieces, score, streak, revived });
}
function loadGame(){
  const s = store.get('sadu_save', null);
  if(!s || !s.grid || !s.pieces) return false;
  grid = s.grid; pieces = s.pieces; score = s.score || 0; streak = s.streak || 0; revived = !!s.revived; over = false;
  drawTray(); render(); return true;
}
function render(){
  for(let r = 0; r < N8; r++) for(let c = 0; c < N8; c++){
    const v = grid[r][c];
    cells[r * N8 + c].className = 'cell' + (v >= 0 ? ' f k' + v : '');
  }
  $('#score').textContent = score; $('#best').textContent = best; $('#hbest').textContent = best;
}
function pieceEl(p, m){
  const e = document.createElement('div'); e.className = 'piece';
  e.style.gridTemplateColumns = `repeat(${p.s[0].length},${m}px)`;
  p.s.forEach(row => row.forEach(v => {
    const d = document.createElement('div'); d.className = 'pc ' + (v ? 'k' + p.c : 'e');
    d.style.width = d.style.height = m + 'px'; e.appendChild(d);
  }));
  return e;
}
function drawTray(){
  trayEl.innerHTML = '';
  pieces.forEach((p, i) => {
    const slot = document.createElement('div'); slot.className = 'slot';
    if(!p.used){
      const big = Math.max(p.s[0].length, p.s.length);
      const e = pieceEl(p, big >= 5 ? 16 : big >= 4 ? 19 : 23);
      e.addEventListener('pointerdown', ev => startDrag(ev, i, e));
      slot.appendChild(e);
    }
    trayEl.appendChild(slot);
  });
}
function cellSize(){ return cells[0].getBoundingClientRect().width; }
function startDrag(ev, i, src){
  if(over || dragging || modalOpen()) return;
  ev.preventDefault();
  const p = pieces[i], cs = cellSize();
  const f = pieceEl(p, cs); f.classList.add('drag'); document.body.appendChild(f);
  dragging = { i, p, f, cs, src }; src.style.opacity = .25; sfx('pick');
  moveDrag(ev);
  window.addEventListener('pointermove', moveDrag);
  window.addEventListener('pointerup', endDrag, { once: true });
  window.addEventListener('pointercancel', endDrag, { once: true });
}
function target(ev){
  const d = dragging, w = d.p.s[0].length * (d.cs + 3), h = d.p.s.length * (d.cs + 3);
  const fx = ev.clientX - w / 2, fy = ev.clientY - h - 60;
  const b = cells[0].getBoundingClientRect(), step = d.cs + 3;
  return { fx, fy, c: Math.round((fx - b.left) / step), r: Math.round((fy - b.top) / step) };
}
function clearHints(){ cells.forEach(e => e.classList.remove('g', 'bad')); }
function moveDrag(ev){
  if(!dragging) return;
  const t = target(ev);
  dragging.f.style.left = t.fx + 'px'; dragging.f.style.top = t.fy + 'px'; dragging.t = t;
  clearHints();
  const ok = fits(dragging.p.s, t.r, t.c);
  dragging.p.s.forEach((row, r) => row.forEach((v, c) => {
    if(!v) return; const rr = t.r + r, cc = t.c + c;
    if(rr >= 0 && cc >= 0 && rr < N8 && cc < N8 && grid[rr][cc] < 0) cells[rr * N8 + cc].classList.add(ok ? 'g' : 'bad');
  }));
}
function endDrag(){
  window.removeEventListener('pointermove', moveDrag);
  const d = dragging; dragging = null; if(!d) return;
  d.f.remove(); clearHints();
  const t = d.t;
  if(t && fits(d.p.s, t.r, t.c)) place(d, t); else d.src.style.opacity = 1;
}
function place(d, t){
  let n = 0;
  d.p.s.forEach((row, r) => row.forEach((v, c) => { if(v){ grid[t.r + r][t.c + c] = d.p.c; n++; } }));
  d.p.used = true; score += n; sfx('place'); haptic('light');
  const rows = [], cols = [];
  for(let r = 0; r < N8; r++) if(grid[r].every(v => v >= 0)) rows.push(r);
  for(let c = 0; c < N8; c++) if(grid.every(row => row[c] >= 0)) cols.push(c);
  const lines = rows.length + cols.length;
  render();
  if(lines){
    streak++;
    const kill = new Set();
    rows.forEach(r => { for(let c = 0; c < N8; c++) kill.add(r * N8 + c); });
    cols.forEach(c => { for(let r = 0; r < N8; r++) kill.add(r * N8 + c); });
    kill.forEach(i => cells[i].classList.add('clear'));
    score += lines * 10 * lines * Math.min(streak, 5);
    sfx(lines > 1 || streak > 1 ? 'combo' : 'clear'); haptic(lines > 1 ? 'ok' : 'big');
    const m = $('#msg');
    m.textContent = lines > 1 ? `ما شاء الله! ×${lines}` : streak > 1 ? `سلسلة ×${streak} 🔥` : 'أحسنتِ!';
    setTimeout(() => { m.textContent = ''; }, 1000);
    setTimeout(() => {
      rows.forEach(r => grid[r].fill(-1));
      cols.forEach(c => { for(let r = 0; r < N8; r++) grid[r][c] = -1; });
      render(); afterMove();
    }, 350);
  } else { streak = 0; afterMove(); }
  drawTray();
}
function afterMove(){
  if(pieces.every(p => p.used)) refill();
  if(score > best){ best = score; store.set('sadu_best', best); }
  render(); saveGame();
  const alive = pieces.filter(p => !p.used);
  if(!alive.some(p => canPlaceAnywhere(p.s))) gameOver();
}

/* ---------- نهاية اللعبة ---------- */
function gameOver(){
  over = true; saveGame(); sfx('over'); haptic('big');
  const newBest = score >= best && score > 0;
  const canRevive = !revived;
  modal(`
    <h2>انتهت اللعبة</h2>
    <div class="big">نقاطك: <b>${score}</b></div>
    ${newBest ? '<div class="ttl" style="font-size:24px;color:var(--gold)">🏆 رقم قياسي جديد!</div>' : `<div class="hint">أفضل نتيجة: ${best}</div>`}
    ${canRevive ? '<button class="btn" id="m-revive">🎬 كمّلي اللعب (فيديو قصير)</button>' : ''}
    <button class="btn" id="m-again">العبي مرة ثانية</button>
    <button class="btn alt" id="m-home">القائمة الرئيسية</button>`);
  if($('#m-revive')) $('#m-revive').onclick = revive;
  $('#m-again').onclick = async () => { await Ads.maybeInterstitial(); newGame(); };
  $('#m-home').onclick = async () => { await Ads.maybeInterstitial(); goHome(); };
}
async function revive(){
  if(Ads.isNative && !Ads.rewardedAvailable()){ toast('ما في فيديو الآن، حاولي بعد شوي'); return; }
  const ok = Ads.isNative ? await Ads.showRewarded() : true;
  if(!ok){ toast('لازم تكملين الفيديو للمكافأة'); return; }
  revived = true; over = false; closeModal();
  // نمسحو 3 صفوف الأكثر امتلاءً ونعطيو قطع جديدة
  const order = [...Array(N8).keys()].sort((a, b) => grid[b].filter(v => v >= 0).length - grid[a].filter(v => v >= 0).length);
  order.slice(0, 3).forEach(r => grid[r].fill(-1));
  streak = 0; refill(); render(); saveGame(); haptic('ok'); toast('كملي، بالتوفيق! 🎉');
}

/* ---------- الشاشات والإعدادات ---------- */
function applyTheme(){ document.body.className = 't' + theme; try{ N && N.isNative && N.StatusBar.setBackgroundColor({ color: ['#3d0f33', '#7a4a1c', '#0b2f3d'][theme] }); }catch(e){} }
function drawThemes(){
  const box = $('#themes'); box.innerHTML = '';
  [0, 1, 2].forEach(i => {
    const d = document.createElement('div');
    const locked = best < UNLOCK[i];
    d.className = 'th th' + i + (theme === i ? ' on' : '') + (locked ? ' lock' : '');
    d.onclick = () => {
      if(locked){ toast(`يتفتح لما توصلين ${UNLOCK[i]} نقطة`); return; }
      theme = i; store.set('sadu_theme', i); applyTheme(); drawThemes();
    };
    box.appendChild(d);
  });
}
function goHome(){
  closeModal(); show('home'); drawThemes();
  $('#play').textContent = store.get('sadu_save', null) ? 'كمّلي اللعب' : 'العبي';
  $('#snd').textContent = sound ? '🔊 الصوت' : '🔇 الصوت';
  $('#priv').style.display = Ads.privacyRequired ? '' : 'none';
  $('#hbest').textContent = best;
}
function startPlay(){
  show('game');
  if(!(store.get('sadu_save', null) && loadGame())) newGame();
  else { render(); }
}
function openMenu(){
  modal(`
    <h2>متوقفة مؤقتاً</h2>
    <button class="btn" id="m-resume">كمّلي</button>
    <button class="btn alt" id="m-new">لعبة جديدة</button>
    <button class="btn alt" id="m-home">القائمة الرئيسية</button>`);
  $('#m-resume').onclick = closeModal;
  $('#m-new').onclick = async () => { closeModal(); await Ads.maybeInterstitial(); newGame(); };
  $('#m-home').onclick = goHome;
}
$('#play').onclick = startPlay;
$('#menu').onclick = openMenu;
$('#snd').onclick = () => { sound = !sound; store.set('sadu_sound', sound); $('#snd').textContent = sound ? '🔊 الصوت' : '🔇 الصوت'; };
$('#priv').onclick = () => Ads.showPrivacyOptions();

/* ---------- تشغيل ---------- */
applyTheme(); goHome();
try{ N && N.isNative && N.StatusBar.setStyle({ style: N.Style.Dark }); }catch(e){}
try{ N.App.addListener('backButton', () => {
  if(modalOpen()){ if($('#m-resume')) closeModal(); return; }
  if($('#game').classList.contains('show')){ openMenu(); return; }
  N.App.exitApp();
}); }catch(e){}
try{
  N.App.addListener('pause', () => { if(actx) actx.suspend(); });
  N.App.addListener('resume', () => { if(actx) actx.resume(); });
}catch(e){}
Ads.init().finally(() => { $('#priv').style.display = Ads.privacyRequired ? '' : 'none'; Ads.showBanner(); try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} });
setTimeout(() => { try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} }, 2500);
})();
