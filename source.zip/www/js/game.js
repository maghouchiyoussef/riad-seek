// Sweet Pop — match-3 puzzle
(function(){
'use strict';
const N = window.Native;
const $ = (s) => document.querySelector(s);

/* ================= i18n ================= */
const T = {
  en:{ title:'Sweet Pop', sub:'Match 3 Puzzle', play:'PLAY', levels:'Levels', settings:'Settings', level:'LEVEL', moves:'MOVES',
    gScore:'Reach {n} points', gCollect:'Collect the candies', gJelly:'Clear all the jelly', go:"Let's go!",
    win:'Sweet!', fail:'Out of moves', failP:'So close! Get 5 more moves?', plus5:'+5 moves (watch ad)', retry:'Retry', next:'Next level', home:'Home', levelsBtn:'Levels',
    paused:'Paused', resume:'Resume', restart:'Restart', lang:'Language', sound:'Sound', on:'On', off:'Off', privacy:'Ad choices', close:'Close',
    hammerHint:'Tap a candy to smash it', shuffle:'Shuffle!', noMoves:'No more moves! Shuffling…', more:'Get 2 more (watch ad)', got:'+2!', boosters:'Boosters',
    adNo:'Ad not ready, try again soon', locked:'Finish the previous level first', score:'Score', stars:'Stars', best:'Best',
    praise:['Sweet!','Tasty!','Delicious!','Divine!','Sugar Rush!'], tut:'Swipe to swap two sweets', daily:'Daily gift!', dailyP:'Come back every day for free boosters', claim:'Claim' },
  fr:{ title:'Sweet Pop', sub:'Puzzle Match 3', play:'JOUER', levels:'Niveaux', settings:'Réglages', level:'NIVEAU', moves:'COUPS',
    gScore:'Atteins {n} points', gCollect:'Collecte les bonbons', gJelly:'Enlève toute la gelée', go:"C'est parti !",
    win:'Bravo !', fail:'Plus de coups', failP:'Presque ! 5 coups de plus ?', plus5:'+5 coups (voir une pub)', retry:'Rejouer', next:'Niveau suivant', home:'Accueil', levelsBtn:'Niveaux',
    paused:'Pause', resume:'Reprendre', restart:'Recommencer', lang:'Langue', sound:'Son', on:'Oui', off:'Non', privacy:'Choix pub', close:'Fermer',
    hammerHint:'Touche un bonbon pour le casser', shuffle:'Mélange !', noMoves:'Plus de coups possibles ! Mélange…', more:'2 de plus (voir une pub)', got:'+2 !', boosters:'Bonus',
    adNo:'Pub indisponible, réessaie bientôt', locked:"Termine d'abord le niveau précédent", score:'Score', stars:'Étoiles', best:'Record',
    praise:['Super !','Délicieux !','Génial !','Divin !','Sucre total !'], tut:'Glisse pour échanger deux bonbons', daily:'Cadeau du jour !', dailyP:'Reviens chaque jour pour des bonus gratuits', claim:'Récupérer' },
  ar:{ title:'سويت بوب', sub:'لعبة حلويات مطابقة', play:'العب', levels:'المستويات', settings:'الإعدادات', level:'المستوى', moves:'الحركات',
    gScore:'اجمع {n} نقطة', gCollect:'اجمع الحلويات', gJelly:'أزل كل الجيلي', go:'هيا بنا!',
    win:'رائع!', fail:'انتهت الحركات', failP:'قريب جدًا! تريد 5 حركات إضافية؟', plus5:'+5 حركات (شاهد إعلانًا)', retry:'إعادة', next:'المستوى التالي', home:'الرئيسية', levelsBtn:'المستويات',
    paused:'إيقاف مؤقت', resume:'متابعة', restart:'إعادة المستوى', lang:'اللغة', sound:'الصوت', on:'تشغيل', off:'إيقاف', privacy:'خيارات الإعلانات', close:'إغلاق',
    hammerHint:'المس حلوى لتكسرها', shuffle:'خلط!', noMoves:'لا توجد حركات! جاري الخلط…', more:'احصل على 2 (شاهد إعلانًا)', got:'+2!', boosters:'المساعدات',
    adNo:'الإعلان غير جاهز، جرّب بعد قليل', locked:'أكمل المستوى السابق أولًا', score:'النقاط', stars:'النجوم', best:'الأفضل',
    praise:['لذيذ!','رائع!','مذهل!','خرافي!','انفجار السكر!'], tut:'اسحب لتبديل حلوتين', daily:'هدية اليوم!', dailyP:'ارجع كل يوم لتحصل على مساعدات مجانية', claim:'استلام' }
};
const LANG_NAME = { en:'English', fr:'Français', ar:'العربية' };
let lang = 'en';
const t = (k) => T[lang][k];

/* ================= save ================= */
const MAX_LEVEL = 150;
function fresh(){ return { level:1, stars:{}, best:{}, hammer:3, shuffle:2, lang:null, sound:true, wins:0, gift:'' }; }
let SV = fresh();
function load(){
  try{
    const d = JSON.parse(localStorage.getItem('sp_save') || 'null');
    if(d){ SV = Object.assign(fresh(), d);
      if(!(SV.level >= 1 && SV.level <= MAX_LEVEL)) SV.level = 1;
      if(!SV.stars || typeof SV.stars !== 'object') SV.stars = {};
      if(!SV.best || typeof SV.best !== 'object') SV.best = {};
      if(!(SV.hammer >= 0)) SV.hammer = 3; if(!(SV.shuffle >= 0)) SV.shuffle = 2;
    }
  }catch(e){ SV = fresh(); }
}
function save(){ try{ localStorage.setItem('sp_save', JSON.stringify(SV)); }catch(e){} }
function detectLang(){
  if(SV.lang && T[SV.lang]) return SV.lang;
  const n = (navigator.language || 'en').toLowerCase();
  return n.startsWith('ar') ? 'ar' : n.startsWith('fr') ? 'fr' : 'en';
}
const totalStars = () => Object.values(SV.stars).reduce((a, b) => a + b, 0);

/* ================= audio / haptics ================= */
let actx = null;
function tone(f, d, type, vol, f2, delay){
  if(!SV.sound || SPEED === 0) return;
  try{
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    if(actx.state === 'suspended') actx.resume();
    const o = actx.createOscillator(), g = actx.createGain(), now = actx.currentTime + (delay || 0);
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, now); if(f2) o.frequency.exponentialRampToValueAtTime(f2, now + d);
    g.gain.setValueAtTime(0.0001, actx.currentTime); g.gain.setValueAtTime(vol || 0.07, now); g.gain.exponentialRampToValueAtTime(0.0001, now + d);
    o.connect(g); g.connect(actx.destination); o.start(now); o.stop(now + d + 0.02);
  }catch(e){}
}
const sfx = {
  swap(){ tone(420, .08, 'sine', .05, 620); },
  bad(){ tone(200, .15, 'triangle', .05, 150); },
  pop(n){ const f = 520 * Math.pow(1.12, Math.min(n, 10)); tone(f, .1, 'triangle', .06); tone(f * 1.5, .12, 'sine', .04, null, .05); },
  zap(){ tone(900, .25, 'sawtooth', .04, 200); },
  boom(){ tone(140, .3, 'square', .06, 50); },
  special(){ tone(660, .1, 'triangle', .06); tone(990, .16, 'triangle', .06, null, .08); },
  win(){ [523, 659, 784, 1046, 1318].forEach((f, i) => tone(f, .22, 'triangle', .08, null, i * .11)); },
  lose(){ [392, 330, 262].forEach((f, i) => tone(f, .3, 'triangle', .07, null, i * .18)); },
};
function hap(k){ try{ if(!N || !N.isNative || SPEED === 0) return; if(k === 'ok') N.Haptics.notification({ type: N.NotificationType.Success }); else N.Haptics.impact({ style: k === 'big' ? N.ImpactStyle.Medium : N.ImpactStyle.Light }); }catch(e){} }
function toast(m){ const el = $('#toast'); el.textContent = m; el.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('show'), 2000); }

/* ================= levels ================= */
function rng(seed){ return function(){ seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function makeLevel(n){
  const R = rng(n * 7919 + 13);
  const colors = n <= 8 ? 5 : n <= 30 ? (R() < 0.6 ? 5 : 6) : 6;
  const kind = n === 1 ? 'score' : n === 2 ? 'collect' : ['jelly', 'score', 'collect'][n % 3];
  const moves = Math.max(16, Math.round(28 - Math.min(n, 120) * 0.06 + (colors === 6 ? 3 : 0) + (R() * 4 - 2)));
  const L = { n, colors, kind, moves, jelly:[] };
  const diff = Math.min(1, n / 120);
  if(kind === 'jelly') L.moves = moves + 6;
  if(kind === 'score'){
    L.target = Math.round(L.moves * (450 + diff * 350) * (colors === 6 ? 0.85 : 1) / 100) * 100;
    L.stars = [L.target, Math.round(L.target * 1.35 / 100) * 100, Math.round(L.target * 1.75 / 100) * 100];
  } else if(kind === 'collect'){
    const k = n < 10 ? 1 : R() < 0.5 ? 1 : 2;
    const cols = []; while(cols.length < k){ const c = Math.floor(R() * colors); if(!cols.includes(c)) cols.push(c); }
    const per = Math.round((k === 1 ? 18 : 12) + diff * (k === 1 ? 20 : 14));
    L.items = cols.map(c => ({ t:c, n:per }));
    L.stars = [0, Math.round(L.moves * 520 / 100) * 100, Math.round(L.moves * 760 / 100) * 100];
  } else {
    const cnt = Math.min(30, 6 + Math.round(n * 0.2)) & ~1;
    const cells = new Set();
    while(cells.size < cnt){
      const r = 1 + Math.floor(R() * 6), c = 1 + Math.floor(R() * 3);
      cells.add(r * 8 + c); cells.add(r * 8 + (7 - c));
    }
    L.jelly = [...cells].map(i => ({ r: Math.floor(i / 8), c: i % 8, l: n > 60 && R() < diff * 0.25 ? 2 : 1 }));
    L.stars = [0, Math.round(L.moves * 520 / 100) * 100, Math.round(L.moves * 760 / 100) * 100];
  }
  return L;
}

/* ================= state ================= */
const GN = 8;
let grid = [], jelly = [], L = null, moves = 0, score = 0, collected = {}, busy = false, ended = false;
let cascadeN = 0, idCounter = 1, hammerMode = false, plus5Used = false, sel = null, lastAct = 0, hint = null;
let SPEED = 1; // 0 = instant (tests)
let tutOn = false, tutMove = null;
const fx = [], parts = [], dying = [], texts = [];
const now = () => performance.now();
function wait(ms){ return SPEED === 0 ? Promise.resolve() : new Promise(r => setTimeout(r, ms * SPEED)); }
function mkCandy(tp, s){ return { t:tp, s:s || '', id:idCounter++, tw:null, born:now() }; }
function rndType(){ return Math.floor(Math.random() * L.colors); }
const inB = (r, c) => r >= 0 && c >= 0 && r < GN && c < GN;
const at = (r, c) => inB(r, c) ? grid[r][c] : null;
const sameCol = (a, b) => a && b && a.t >= 0 && a.s !== 'b' && b.s !== 'b' && a.t === b.t;

function fillInitial(){
  for(let tries = 0; tries < 50; tries++){
    grid = [];
    for(let r = 0; r < GN; r++){ grid.push([]); for(let c = 0; c < GN; c++){
      let tp, k = 0;
      do{ tp = rndType(); k++; } while(k < 20 && ((c >= 2 && grid[r][c - 1].t === tp && grid[r][c - 2].t === tp) || (r >= 2 && grid[r - 1][c].t === tp && grid[r - 2][c].t === tp)));
      grid[r].push(mkCandy(tp));
    } }
    if(!findMatches().length && findMove()) return;
  }
}

/* ================= matching ================= */
function findMatches(){
  const runs = [];
  for(let r = 0; r < GN; r++){ let c = 0; while(c < GN){ let e = c + 1; while(e < GN && sameCol(grid[r][c], grid[r][e])) e++; if(e - c >= 3) runs.push({ dir:'h', cells:[...Array(e - c)].map((_, i) => [r, c + i]) }); c = e; } }
  for(let c = 0; c < GN; c++){ let r = 0; while(r < GN){ let e = r + 1; while(e < GN && sameCol(grid[r][c], grid[e][c])) e++; if(e - r >= 3) runs.push({ dir:'v', cells:[...Array(e - r)].map((_, i) => [r + i, c]) }); r = e; } }
  if(!runs.length) return [];
  // union runs sharing cells
  const par = runs.map((_, i) => i), f = (i) => par[i] === i ? i : (par[i] = f(par[i]));
  const owner = {};
  runs.forEach((run, i) => run.cells.forEach(([r, c]) => { const k = r * GN + c; if(owner[k] !== undefined) par[f(i)] = f(owner[k]); else owner[k] = i; }));
  const groups = {};
  runs.forEach((run, i) => { const g = f(i); (groups[g] = groups[g] || { runs:[], cells:new Map() }).runs.push(run); run.cells.forEach(([r, c]) => groups[g].cells.set(r * GN + c, [r, c])); });
  return Object.values(groups);
}
function decideSpecial(g, swapCells){
  const maxLen = Math.max(...g.runs.map(r => r.cells.length));
  const hasH = g.runs.some(r => r.dir === 'h'), hasV = g.runs.some(r => r.dir === 'v');
  let s = '';
  if(maxLen >= 5) s = 'b';
  else if(hasH && hasV) s = 'w';
  else if(maxLen === 4) s = g.runs[0].dir === 'h' ? 'v' : 'h';
  if(!s) return null;
  let pos = null;
  for(const sc of swapCells || []) if(g.cells.has(sc[0] * GN + sc[1])){ pos = sc; break; }
  if(!pos && s === 'w'){
    const hs = g.runs.filter(r => r.dir === 'h').flatMap(r => r.cells.map(([a, b]) => a * GN + b));
    const vs = g.runs.filter(r => r.dir === 'v').flatMap(r => r.cells.map(([a, b]) => a * GN + b));
    const k = hs.find(x => vs.includes(x)); if(k !== undefined) pos = [Math.floor(k / GN), k % GN];
  }
  if(!pos){ const lr = g.runs.reduce((a, b) => b.cells.length > a.cells.length ? b : a); pos = lr.cells[Math.floor(lr.cells.length / 2)]; }
  const c0 = g.cells.values().next().value;
  return { r:pos[0], c:pos[1], t: s === 'b' ? -1 : grid[c0[0]][c0[1]].t, s };
}
function findMove(){
  for(let r = 0; r < GN; r++) for(let c = 0; c < GN; c++) for(const [dr, dc] of [[0, 1], [1, 0]]){
    const r2 = r + dr, c2 = c + dc; if(!inB(r2, c2)) continue;
    const a = grid[r][c], b = grid[r2][c2]; if(!a || !b) continue;
    if(a.s === 'b' || b.s === 'b' || (a.s && b.s)) return [[r, c], [r2, c2]];
    grid[r][c] = b; grid[r2][c2] = a;
    const ok = lineAt(r, c) || lineAt(r2, c2);
    grid[r][c] = a; grid[r2][c2] = b;
    if(ok) return [[r, c], [r2, c2]];
  }
  return null;
}
function lineAt(r, c){
  const x = grid[r][c]; if(!x || x.s === 'b') return false;
  let h = 1, v = 1;
  for(let i = c - 1; i >= 0 && sameCol(grid[r][i], x); i--) h++;
  for(let i = c + 1; i < GN && sameCol(grid[r][i], x); i++) h++;
  for(let i = r - 1; i >= 0 && sameCol(grid[i][c], x); i--) v++;
  for(let i = r + 1; i < GN && sameCol(grid[i][c], x); i++) v++;
  return h >= 3 || v >= 3;
}

/* ================= effects / clearing ================= */
function specialArea(r, c, cd){
  const out = [];
  if(cd.s === 'h') for(let i = 0; i < GN; i++) out.push([r, i]);
  else if(cd.s === 'v') for(let i = 0; i < GN; i++) out.push([i, c]);
  else if(cd.s === 'w') for(let i = -1; i <= 1; i++) for(let j = -1; j <= 1; j++) if(inB(r + i, c + j)) out.push([r + i, c + j]);
  else if(cd.s === 'b'){
    const col = cd.target !== undefined ? cd.target : randomPresentColor();
    for(let i = 0; i < GN; i++) for(let j = 0; j < GN; j++){ const x = grid[i][j]; if(x && x.t === col && x.s !== 'b') out.push([i, j]); }
  }
  return out;
}
function randomPresentColor(){
  const cs = []; for(let i = 0; i < GN; i++) for(let j = 0; j < GN; j++){ const x = grid[i][j]; if(x && x.t >= 0 && x.s !== 'b') cs.push(x.t); }
  return cs.length ? cs[Math.floor(Math.random() * cs.length)] : 0;
}
async function clearCells(list, creations){
  const set = new Map(); const q = [];
  const add = ([r, c]) => { const k = r * GN + c; if(!set.has(k) && inB(r, c)){ set.set(k, [r, c]); q.push([r, c]); } };
  list.forEach(add);
  const keep = new Set((creations || []).map(x => x.r * GN + x.c));
  while(q.length){
    const [r, c] = q.shift(); const cd = grid[r][c];
    if(!cd || !cd.s || cd.fired || keep.has(r * GN + c)) continue;
    cd.fired = true;
    if(cd.s === 'h' || cd.s === 'v'){ fx.push({ kind:cd.s, r, c, t0:now(), col:cd.t }); sfx.zap(); }
    else if(cd.s === 'w'){ fx.push({ kind:'w', r, c, t0:now(), col:cd.t }); sfx.boom(); }
    else if(cd.s === 'b'){ fx.push({ kind:'b', r, c, t0:now() }); sfx.zap(); }
    specialArea(r, c, cd).forEach(add);
  }
  const mult = Math.max(1, cascadeN);
  let n = 0;
  for(const [k, [r, c]] of set){
    if(keep.has(k)) continue;
    const cd = grid[r][c];
    if(jelly[r][c] > 0){ jelly[r][c]--; score += 100; burst(r, c, '#ff8cc4', 4); }
    if(!cd) continue;
    n++;
    score += (cd.s ? 120 : 60) * mult;
    if(cd.t >= 0 && collected[cd.t] !== undefined) collected[cd.t]++;
    cd.dieT = now(); cd.r = r; cd.c = c; dying.push(cd);
    burst(r, c, cd.t >= 0 ? CANDY.COLORS[cd.t].base : '#8a5a3a', 5);
    grid[r][c] = null;
  }
  for(const cr of creations || []){
    const old = grid[cr.r][cr.c];
    if(old && !set.has(cr.r * GN + cr.c)){ /* the creation cell itself */ }
    if(old){ score += 60 * mult; if(old.t >= 0 && collected[old.t] !== undefined) collected[old.t]++; if(jelly[cr.r][cr.c] > 0){ jelly[cr.r][cr.c]--; score += 100; } }
    const nc = mkCandy(cr.t, cr.s); nc.pop = now(); grid[cr.r][cr.c] = nc; sfx.special();
  }
  if(n){ sfx.pop(cascadeN); hap(n > 6 ? 'big' : 'light'); }
  if(n >= 4 || (creations && creations.length)) floatScore(list[0], (n * 60 * mult));
  updHud();
  await wait(230);
}
async function resolveGroups(groups, swapCells){
  const cells = [], creations = [];
  for(const g of groups){
    const sp = decideSpecial(g, swapCells);
    for(const v of g.cells.values()) if(!sp || v[0] !== sp.r || v[1] !== sp.c) cells.push(v);
    if(sp) creations.push(sp);
  }
  await clearCells(cells, creations);
}
async function gravity(){
  let maxD = 0;
  for(let c = 0; c < GN; c++){
    let write = GN - 1;
    for(let r = GN - 1; r >= 0; r--){
      const cd = grid[r][c];
      if(cd){ if(write !== r){ grid[write][c] = cd; grid[r][c] = null; const d = write - r; cd.tw = { fr:r, fc:c, t0:now(), dur:Math.max(120, 70 * d) * SPEED }; maxD = Math.max(maxD, d); } write--; }
    }
    let k = 1;
    for(let r = write; r >= 0; r--){
      const cd = mkCandy(rndType()); grid[r][c] = cd;
      const d = r + k; cd.tw = { fr:-k, fc:c, t0:now(), dur:Math.max(120, 70 * d) * SPEED }; maxD = Math.max(maxD, d); k++;
    }
  }
  await wait(Math.max(120, 70 * maxD) + 20);
}
async function settle(){
  await gravity();
  for(let guard = 0; guard < 60; guard++){
    const g = findMatches(); if(!g.length) break;
    cascadeN++;
    if(cascadeN >= 3) praise(cascadeN);
    await resolveGroups(g, null);
    await gravity();
  }
}
function praise(n){ const p = t('praise'); showMsg(p[Math.min(p.length - 1, n - 3)]); }

/* ================= player actions ================= */
async function trySwap(r1, c1, r2, c2){
  if(busy || ended || !inB(r2, c2)) return;
  const a = grid[r1][c1], b = grid[r2][c2]; if(!a || !b) return;
  busy = true; hint = null; lastAct = now(); if(tutOn){ tutOn = false; }
  grid[r1][c1] = b; grid[r2][c2] = a;
  a.tw = { fr:r1, fc:c1, t0:now(), dur:150 * SPEED }; b.tw = { fr:r2, fc:c2, t0:now(), dur:150 * SPEED };
  sfx.swap(); await wait(160);
  cascadeN = 1;
  if(a.s === 'b' || b.s === 'b' || (a.s && b.s)){
    moves--; updHud();
    await comboSpecial(a, b, r2, c2, r1, c1);
    await settle(); await afterTurn(); return;
  }
  const g = findMatches();
  if(!g.length){
    grid[r1][c1] = a; grid[r2][c2] = b;
    a.tw = { fr:r2, fc:c2, t0:now(), dur:150 * SPEED }; b.tw = { fr:r1, fc:c1, t0:now(), dur:150 * SPEED };
    sfx.bad(); await wait(160); busy = false; return;
  }
  moves--; updHud();
  await resolveGroups(g, [[r2, c2], [r1, c1]]);
  await settle(); await afterTurn();
}
async function comboSpecial(a, b, r, c, r0, c0){
  // a now at (r,c), b at (r0,c0)
  const cells = [[r, c], [r0, c0]];
  if(a.s === 'b' && b.s === 'b'){
    a.fired = b.fired = true; fx.push({ kind:'all', t0:now() }); sfx.boom();
    for(let i = 0; i < GN; i++) for(let j = 0; j < GN; j++) cells.push([i, j]);
    await clearCells(cells, []); return;
  }
  if(a.s === 'b' || b.s === 'b'){
    const bomb = a.s === 'b' ? a : b, other = bomb === a ? b : a;
    bomb.fired = true; fx.push({ kind:'b', r: bomb === a ? r : r0, c: bomb === a ? c : c0, t0:now() }); sfx.zap();
    const col = other.t;
    if(!other.s){ for(let i = 0; i < GN; i++) for(let j = 0; j < GN; j++){ const x = grid[i][j]; if(x && x.t === col && x.s !== 'b') cells.push([i, j]); } await clearCells(cells, []); return; }
    // convert all of that color into the special and fire them
    for(let i = 0; i < GN; i++) for(let j = 0; j < GN; j++){ const x = grid[i][j]; if(x && x.t === col && x.s !== 'b'){ if(!x.s) x.s = other.s === 'w' ? 'w' : (Math.random() < 0.5 ? 'h' : 'v'); x.pop = now(); cells.push([i, j]); } }
    await wait(350);
    await clearCells(cells, []); return;
  }
  // two specials (h/v/w)
  a.fired = b.fired = true;
  const st = (x) => x.s === 'h' || x.s === 'v';
  if(st(a) && st(b)){ for(let i = 0; i < GN; i++){ cells.push([r, i], [i, c]); } fx.push({ kind:'h', r, c, t0:now() }, { kind:'v', r, c, t0:now() }); sfx.zap(); }
  else if(a.s === 'w' && b.s === 'w'){ for(let i = -2; i <= 2; i++) for(let j = -2; j <= 2; j++) cells.push([r + i, c + j]); fx.push({ kind:'w', r, c, t0:now(), big:true }); sfx.boom(); }
  else { for(let k = -1; k <= 1; k++) for(let i = 0; i < GN; i++){ cells.push([r + k, i], [i, c + k]); } fx.push({ kind:'h3', r, c, t0:now() }); sfx.zap(); sfx.boom(); }
  await clearCells(cells.filter(([x, y]) => inB(x, y)), []);
}
async function hammerAt(r, c){
  if(busy || ended || !grid[r][c]) return;
  busy = true; hammerMode = false; $('#bHammer').classList.remove('on');
  SV.hammer--; save(); updBoost();
  cascadeN = 1; fx.push({ kind:'w', r, c, t0:now(), small:true }); sfx.boom();
  await clearCells([[r, c]], []); await settle(); await afterTurn();
}
async function doShuffle(user){
  const list = [];
  for(let r = 0; r < GN; r++) for(let c = 0; c < GN; c++) if(grid[r][c]) list.push(grid[r][c]);
  for(let k = 0; k < 60; k++){
    for(let i = list.length - 1; i > 0; i--){ const j = Math.floor(Math.random() * (i + 1)); [list[i], list[j]] = [list[j], list[i]]; }
    let idx = 0; for(let r = 0; r < GN; r++) for(let c = 0; c < GN; c++){ grid[r][c] = list[idx++]; grid[r][c].pop = now(); }
    if(!findMatches().length && findMove()) break;
    if(k > 40){ for(let r = 0; r < GN; r++) for(let c = 0; c < GN; c++) if(!grid[r][c].s) grid[r][c].t = rndType(); }
  }
  showMsg(user ? t('shuffle') : t('noMoves'));
  await wait(500);
}
async function afterTurn(){
  cascadeN = 0;
  if(L.kind === 'score'){
    if(moves <= 0){ if(score >= L.target){ ended = true; return win(); } busy = false; return fail(); }
  } else if(goalDone()){ await sugarRush(); return win(); }
  if(moves <= 0){ busy = false; return fail(); }
  if(!findMove()) await doShuffle(false);
  busy = false; lastAct = now();
}
function goalDone(){
  if(L.kind === 'score') return score >= L.target;
  if(L.kind === 'collect') return L.items.every(it => collected[it.t] >= it.n);
  for(let r = 0; r < GN; r++) for(let c = 0; c < GN; c++) if(jelly[r][c] > 0) return false;
  return true;
}
async function sugarRush(){
  ended = true;
  if(moves > 0){
    showMsg(t('praise')[4]);
    await wait(600);
    const k = Math.min(moves, 12);
    score += (moves - k) * 300;
    for(let i = 0; i < k; i++){
      const opts = []; for(let r = 0; r < GN; r++) for(let c = 0; c < GN; c++){ const x = grid[r][c]; if(x && !x.s) opts.push([r, c]); }
      if(!opts.length) break;
      const [r, c] = opts[Math.floor(Math.random() * opts.length)];
      grid[r][c].s = Math.random() < 0.5 ? 'h' : 'v'; grid[r][c].pop = now(); moves--; score += 300; updHud(); sfx.special();
      await wait(110);
    }
    moves = 0; updHud();
    const all = []; for(let r = 0; r < GN; r++) for(let c = 0; c < GN; c++){ const x = grid[r][c]; if(x && x.s) all.push([r, c]); }
    cascadeN = 1;
    if(all.length){ await clearCells(all, []); await settle(); }
  }
}

/* ================= UI / screens ================= */
const modal = $('#modal'); let modalOpen = false;
function showModal(html, bind){ modal.innerHTML = '<div class="box">' + html + '</div>'; modal.classList.add('show'); modalOpen = true; if(bind) bind(modal); }
function closeModal(){ modal.classList.remove('show'); modal.innerHTML = ''; modalOpen = false; }
function show(id){
  document.querySelectorAll('.scr').forEach(s => s.classList.toggle('show', s.id === id));
  if(id === 'game') Ads.hideBanner(); else Ads.showBanner();
  if(id === 'game') requestAnimationFrame(resize);
}
function showMsg(m){ const el = $('#msg'); el.textContent = m; el.classList.remove('show'); void el.offsetWidth; el.classList.add('show'); }

function iconCanvas(tp, px){ const c = document.createElement('canvas'); c.width = c.height = px * 2; c.getContext('2d').drawImage(CANDY.get(tp, ''), 0, 0, px * 2, px * 2); return c; }
function goalHTML(big){
  if(L.kind === 'score') return '<div class="goal">🎯 ' + L.target + '</div>';
  if(L.kind === 'jelly'){ let n = 0; for(let r = 0; r < GN; r++) for(let c = 0; c < GN; c++) n += jelly[r][c] ? 1 : 0; return '<div class="goal' + (n === 0 ? ' ok' : '') + '">🍮 ' + n + '</div>'; }
  return L.items.map(it => '<div class="goal' + (collected[it.t] >= it.n ? ' ok' : '') + '" data-t="' + it.t + '"><canvas></canvas>' + Math.max(0, it.n - collected[it.t]) + '</div>').join('');
}
function fillGoalIcons(root){ root.querySelectorAll('.goal[data-t] canvas').forEach(cv => { const tp = +cv.parentElement.dataset.t; cv.width = cv.height = 60; cv.getContext('2d').drawImage(CANDY.get(tp, ''), 0, 0, 60, 60); }); }
let lastGoalHTML = '';
function updHud(){
  $('#gMoves').textContent = moves;
  const h = goalHTML(); if(h !== lastGoalHTML){ lastGoalHTML = h; $('#goals').innerHTML = h; fillGoalIcons($('#goals')); }
  const top = L.stars[2];
  $('#scoreFill').style.width = Math.min(100, score / top * 100) + '%';
  const pos = (v) => Math.min(98, v / top * 100) + '%';
  const s1 = L.kind === 'score' ? L.stars[0] : Math.min(L.stars[1] * 0.5, L.stars[1]);
  [[s1, '#mk1'], [L.stars[1], '#mk2'], [L.stars[2], '#mk3']].forEach(([v, id]) => { const el = $(id); el.style.left = pos(v); el.classList.toggle('on', score >= v); });
  $('#scoreTxt').textContent = score;
}
function updBoost(){ $('#cHammer').textContent = SV.hammer > 0 ? SV.hammer : '+'; $('#cShuffle').textContent = SV.shuffle > 0 ? SV.shuffle : '+'; }

function applyLang(){
  document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  $('#tTitle').textContent = t('title'); $('#tSub').textContent = t('sub'); document.title = t('title');
  $('#bPlay').textContent = '▶ ' + t('play'); $('#bMap').textContent = '🗺️ ' + t('levels'); $('#bSet').textContent = '⚙️ ' + t('settings');
  $('#mTitle').textContent = t('levels'); $('#mBack').textContent = lang === 'ar' ? '→' : '←';
  $('#lLevel').textContent = t('level'); $('#lMoves').textContent = t('moves');
  updHome();
}
function updHome(){ $('#hLevel').textContent = '🍬 ' + t('level') + ' ' + SV.level; $('#hStars').textContent = '⭐ ' + totalStars(); }

function showMap(){
  const g = $('#lvgrid'); g.innerHTML = ''; $('#mStars').textContent = '⭐ ' + totalStars();
  const fr = document.createDocumentFragment();
  for(let i = 1; i <= MAX_LEVEL; i++){
    const b = document.createElement('button'); const st = SV.stars[i] || 0, open = i <= SV.level;
    b.className = 'lv' + (i === SV.level ? ' cur' : '') + (open ? '' : ' lock');
    b.innerHTML = (open ? i : '🔒') + '<small>' + (open ? '★'.repeat(st) + '☆'.repeat(3 - st) : '') + '</small>';
    b.onclick = () => { if(!open){ toast(t('locked')); return; } startLevel(i); };
    fr.appendChild(b);
  }
  g.appendChild(fr); show('map');
  const cur = g.children[SV.level - 1]; if(cur) setTimeout(() => cur.scrollIntoView({ block:'center' }), 30);
}

function startLevel(n){
  closeModal();
  L = makeLevel(n); moves = L.moves; score = 0; collected = {}; ended = false; busy = false; plus5Used = false; hammerMode = false; sel = null; hint = null;
  if(L.items) L.items.forEach(it => collected[it.t] = 0); else for(let i = 0; i < 6; i++) collected[i] = 0;
  if(L.kind !== 'collect') collected = {};
  jelly = [...Array(GN)].map(() => Array(GN).fill(0)); L.jelly.forEach(j => jelly[j.r][j.c] = j.l);
  fillInitial();
  dying.length = 0; parts.length = 0; fx.length = 0; texts.length = 0;
  for(let r = 0; r < GN; r++) for(let c = 0; c < GN; c++){ const cd = grid[r][c]; cd.tw = { fr:r - GN - 1, fc:c, t0:now() + (GN - r) * 30 + c * 10, dur:420 * SPEED }; }
  $('#gLevel').textContent = n; lastGoalHTML = '';
  tutOn = n <= 2 && !(SV.stars[n] > 0) && SPEED !== 0; tutMove = null;
  updHud(); updBoost(); $('#bHammer').classList.remove('on');
  show('game'); lastAct = now();
  // goal intro
  const gtxt = L.kind === 'score' ? t('gScore').replace('{n}', L.target) : L.kind === 'collect' ? t('gCollect') : t('gJelly');
  if(SPEED){
    busy = true;
    showModal('<h2>' + t('level') + ' ' + n + '</h2><p>' + gtxt + '</p><div class="goalsBig">' + goalHTML().replace(/class="goal[^"]*"/g, '') + '</div><button class="btn grn" id="go">' + t('go') + '</button>', (m) => {
      m.querySelectorAll('.goalsBig canvas').forEach((cv, i) => { cv.width = cv.height = 88; cv.getContext('2d').drawImage(CANDY.get(L.items[i].t, ''), 0, 0, 88, 88); });
      m.querySelector('#go').onclick = () => { closeModal(); busy = false; lastAct = now(); };
    });
  }
}

async function reward(){
  if(!Ads.isNative) return true; // web preview only
  if(!Ads.rewardedAvailable()){ toast(t('adNo')); return false; }
  return !!(await Ads.showRewarded());
}
function starsNow(){ return score >= L.stars[2] ? 3 : score >= L.stars[1] ? 2 : 1; }
function win(){
  busy = true; ended = true;
  const st = starsNow(), n = L.n;
  SV.stars[n] = Math.max(SV.stars[n] || 0, st);
  SV.best[n] = Math.max(SV.best[n] || 0, score);
  if(n === SV.level && SV.level < MAX_LEVEL) SV.level = n + 1;
  SV.wins++;
  if(SV.wins % 5 === 0){ SV.hammer++; }
  save(); sfx.win(); hap('ok');
  Ads.showBanner();
  showModal('<h2>' + t('win') + '</h2><div class="stars"><span>⭐</span><span>⭐</span><span>⭐</span></div><p><b>' + t('score') + ': ' + score + '</b><br>' + t('best') + ': ' + SV.best[n] + '</p>' +
    (n < MAX_LEVEL ? '<button class="btn grn" id="nx">' + (lang === 'ar' ? '◀ ' : '▶ ') + t('next') + '</button>' : '') +
    '<div class="row"><button class="btn alt sm" id="rp">🔄 ' + t('retry') + '</button><button class="btn alt sm" id="mp">🗺️ ' + t('levelsBtn') + '</button></div>', (m) => {
      const sp = m.querySelectorAll('.stars span');
      for(let i = 0; i < st; i++) setTimeout(() => { sp[i].classList.add('on'); tone(880 + i * 220, .12, 'triangle', .06); }, 300 + i * 300);
      const nx = m.querySelector('#nx'); if(nx) nx.onclick = async () => { closeModal(); await maybeInter(); startLevel(n + 1); };
      m.querySelector('#rp').onclick = async () => { closeModal(); await maybeInter(); startLevel(n); };
      m.querySelector('#mp').onclick = () => { closeModal(); showMap(); };
    });
}
function fail(){
  busy = true; sfx.lose();
  Ads.showBanner();
  showModal('<h2>' + t('fail') + '</h2><div class="goalsBig">' + goalHTML() + '</div>' +
    (!plus5Used ? '<p>' + t('failP') + '</p><button class="btn pnk" id="p5">🎬 ' + t('plus5') + '</button>' : '') +
    '<div class="row"><button class="btn grn sm" id="rt">🔄 ' + t('retry') + '</button><button class="btn alt sm" id="mp">🗺️ ' + t('levelsBtn') + '</button></div>', (m) => {
      fillGoalIcons(m);
      const p5 = m.querySelector('#p5');
      if(p5) p5.onclick = async () => {
        const ok = await reward(); if(!ok) return;
        plus5Used = true; moves += 5; closeModal(); Ads.hideBanner(); updHud(); busy = false; ended = false; lastAct = now();
      };
      m.querySelector('#rt').onclick = async () => { closeModal(); await maybeInter(); startLevel(L.n); };
      m.querySelector('#mp').onclick = () => { closeModal(); showMap(); };
    });
}
const sessionStart = Date.now();
async function maybeInter(){ if(Date.now() - sessionStart < 120000 || SV.wins < 3) return false; try{ return await Ads.maybeInterstitial(); }catch(e){ return false; } }
function pause(){
  if(!$('#game').classList.contains('show') || modalOpen) return;
  showModal('<h2>' + t('paused') + '</h2><button class="btn grn" id="r">▶ ' + t('resume') + '</button><button class="btn alt sm" id="rs">🔄 ' + t('restart') + '</button><button class="btn alt sm" id="h">🏠 ' + t('home') + '</button>', (m) => {
    m.querySelector('#r').onclick = () => closeModal();
    m.querySelector('#rs').onclick = () => { closeModal(); startLevel(L.n); };
    m.querySelector('#h').onclick = () => { closeModal(); goHome(); };
  });
}
function goHome(){ updHome(); show('home'); setTimeout(() => { if(!modalOpen) dailyGift(); }, 400); }
async function boosterAd(kind){
  showModal('<h2>' + t('boosters') + '</h2><div style="font-size:54px">' + (kind === 'hammer' ? '🔨' : '🔀') + '</div><button class="btn pnk" id="ad">🎬 ' + t('more') + '</button><button class="btn alt sm" id="cl">' + t('close') + '</button>', (m) => {
    m.querySelector('#cl').onclick = closeModal;
    m.querySelector('#ad').onclick = async () => { const ok = await reward(); closeModal(); if(ok){ SV[kind] += 2; save(); updBoost(); toast(t('got')); } };
  });
}
function showSettings(){
  showModal('<h2>⚙️ ' + t('settings') + '</h2><p>' + t('lang') + '</p><div class="row" id="lr"></div><p>' + t('sound') + '</p>' +
    '<button class="btn alt sm" id="snd">' + (SV.sound ? '🔊 ' + t('on') : '🔇 ' + t('off')) + '</button>' +
    (Ads.privacyRequired ? '<button class="btn alt sm" id="prv">🔒 ' + t('privacy') + '</button>' : '') +
    '<button class="btn grn" id="cl">' + t('close') + '</button>', (m) => {
      ['ar','en','fr'].forEach(Lg => { const b = document.createElement('button'); b.className = 'btn sm ' + (Lg === lang ? '' : 'alt'); b.textContent = LANG_NAME[Lg];
        b.onclick = () => { lang = Lg; SV.lang = Lg; save(); applyLang(); showSettings(); }; m.querySelector('#lr').appendChild(b); });
      m.querySelector('#snd').onclick = () => { SV.sound = !SV.sound; save(); showSettings(); };
      const pv = m.querySelector('#prv'); if(pv) pv.onclick = () => Ads.showPrivacyOptions();
      m.querySelector('#cl').onclick = closeModal;
    });
}

/* ================= rendering ================= */
const cv = $('#cv'), ctx = cv.getContext('2d');
let CS = 40, DPR = 1;
function resize(){
  const w = $('#boardWrap').getBoundingClientRect();
  if(w.width < 10) return;
  CS = Math.floor(Math.min((w.width - 8) / GN, (w.height - 8) / GN, 110));
  DPR = Math.min(window.devicePixelRatio || 1, 2);
  cv.width = CS * GN * DPR; cv.height = CS * GN * DPR; cv.style.width = CS * GN + 'px'; cv.style.height = CS * GN + 'px';
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
}
window.addEventListener('resize', resize);
function burst(r, c, col, n){ if(SPEED === 0 || parts.length > 160) return; for(let i = 0; i < n; i++) parts.push({ x:(c + .5), y:(r + .5), vx:(Math.random() - .5) * 8, vy:(Math.random() - .9) * 8, l:.5 + Math.random() * .3, col }); }
function floatScore(cell, v){ if(!cell || SPEED === 0) return; texts.push({ x:cell[1] + .5, y:cell[0] + .5, v:'+' + v, t0:now() }); }
function rr(x, a, b, w, h, r){ x.beginPath(); x.moveTo(a + r, b); x.arcTo(a + w, b, a + w, b + h, r); x.arcTo(a + w, b + h, a, b + h, r); x.arcTo(a, b + h, a, b, r); x.arcTo(a, b, a + w, b, r); x.closePath(); }
let lastFrame = now();
function frame(){
  const tnow = now(), dt = Math.min(.05, (tnow - lastFrame) / 1000); lastFrame = tnow;
  if($('#game').classList.contains('show') && L){
    const W = CS * GN;
    ctx.clearRect(0, 0, W, W);
    // board
    ctx.fillStyle = 'rgba(70,10,90,.45)'; rr(ctx, 0, 0, W, W, CS * .3); ctx.fill();
    for(let r = 0; r < GN; r++) for(let c = 0; c < GN; c++){
      ctx.fillStyle = (r + c) % 2 ? 'rgba(255,255,255,.10)' : 'rgba(255,255,255,.18)';
      rr(ctx, c * CS + 2, r * CS + 2, CS - 4, CS - 4, CS * .18); ctx.fill();
      const j = jelly[r][c];
      if(j){ ctx.fillStyle = j === 2 ? 'rgba(255,60,160,.9)' : 'rgba(255,120,195,.8)'; rr(ctx, c * CS + 2, r * CS + 2, CS - 4, CS - 4, CS * .2); ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = j === 2 ? 3 : 2; ctx.stroke();
        ctx.fillStyle = 'rgba(255,255,255,.35)'; rr(ctx, c * CS + 6, r * CS + 6, CS * .4, CS * .14, CS * .07); ctx.fill(); }
    }
    // selection / hint
    if(sel){ ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; rr(ctx, sel[1] * CS + 2, sel[0] * CS + 2, CS - 4, CS - 4, CS * .18); ctx.stroke(); }
    if(!busy && !ended && !modalOpen && tnow - lastAct > 5500){ if(!hint) hint = findMove(); } else if(busy) hint = null;
    // candies
    ctx.save(); ctx.beginPath(); ctx.rect(0, 0, W, W); ctx.clip();
    for(let r = 0; r < GN; r++) for(let c = 0; c < GN; c++){
      const cd = grid[r] && grid[r][c]; if(!cd) continue;
      let y = r, x = c;
      if(cd.tw){ const p = Math.max(0, Math.min(1, (tnow - cd.tw.t0) / Math.max(1, cd.tw.dur))); if(p >= 1) cd.tw = null; else { const e = cd.tw.fr < r ? p * p : 1 - (1 - p) * (1 - p); y = cd.tw.fr + (r - cd.tw.fr) * (cd.tw.fr < r ? e : p); x = cd.tw.fc + (c - cd.tw.fc) * p; if(cd.tw.fr === r) y = r; } }
      let s = 1;
      if(cd.pop){ const p = (tnow - cd.pop) / 250; if(p >= 1) cd.pop = null; else s = 1 + Math.sin(p * Math.PI) * .25; }
      if(hint && ((hint[0][0] === r && hint[0][1] === c) || (hint[1][0] === r && hint[1][1] === c))) s *= 1 + Math.abs(Math.sin(tnow / 220)) * .12;
      const sz = CS * .9 * s, img = CANDY.get(cd.t, cd.s);
      ctx.drawImage(img, x * CS + (CS - sz) / 2, y * CS + (CS - sz) / 2, sz, sz);
    }
    // dying
    for(let i = dying.length - 1; i >= 0; i--){
      const d = dying[i], p = (tnow - d.dieT) / 220; if(p >= 1){ dying.splice(i, 1); continue; }
      const sz = CS * .9 * (1 + p * .3); ctx.globalAlpha = 1 - p;
      ctx.drawImage(CANDY.get(d.t, d.s), d.c * CS + (CS - sz) / 2, d.r * CS + (CS - sz) / 2, sz, sz); ctx.globalAlpha = 1;
    }
    ctx.restore();
    // fx
    for(let i = fx.length - 1; i >= 0; i--){
      const f = fx[i], p = (tnow - f.t0) / 350; if(p >= 1){ fx.splice(i, 1); continue; }
      ctx.globalAlpha = 1 - p;
      const cx = (f.c + .5) * CS, cy = (f.r + .5) * CS;
      if(f.kind === 'h' || f.kind === 'h3'){ const hh = CS * (f.kind === 'h3' ? 3 : .5) * (1 - p * .5); const g = ctx.createLinearGradient(0, cy - hh / 2, 0, cy + hh / 2); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(.5, 'rgba(255,255,255,.95)'); g.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = g; ctx.fillRect(0, cy - hh / 2, W, hh); }
      if(f.kind === 'v' || f.kind === 'h3'){ const ww = CS * (f.kind === 'h3' ? 3 : .5) * (1 - p * .5); const g = ctx.createLinearGradient(cx - ww / 2, 0, cx + ww / 2, 0); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(.5, 'rgba(255,255,255,.95)'); g.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = g; ctx.fillRect(cx - ww / 2, 0, ww, W); }
      if(f.kind === 'w'){ const rad = CS * (f.big ? 2.8 : f.small ? .9 : 1.7) * (.4 + p); const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, rad); g.addColorStop(0, 'rgba(255,255,220,.95)'); g.addColorStop(.6, 'rgba(255,190,80,.6)'); g.addColorStop(1, 'rgba(255,120,0,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, rad, 0, 7); ctx.fill(); }
      if(f.kind === 'b' || f.kind === 'all'){ ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(f.kind === 'all' ? W / 2 : cx, f.kind === 'all' ? W / 2 : cy, W * p, 0, 7); ctx.stroke(); }
      ctx.globalAlpha = 1;
    }
    // particles
    for(let i = parts.length - 1; i >= 0; i--){
      const q = parts[i]; q.l -= dt; if(q.l <= 0){ parts.splice(i, 1); continue; }
      q.vy += 20 * dt; q.x += q.vx * dt; q.y += q.vy * dt;
      ctx.globalAlpha = Math.min(1, q.l * 2); ctx.fillStyle = q.col; ctx.beginPath(); ctx.arc(q.x * CS, q.y * CS, CS * .07, 0, 7); ctx.fill();
    }
    ctx.globalAlpha = 1;
    // tutorial hand
    if(tutOn && !busy && !modalOpen && !ended){
      if(!tutMove) tutMove = findMove();
      if(tutMove){
        const p = (tnow % 1400) / 1400, e = p < .2 ? 0 : p > .7 ? 1 : (p - .2) / .5;
        const [a, b2] = tutMove, hx = (a[1] + (b2[1] - a[1]) * e + .6) * CS, hy = (a[0] + (b2[0] - a[0]) * e + .7) * CS;
        ctx.globalAlpha = p > .85 ? (1 - p) / .15 : 1;
        ctx.font = Math.round(CS * .8) + 'px "Noto Color Emoji","Apple Color Emoji","Segoe UI Emoji",sans-serif'; ctx.textAlign = 'center'; ctx.fillText('👆', hx, hy + CS * .3);
        ctx.globalAlpha = 1;
      }
    }
    // texts
    for(let i = texts.length - 1; i >= 0; i--){
      const tx = texts[i], p = (tnow - tx.t0) / 800; if(p >= 1){ texts.splice(i, 1); continue; }
      ctx.globalAlpha = 1 - p; ctx.font = 'bold ' + Math.round(CS * .5) + 'px Plex, Arial'; ctx.textAlign = 'center';
      ctx.lineWidth = 4; ctx.strokeStyle = '#8a1f7a'; ctx.strokeText(tx.v, tx.x * CS, (tx.y - p * .8) * CS); ctx.fillStyle = '#fff'; ctx.fillText(tx.v, tx.x * CS, (tx.y - p * .8) * CS);
      ctx.globalAlpha = 1;
    }
  }
  requestAnimationFrame(frame);
}

/* ================= input ================= */
let down = null;
function cellFrom(e){ const b = cv.getBoundingClientRect(); return [Math.floor((e.clientY - b.top) / CS), Math.floor((e.clientX - b.left) / CS), e.clientX, e.clientY]; }
cv.addEventListener('pointerdown', (e) => {
  e.preventDefault();
  if(busy || ended || modalOpen) return;
  const [r, c, x, y] = cellFrom(e); if(!inB(r, c)) return;
  try{ actx = actx || new (window.AudioContext || window.webkitAudioContext)(); if(actx.state === 'suspended') actx.resume(); }catch(_){}
  if(hammerMode){ hammerAt(r, c); return; }
  down = { r, c, x, y, moved:false };
});
cv.addEventListener('pointermove', (e) => {
  if(!down || down.moved) return;
  const dx = e.clientX - down.x, dy = e.clientY - down.y, th = CS * .3;
  if(Math.abs(dx) < th && Math.abs(dy) < th) return;
  down.moved = true; sel = null;
  if(Math.abs(dx) > Math.abs(dy)) trySwap(down.r, down.c, down.r, down.c + (dx > 0 ? 1 : -1));
  else trySwap(down.r, down.c, down.r + (dy > 0 ? 1 : -1), down.c);
});
cv.addEventListener('pointerup', () => {
  if(!down) return;
  if(!down.moved){
    const { r, c } = down;
    if(sel && Math.abs(sel[0] - r) + Math.abs(sel[1] - c) === 1){ const s0 = sel; sel = null; trySwap(s0[0], s0[1], r, c); }
    else if(sel && sel[0] === r && sel[1] === c) sel = null;
    else sel = [r, c];
  }
  down = null;
});
cv.addEventListener('pointercancel', () => { down = null; });

$('#bPlay').onclick = () => startLevel(SV.level);
$('#bMap').onclick = showMap;
$('#bSet').onclick = showSettings;
$('#mBack').onclick = goHome;
$('#bPause').onclick = pause;
$('#bHammer').onclick = () => {
  if(busy || ended) return;
  if(SV.hammer <= 0){ boosterAd('hammer'); return; }
  hammerMode = !hammerMode; $('#bHammer').classList.toggle('on', hammerMode); if(hammerMode) toast(t('hammerHint'));
};
$('#bShuffle').onclick = async () => {
  if(busy || ended) return;
  if(SV.shuffle <= 0){ boosterAd('shuffle'); return; }
  busy = true; SV.shuffle--; save(); updBoost(); await doShuffle(true); busy = false; lastAct = now();
};

try{
  N.App.addListener('backButton', () => {
    if(modalOpen){ if(!ended && !busy) closeModal(); else if(!$('#game').classList.contains('show')) closeModal(); return; }
    if($('#game').classList.contains('show')){ pause(); return; }
    if($('#map').classList.contains('show')){ goHome(); return; }
    N.App.exitApp();
  });
  N.App.addListener('pause', () => { save(); if(actx) actx.suspend(); });
  N.App.addListener('resume', () => { if(actx) actx.resume(); });
}catch(e){}

/* daily gift */
function dailyGift(){
  const d = new Date(), key = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  if(SV.gift === key || SV.wins < 1) return;
  showModal('<h2>🎁 ' + t('daily') + '</h2><div style="font-size:54px">🔨 🔀</div><p>' + t('dailyP') + '</p><button class="btn grn" id="cl">' + t('claim') + ' +1 🔨 +1 🔀</button>', (m) => {
    m.querySelector('#cl').onclick = () => { SV.gift = key; SV.hammer++; SV.shuffle++; save(); closeModal(); sfx.win(); };
  });
}

/* home logo */
function drawLogo(){
  const c = $('#logoCv'), x = c.getContext('2d'); x.clearRect(0, 0, 600, 300);
  const items = [[0, '', 70, 170, -0.2], [5, 'w', 190, 120, 0.1], [-1, 'b', 300, 150, 0], [3, 'v', 410, 110, -0.1], [2, 'h', 530, 170, 0.2]];
  items.forEach(([tp, s, px, py, rot]) => { x.save(); x.translate(px, py); x.rotate(rot); x.drawImage(CANDY.get(tp, s), -64, -64, 128, 128); x.restore(); });
}

/* start */
load(); lang = detectLang(); applyLang(); drawLogo();
setTimeout(() => { if($('#home').classList.contains('show') && !modalOpen) dailyGift(); }, 900);
try{ N && N.isNative && N.StatusBar.setStyle({ style: N.Style.Dark }); }catch(e){}
try{ N && N.isNative && N.StatusBar.setBackgroundColor({ color: '#7b2ff7' }); }catch(e){}
Ads.init().finally(() => { if(!$('#game').classList.contains('show')) Ads.showBanner(); try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} });
setTimeout(() => { try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} }, 2500);
requestAnimationFrame(frame);

/* test hooks */
window.__sp = {
  get state(){ return { moves, score, ended, busy, kind:L && L.kind, collected, L }; },
  SV: () => SV, startLevel, makeLevel, findMove, trySwap, setSpeed: (v) => { SPEED = v; },
  setLang: (l) => { lang = l; applyLang(); }, grid: () => grid, goalDone, showMap,
  async autoplay(n, smart){
    SPEED = 0; startLevel(n); closeModal(); busy = false;
    let guard = 0;
    while(!ended && moves > 0 && guard++ < 200){
      let mv = null;
      if(smart){
        // greedy: prefer special combos, then moves that create specials
        let best = -1;
        for(let r = 0; r < GN; r++) for(let c = 0; c < GN; c++) for(const [dr, dc] of [[0, 1], [1, 0]]){
          const r2 = r + dr, c2 = c + dc; if(!inB(r2, c2)) continue;
          const a = grid[r][c], b = grid[r2][c2]; if(!a || !b) continue;
          let sc = -1;
          if(a.s === 'b' || b.s === 'b' || (a.s && b.s)) sc = 100;
          else { grid[r][c] = b; grid[r2][c2] = a; const g = findMatches(); if(g.length){ sc = 0; for(const gg of g){ const sp = decideSpecial(gg, [[r, c], [r2, c2]]); sc += gg.cells.size + (sp ? (sp.s === 'b' ? 30 : sp.s === 'w' ? 15 : 10) : 0); } sc += r / 10; } grid[r][c] = a; grid[r2][c2] = b; }
          if(sc > best){ best = sc; mv = [[r, c], [r2, c2]]; }
        }
      } else mv = findMove();
      if(!mv) break;
      await trySwap(mv[0][0], mv[0][1], mv[1][0], mv[1][1]);
      if(busy && !ended && moves <= 0) break;
    }
    const res = { n, kind:L.kind, win: ended && goalDone(), score, movesLeft:moves, stars: ended ? starsNow() : 0, L:{ moves:L.moves, stars:L.stars, target:L.target, items:L.items } };
    closeModal(); SPEED = 1; return res;
  }
};
})();
