// Riad Seek — لعبة الأشياء المخبّية
(function(){
'use strict';
const N = window.Native;
const IMG_W = 1024, IMG_H = 1536;
const FREE_HINTS = 3;
const $ = id => document.getElementById(id);

// ---------- حفظ التقدّم ----------
const store = {
  get(k, d){ try{ const v = localStorage.getItem('rs_' + k); return v === null ? d : JSON.parse(v); }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem('rs_' + k, JSON.stringify(v)); }catch(e){} },
};

// ---------- النصوص ----------
const T = {
  ar:{ title:'خبايا الرياض', sub:'لعبة البحث عن الأشياء المخبّية', found:'لقيتي', level:'المستوى', locked:'مسدود', play:'العب',
       progress:(a,b)=>`كمّلتي ${a} من ${b} مستويات`, soon:'✨ مستويات جديدة قريباً', lang:'🌐 Français', soundOn:'🔊 الصوت', soundOff:'🔇 الصوت', help:'❓ كيفاش نلعب', privacy:'🔒 خيارات الإعلانات', policy:'📄 سياسة الخصوصية',
       win:'برافو!', winTxt:'لقيتي كاع الأشياء', time:'الوقت', hintsUsed:'التلميحات', next:'المستوى الموالي', again:'عاود', menu:'القائمة',
       allDone:'كمّلتي جميع المستويات! تسنّى مستويات جديدة فالتحديث الجاي.',
       noHint:'سالاو التلميحات', hintAd:'شوف إعلان قصير وخود تلميح', watch:'🎬 شاهد إعلان (+1 تلميح)', close:'سد', adNA:'ما كاينش إعلان دابا، عاود من بعد',
       slow:'بشوية! ما تضغطش عشوائياً', howTitle:'كيفاش نلعب؟',
       how:'🔎 قلّب على الأشياء اللي مكتوبين لتحت فالصورة.<br>👆 ضغط على الشي ملي تلقاه.<br>🤏 كبّر وصغّر بجوج صوابع، وحرّك الصورة.<br>💡 ستعمل زر التلميح ملي تحبس.<br>⭐ بلا تلميحات = 3 نجوم.',
       ok:'فهمت', quitQ:'تخرج من المستوى؟', quitTxt:'غادي يضيع التقدّم ديال هاد المستوى.', yes:'نعم، خرج', no:'لا، كمّل', exitQ:'تخرج من اللعبة؟' },
  fr:{ title:'Riad Seek', sub:'Jeu d\'objets cachés marocain', found:'Trouvés', level:'Niveau', locked:'Verrouillé', play:'Jouer',
       progress:(a,b)=>`${a} niveau(x) terminé(s) sur ${b}`, soon:'✨ Nouveaux niveaux bientôt', lang:'🌐 English', soundOn:'🔊 Son', soundOff:'🔇 Son', help:'❓ Comment jouer', privacy:'🔒 Options pub', policy:'📄 Confidentialité',
       win:'Bravo !', winTxt:'Tu as tout trouvé', time:'Temps', hintsUsed:'Indices', next:'Niveau suivant', again:'Rejouer', menu:'Menu',
       allDone:'Tu as terminé tous les niveaux ! De nouveaux niveaux arrivent dans la prochaine mise à jour.',
       noHint:'Plus d\'indices', hintAd:'Regarde une courte pub pour obtenir un indice', watch:'🎬 Voir une pub (+1 indice)', close:'Fermer', adNA:'Aucune pub disponible, réessaie plus tard',
       slow:'Doucement ! Ne tape pas au hasard', howTitle:'Comment jouer ?',
       how:'🔎 Cherche les objets listés en bas dans l\'image.<br>👆 Touche l\'objet quand tu le trouves.<br>🤏 Zoome avec deux doigts et déplace l\'image.<br>💡 Utilise l\'indice si tu bloques.<br>⭐ Sans indice = 3 étoiles.',
       ok:'Compris', quitQ:'Quitter le niveau ?', quitTxt:'La progression de ce niveau sera perdue.', yes:'Oui, quitter', no:'Non, continuer', exitQ:'Quitter le jeu ?' },
  en:{ title:'Riad Seek', sub:'Moroccan hidden object game', found:'Found', level:'Level', locked:'Locked', play:'Play',
       progress:(a,b)=>`${a} of ${b} levels completed`, soon:'✨ New levels coming soon', lang:'🌐 العربية', soundOn:'🔊 Sound', soundOff:'🔇 Sound', help:'❓ How to play', privacy:'🔒 Ad options', policy:'📄 Privacy policy',
       win:'Well done!', winTxt:'You found everything', time:'Time', hintsUsed:'Hints', next:'Next level', again:'Play again', menu:'Menu',
       allDone:'You finished every level! New levels are coming in the next update.',
       noHint:'No hints left', hintAd:'Watch a short ad to get a hint', watch:'🎬 Watch ad (+1 hint)', close:'Close', adNA:'No ad available right now, try later',
       slow:'Easy! Don\'t tap randomly', howTitle:'How to play?',
       how:'🔎 Find the objects listed at the bottom in the picture.<br>👆 Tap an object when you spot it.<br>🤏 Pinch to zoom and drag to move.<br>💡 Use a hint when you are stuck.<br>⭐ No hints = 3 stars.',
       ok:'Got it', quitQ:'Leave this level?', quitTxt:'Your progress in this level will be lost.', yes:'Yes, leave', no:'No, keep playing', exitQ:'Quit the game?' },
};
const guessLang = () => { const l = (navigator.language || 'ar').slice(0,2); return l === 'fr' ? 'fr' : (l === 'en' ? 'en' : 'ar'); };
let lang = store.get('lang', guessLang());
const t = k => T[lang][k];

// ---------- الحالة ----------
let unlocked = store.get('unlocked', 1);       // عدد المستويات المفتوحة
let best = store.get('best', {});              // أحسن وقت لكل مستوى (ثواني)
let stars = store.get('stars', {});            // أحسن نجوم لكل مستوى
let sound = store.get('sound', true);
let screen = 'menu';
let li = 0, LEVEL = null, found = new Set(), hints = FREE_HINTS, hintsUsed = 0, won = false;
let elapsed = 0, runStart = 0, timerId = null;

// ---------- الأصوات (WebAudio بلا ملفات) ----------
let actx = null;
function tone(freq, dur, type, vol, delay){
  if(!sound) return;
  try{
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const t0 = actx.currentTime + (delay || 0);
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(freq, t0);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol || 0.15, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(actx.destination); o.start(t0); o.stop(t0 + dur + 0.05);
  }catch(e){}
}
const SFX = {
  found(){ tone(880,.18,'triangle',.18); tone(1320,.25,'triangle',.14,.08); },
  miss(){ tone(180,.18,'square',.06); },
  hint(){ [660,880,1100].forEach((f,i)=>tone(f,.2,'sine',.12,i*.07)); },
  win(){ [523,659,784,1047].forEach((f,i)=>tone(f,.35,'triangle',.16,i*.12)); },
  tap(){ tone(520,.06,'sine',.06); },
};
function haptic(kind){
  try{
    if(N && N.isNative){
      if(kind === 'ok') N.Haptics.notification({ type: N.NotificationType.Success });
      else if(kind === 'bad') N.Haptics.impact({ style: N.ImpactStyle.Light });
      else N.Haptics.impact({ style: N.ImpactStyle.Medium });
    }else if(navigator.vibrate) navigator.vibrate(kind === 'bad' ? 30 : 15);
  }catch(e){}
}

// ---------- أدوات الواجهة ----------
let toastT = null;
function toast(msg){ const el = $('toast'); el.textContent = msg; el.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(()=>el.classList.remove('on'), 1600); }
let modalOpen = false, modalOnClose = null;
function modal(html, onClose){ $('box').innerHTML = html; $('modal').classList.add('show'); modalOpen = true; modalOnClose = onClose || null; }
function closeModal(){ $('modal').classList.remove('show'); modalOpen = false; const f = modalOnClose; modalOnClose = null; if(f) f(); }
const fmt = s => String(Math.floor(s/60)).padStart(2,'0') + ':' + String(s%60).padStart(2,'0');
const starStr = n => '★'.repeat(n) + '☆'.repeat(3-n);

function show(name){
  screen = name;
  $('menu').classList.toggle('on', name === 'menu');
  $('game').classList.toggle('on', name === 'game');
  if(name === 'game') Ads.hideBanner(); else Ads.showBanner();
}

// ---------- القائمة ----------
function renderMenu(){
  document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  $('m-title').textContent = t('title'); $('m-sub').textContent = t('sub');
  const done = Object.keys(stars).length;
  $('progress').textContent = T[lang].progress(done, LEVELS.length);
  const c = $('cards'); c.innerHTML = '';
  LEVELS.forEach((L, i) => {
    const lock = i + 1 > unlocked;
    const b = document.createElement('button');
    b.className = 'lcard' + (lock ? ' lock' : '');
    b.style.backgroundImage = `url('${L.thumb}')`;
    const meta = lock ? `<span>${t('locked')}</span>` :
      `<span class="stars">${stars[i] ? starStr(stars[i]) : '▶ ' + t('play')}</span><span>${best[i] ? fmt(best[i]) : ''}</span>`;
    b.innerHTML = `<div class="shade"></div><span class="num">${i+1}</span>${lock ? '<div class="lockic">🔒</div>' : ''}
      <div class="info"><div class="nm">${L.name[lang]}</div><div class="meta">${meta}</div></div>`;
    b.onclick = () => { if(lock){ SFX.miss(); toast(t('locked')); return; } SFX.tap(); startLevel(i); };
    c.appendChild(b);
  });
  const s = document.createElement('div'); s.className = 'soon'; s.textContent = t('soon'); c.appendChild(s);
  $('b-lang').textContent = t('lang');
  $('b-sound').textContent = sound ? t('soundOn') : t('soundOff');
  $('b-help').textContent = t('help');
  $('b-privacy').textContent = t('privacy');
  $('b-policy').textContent = t('policy');
  $('b-privacy').style.display = Ads.privacyRequired ? '' : 'none';
}
$('b-lang').onclick = () => { lang = lang === 'ar' ? 'fr' : (lang === 'fr' ? 'en' : 'ar'); store.set('lang', lang); renderMenu(); };
$('b-sound').onclick = () => { sound = !sound; store.set('sound', sound); renderMenu(); SFX.tap(); };
$('b-help').onclick = () => showHelp();
$('b-privacy').onclick = () => Ads.showPrivacyOptions();
document.addEventListener('ads-ready', () => { if(screen === 'menu') renderMenu(); });

function showHelp(after){
  modal(`<h2>${t('howTitle')}</h2><p style="text-align:start">${t('how')}</p><button class="btn" id="m-ok">${t('ok')}</button>`, after);
  $('m-ok').onclick = closeModal;
}

// ---------- Pan / Zoom ----------
const view = $('view'), world = $('world');
let scale = 1, minScale = 1, tx = 0, ty = 0;
const MAX_SCALE = 3.2;
function fit(reset){
  const vw = view.clientWidth, vh = view.clientHeight;
  if(!vw || !vh) return;
  minScale = Math.min(Math.max(vw/IMG_W, vh/IMG_H), Math.max(vw/IMG_W, 0.2));
  if(reset || scale < minScale){ scale = minScale; tx = 0; ty = 0; }
  clamp(); apply();
}
function clamp(){
  const vw = view.clientWidth, vh = view.clientHeight, w = IMG_W*scale, h = IMG_H*scale;
  tx = w <= vw ? (vw-w)/2 : Math.min(0, Math.max(vw-w, tx));
  ty = h <= vh ? (vh-h)/2 : Math.min(0, Math.max(vh-h, ty));
}
function apply(){ world.style.transform = `translate(${tx}px,${ty}px) scale(${scale})`; }
function zoomAt(cx, cy, ns){ ns = Math.min(MAX_SCALE, Math.max(minScale, ns)); tx = cx-(cx-tx)*(ns/scale); ty = cy-(cy-ty)*(ns/scale); scale = ns; clamp(); apply(); }

const ptrs = new Map(); let startPt = null, pinchD = 0, pinchS = 1, moved = false, downT = 0;
view.addEventListener('pointerdown', e => {
  if(e.target.closest('#hintbtn')) return;
  try{ view.setPointerCapture(e.pointerId); }catch(_){}
  ptrs.set(e.pointerId, {x:e.clientX, y:e.clientY});
  if(ptrs.size === 1){ startPt = {x:e.clientX, y:e.clientY, tx, ty}; moved = false; downT = Date.now(); }
  if(ptrs.size === 2){ const [a,b] = [...ptrs.values()]; pinchD = Math.hypot(a.x-b.x, a.y-b.y) || 1; pinchS = scale; moved = true; }
});
view.addEventListener('pointermove', e => {
  if(!ptrs.has(e.pointerId)) return;
  ptrs.set(e.pointerId, {x:e.clientX, y:e.clientY});
  const r = view.getBoundingClientRect();
  if(ptrs.size === 2){
    const [a,b] = [...ptrs.values()]; const d = Math.hypot(a.x-b.x, a.y-b.y);
    zoomAt((a.x+b.x)/2 - r.left, (a.y+b.y)/2 - r.top, pinchS*d/pinchD);
  }else if(ptrs.size === 1 && startPt){
    const dx = e.clientX-startPt.x, dy = e.clientY-startPt.y;
    if(Math.hypot(dx,dy) > 10) moved = true;
    if(moved){ tx = startPt.tx+dx; ty = startPt.ty+dy; clamp(); apply(); }
  }
});
function endPtr(e){
  if(!ptrs.has(e.pointerId)) return;
  const was = ptrs.size; ptrs.delete(e.pointerId);
  if(was === 1 && !moved && Date.now()-downT < 600 && e.type === 'pointerup') onTap(e.clientX, e.clientY);
  if(ptrs.size === 1){ const p = [...ptrs.values()][0]; startPt = {x:p.x, y:p.y, tx, ty}; moved = true; }
}
view.addEventListener('pointerup', endPtr); view.addEventListener('pointercancel', endPtr);
view.addEventListener('wheel', e => { e.preventDefault(); const r = view.getBoundingClientRect(); zoomAt(e.clientX-r.left, e.clientY-r.top, scale*(e.deltaY < 0 ? 1.15 : 0.87)); }, {passive:false});
window.addEventListener('resize', () => { if(screen === 'game') fit(false); });

// ---------- منطق اللعب ----------
let missTimes = [], lockedUntil = 0;
function toImg(cx, cy){ const r = view.getBoundingClientRect(); return { x:(cx-r.left-tx)/scale, y:(cy-r.top-ty)/scale }; }
function onTap(cx, cy){
  if(won || !LEVEL || modalOpen) return;
  if(Date.now() < lockedUntil) return;
  const p = toImg(cx, cy);
  const pad = Math.max(8, 14/scale);   // هامش أكبر شوية ملي تكون الصورة صغيرة
  let hit = null;
  for(const o of LEVEL.objects){
    if(found.has(o.id)) continue;
    for(const b of o.boxes){
      if(p.x >= b[0]-pad && p.x <= b[2]+pad && p.y >= b[1]-pad && p.y <= b[3]+pad){
        // نختارو أصغر صندوق إلا تداخلو
        const area = (b[2]-b[0])*(b[3]-b[1]);
        if(!hit || area < hit.area) hit = { o, b, area };
      }
    }
  }
  if(hit){ markFound(hit.o, hit.b); return; }
  const m = document.createElement('div'); m.className = 'miss'; m.textContent = '✗';
  const sz = 50/scale; m.style.left = p.x + 'px'; m.style.top = p.y + 'px'; m.style.width = m.style.height = m.style.lineHeight = sz + 'px'; m.style.margin = (-sz/2) + 'px 0 0 ' + (-sz/2) + 'px'; m.style.fontSize = (46/scale) + 'px';
  world.appendChild(m); setTimeout(() => m.remove(), 700);
  SFX.miss(); haptic('bad');
  // ضد الضغط العشوائي: 5 أخطاء فـ 4 ثواني = توقيف 3 ثواني
  const now = Date.now(); missTimes = missTimes.filter(x => now - x < 4000); missTimes.push(now);
  if(missTimes.length >= 5){
    missTimes = []; lockedUntil = now + 3000;
    $('lockt').textContent = t('slow'); $('lockmsg').style.display = 'flex';
    setTimeout(() => { $('lockmsg').style.display = 'none'; }, 3000);
  }
}
function ringFor(b, cls){
  const d = document.createElement('div'); d.className = cls;
  const w = b[2]-b[0], h = b[3]-b[1], s = Math.max(w, h, 70) + 12;
  const cx = (b[0]+b[2])/2, cy = (b[1]+b[3])/2;
  d.style.width = s+'px'; d.style.height = s+'px'; d.style.left = (cx-s/2)+'px'; d.style.top = (cy-s/2)+'px';
  return d;
}
function markFound(o, b){
  found.add(o.id);
  world.querySelectorAll('.hint').forEach(e => e.remove());
  world.appendChild(ringFor(b, 'mark'));
  SFX.found(); haptic('ok'); toast('✓ ' + o.n[lang]);
  renderStrip(); updateCount();
  if(found.size === LEVEL.objects.length) setTimeout(win, 650);
}

// ---------- التلميحات ----------
function updateHint(){
  const btn = $('hintbtn');
  if(hints > 0){ btn.classList.remove('ad'); $('hn').textContent = hints; }
  else { btn.classList.add('ad'); $('hn').textContent = 'AD'; }
}
function giveHint(){
  const rem = LEVEL.objects.filter(o => !found.has(o.id)); if(!rem.length) return;
  const o = rem[Math.floor(Math.random()*rem.length)], b = o.boxes[0];
  hintsUsed++;
  const vw = view.clientWidth, vh = view.clientHeight, cx = (b[0]+b[2])/2, cy = (b[1]+b[3])/2;
  scale = Math.min(MAX_SCALE, Math.max(scale, minScale*1.6, 0.8));
  tx = vw/2 - cx*scale; ty = vh/2 - cy*scale; clamp(); apply();
  world.querySelectorAll('.hint').forEach(e => e.remove());
  const ring = ringFor(b, 'hint'); world.appendChild(ring); setTimeout(() => ring.remove(), 4500);
  SFX.hint(); haptic();
  // نبيّنو الشي فالشريط
  const it = document.querySelector(`.item[data-id="${o.id}"]`); if(it) it.scrollIntoView({ inline:'center', behavior:'smooth', block:'nearest' });
}
function useHint(){
  if(won || !LEVEL) return;
  if(hints > 0){ hints--; updateHint(); giveHint(); return; }
  pauseTimer();
  modal(`<h2>💡 ${t('noHint')}</h2><p>${t('hintAd')}</p><button class="btn" id="m-watch">${t('watch')}</button><button class="btn alt" id="m-close">${t('close')}</button>`, resumeTimer);
  $('m-close').onclick = closeModal;
  $('m-watch').onclick = async () => {
    if(!Ads.isNative){ closeModal(); giveHint(); return; }          // فالمتصفح: بلا إعلان (للتجربة)
    if(!Ads.rewardedAvailable()){ closeModal(); toast(t('adNA')); return; }
    const ok = await Ads.showRewarded();
    closeModal();
    if(ok) giveHint(); else toast(t('adNA'));
  };
}
$('hintbtn').addEventListener('click', useHint);

// ---------- الشريط ----------
function thumbStyle(b, img){
  const w = b[2]-b[0], h = b[3]-b[1], s = Math.max(w, h) + 16, cx = (b[0]+b[2])/2, cy = (b[1]+b[3])/2;
  const k = 76/s, x = cx - s/2, y = cy - s/2;
  return `background-image:url('${img}');background-size:${IMG_W*k}px ${IMG_H*k}px;background-position:${-x*k}px ${-y*k}px;`;
}
function renderStrip(){
  const s = $('strip'); s.innerHTML = ''; s.dir = lang === 'ar' ? 'rtl' : 'ltr';
  const list = [...LEVEL.objects].sort((a,b) => (found.has(a.id)?1:0) - (found.has(b.id)?1:0));
  for(const o of list){
    const d = document.createElement('div'); d.className = 'item' + (found.has(o.id) ? ' done' : ''); d.dataset.id = o.id;
    d.innerHTML = `<div class="thumb" style="${thumbStyle(o.boxes[0], LEVEL.img)}"></div><div class="name">${o.n[lang]}</div>`;
    s.appendChild(d);
  }
}
function updateCount(){ $('cnt').textContent = `${t('found')}: ${found.size}/${LEVEL.objects.length}`; }

// ---------- الوقت ----------
const curSecs = () => Math.floor((elapsed + (runStart ? Date.now()-runStart : 0)) / 1000);
function tick(){ $('timer').textContent = fmt(curSecs()); }
function startTimer(){ elapsed = 0; runStart = Date.now(); clearInterval(timerId); timerId = setInterval(tick, 500); tick(); }
function pauseTimer(){ if(runStart){ elapsed += Date.now()-runStart; runStart = 0; } }
function resumeTimer(){ if(!runStart && !won && screen === 'game') runStart = Date.now(); }

// ---------- بداية / نهاية المستوى ----------
function startLevel(i){
  li = i; LEVEL = LEVELS[i];
  found = new Set(); hints = FREE_HINTS; hintsUsed = 0; won = false; missTimes = []; lockedUntil = 0;
  world.querySelectorAll('.mark,.hint,.miss').forEach(e => e.remove());
  $('ttl').textContent = `${t('level')} ${i+1} — ${LEVEL.name[lang]}`;
  $('lvl').textContent = '';
  $('timer').textContent = '00:00';
  updateHint(); renderStrip(); updateCount();
  show('game');
  const img = $('scene');
  $('loading').style.display = 'flex'; img.style.visibility = 'hidden';
  const go = () => {
    $('loading').style.display = 'none'; img.style.visibility = 'visible';
    fit(true); startTimer();
    if(!store.get('helped', false)){ store.set('helped', true); pauseTimer(); showHelp(resumeTimer); }
  };
  if(img.getAttribute('src') === LEVEL.img && img.complete){ requestAnimationFrame(go); }
  else { img.onload = go; img.src = LEVEL.img; }
}
function win(){
  if(won) return;
  won = true; pauseTimer(); clearInterval(timerId); tick();
  const secs = curSecs();
  const st = hintsUsed === 0 ? 3 : (hintsUsed <= 2 ? 2 : 1);
  if(!best[li] || secs < best[li]) best[li] = secs;
  if(!stars[li] || st > stars[li]) stars[li] = st;
  if(li + 2 > unlocked) unlocked = Math.min(LEVELS.length, li + 2);
  store.set('best', best); store.set('stars', stars); store.set('unlocked', unlocked);
  SFX.win(); haptic('ok');
  const last = li + 1 >= LEVELS.length;
  const big = `<div class="bigstars">${'★'.repeat(st)}<span class="off">${'★'.repeat(3-st)}</span></div>`;
  modal(`<h2>🎉 ${t('win')}</h2>${big}<p>${t('winTxt')}<br>⏱️ ${t('time')}: ${fmt(secs)} · 💡 ${t('hintsUsed')}: ${hintsUsed}${last ? '<br><br>' + t('allDone') : ''}</p>
    ${last ? '' : `<button class="btn" id="m-next">${t('next')}</button>`}
    <button class="btn alt" id="m-again">${t('again')}</button>
    <button class="btn alt" id="m-menu">${t('menu')}</button>`);
  const after = async (fn) => { closeModal(); await Ads.maybeInterstitial(); fn(); };
  if(!last) $('m-next').onclick = () => after(() => startLevel(li + 1));
  $('m-again').onclick = () => after(() => startLevel(li));
  $('m-menu').onclick = () => after(goMenu);
}
function goMenu(){ $('toast').classList.remove('on'); pauseTimer(); clearInterval(timerId); LEVEL = null; renderMenu(); show('menu'); }
function askQuit(){
  if(won){ goMenu(); return; }
  pauseTimer();
  modal(`<h2>${t('quitQ')}</h2><p>${t('quitTxt')}</p><button class="btn" id="m-no">${t('no')}</button><button class="btn alt" id="m-yes">${t('yes')}</button>`, resumeTimer);
  $('m-no').onclick = closeModal;
  $('m-yes').onclick = () => { modalOnClose = null; closeModal(); goMenu(); };
}
$('b-back').onclick = askQuit;
$('modal').addEventListener('click', e => { if(e.target.id === 'modal' && !won) closeModal(); });

// ---------- Android ----------
document.addEventListener('visibilitychange', () => { if(document.hidden) pauseTimer(); else if(!modalOpen) resumeTimer(); });
if(N && N.isNative){
  try{ N.StatusBar.setStyle({ style: N.Style.Dark }); N.StatusBar.setBackgroundColor({ color: '#2c1f40' }); }catch(e){}
  try{
    N.App.addListener('backButton', () => {
      if(modalOpen){ if(!won) closeModal(); return; }
      if(screen === 'game'){ askQuit(); return; }
      N.App.exitApp();
    });
  }catch(e){}
}

// ---------- البداية ----------
renderMenu(); show('menu');
Ads.init().finally(() => {
  if(screen !== 'game') Ads.showBanner();
  renderMenu();
  try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){}
});
// احتياط: نخبيو الـ splash حتى إلا تعطّل AdMob
setTimeout(() => { try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} }, 2500);

// للتجربة فقط
window.__rs = { get LEVEL(){ return LEVEL; }, get found(){ return found; }, startLevel, onTap, apply, get view(){ return view; },
  setView(s, x, y){ scale = s; tx = x; ty = y; apply(); }, get state(){ return { scale, tx, ty, unlocked, stars, best, hints, won, screen }; } };
})();
