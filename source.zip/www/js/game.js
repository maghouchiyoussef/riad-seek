// حروف وكلمات — لعبة كلمات عربية
(function(){
'use strict';
const N = window.Native;
const Ads = window.Ads || { init:async()=>{}, showBanner(){}, hideBanner(){}, maybeInterstitial:async()=>{}, rewardedAvailable:()=>false, showRewarded:async()=>false, showPrivacyOptions(){}, isNative:false, privacyRequired:false };
const $ = id => document.getElementById(id);
const HINT_COST = 30, VIDEO_REWARD = 30, LEVEL_REWARD = 10, BONUS_REWARD = 5;

// ---------- حفظ ----------
const store = {
  get(k, d){ try{ const v = localStorage.getItem('kz_' + k); return v === null ? d : JSON.parse(v); }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem('kz_' + k, JSON.stringify(v)); }catch(e){} },
};
let level = store.get('level', 0);           // المستوى الحالي (0-index)
let coins = store.get('coins', 60);
let sound = store.get('sound', true);
let st = store.get('st', null);              // حالة المستوى الحالي: {level, found:[], revealed:[], bonus:[]}
let screen = 'menu';

// ---------- أصوات ----------
let actx = null;
function tone(f, d, type, v, delay){
  if(!sound) return;
  try{
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const t0 = actx.currentTime + (delay || 0), o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(v || .12, t0 + .015); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    o.connect(g); g.connect(actx.destination); o.start(t0); o.stop(t0 + d + .05);
  }catch(e){}
}
const SFX = {
  tick(n){ tone(420 + n*70, .08, 'triangle', .08); },
  ok(){ [660, 880, 1100].forEach((f,i)=>tone(f, .18, 'triangle', .13, i*.07)); },
  bad(){ tone(170, .2, 'square', .05); },
  bonus(){ [990, 1320].forEach((f,i)=>tone(f, .15, 'sine', .12, i*.08)); },
  win(){ [523, 659, 784, 1047, 1319].forEach((f,i)=>tone(f, .3, 'triangle', .14, i*.1)); },
  coin(){ tone(1500, .07, 'square', .04); },
};
function haptic(kind){
  try{
    if(N && N.isNative){
      if(kind === 'ok') N.Haptics.notification({ type: N.NotificationType.Success });
      else N.Haptics.impact({ style: kind === 'bad' ? N.ImpactStyle.Medium : N.ImpactStyle.Light });
    }else if(navigator.vibrate) navigator.vibrate(kind === 'bad' ? 40 : 10);
  }catch(e){}
}

// ---------- واجهة عامة ----------
let toastT;
function toast(m){ const e = $('toast'); e.textContent = m; e.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(()=>e.classList.remove('on'), 1500); }
let modalOpen = false;
function modal(html){ $('box').innerHTML = html; $('modal').classList.add('show'); modalOpen = true; }
function closeModal(){ $('modal').classList.remove('show'); modalOpen = false; }
$('modal').addEventListener('click', e => { if(e.target.id === 'modal' && !levelDone) closeModal(); });
function setCoins(n){ coins = Math.max(0, n); store.set('coins', coins); $('coins').textContent = coins; $('m-coins').textContent = coins; }
function show(name){
  screen = name;
  $('menu').classList.toggle('on', name === 'menu');
  $('game').classList.toggle('on', name === 'game');
  Ads.showBanner();
}

// ---------- القائمة ----------
function renderMenu(){
  setCoins(coins);
  $('b-play').textContent = level === 0 && !st ? 'العب' : 'تابع اللعب';
  $('m-lvl').textContent = level < LEVELS.length ? `المستوى ${level + 1} من ${LEVELS.length}` : 'كمّلت جميع المستويات! 🎉';
  $('b-sound').textContent = sound ? '🔊 الصوت' : '🔇 الصوت';
  $('b-privacy').style.display = Ads.privacyRequired ? '' : 'none';
}
$('b-play').onclick = () => { if(level >= LEVELS.length){ toast('مستويات جديدة قريباً ✨'); return; } startLevel(); };
$('b-sound').onclick = () => { sound = !sound; store.set('sound', sound); renderMenu(); };
$('b-privacy').onclick = () => Ads.showPrivacyOptions();
$('b-home').onclick = () => goMenu();
document.addEventListener('ads-ready', () => { if(screen === 'menu') renderMenu(); });

// ---------- المستوى ----------
let L = null, cells = {}, wordsFound = new Set(), revealed = new Set(), bonusFound = new Set(), levelDone = false, letters = [];
const key = (r, c) => r + ',' + c;
function cellsOf(p){ const out = []; for(let i = 0; i < p.w.length; i++) out.push(key(p.r + (p.d === 'v' ? i : 0), p.c + (p.d === 'h' ? i : 0))); return out; }

function startLevel(){
  L = LEVELS[level]; levelDone = false;
  if(!st || st.level !== level) st = { level, found: [], revealed: [], bonus: [] };
  wordsFound = new Set(st.found); revealed = new Set(st.revealed); bonusFound = new Set(st.bonus);
  letters = L.letters.slice();
  shuffleLetters(false);
  $('lvl').textContent = `المستوى ${level + 1}`;
  show('game');
  requestAnimationFrame(() => { layout(); });
  updateBonus();
}
function save(){ st.found = [...wordsFound]; st.revealed = [...revealed]; st.bonus = [...bonusFound]; store.set('st', st); }

// الشبكة
function layout(){
  // أبعاد الشبكة
  buildWheel();
  const grid0 = $('grid'); grid0.style.width = grid0.style.height = '0px'; grid0.innerHTML = '';
  const gw = $('gridwrap'), availW = gw.clientWidth - 16, availH = gw.clientHeight - 12;
  const size = Math.floor(Math.min(56, availW / L.w, availH / L.h));
  const gap = Math.max(3, Math.round(size * .08));
  const grid = $('grid'); grid.innerHTML = ''; cells = {};
  grid.style.width = (L.w * size) + 'px'; grid.style.height = (L.h * size) + 'px';
  for(const p of L.words){
    cellsOf(p).forEach((k, i) => {
      if(cells[k]) return;
      const [r, c] = k.split(',').map(Number);
      const d = document.createElement('div'); d.className = 'cell';
      d.style.width = d.style.height = (size - gap) + 'px';
      d.style.top = (r * size) + 'px'; d.style.right = (c * size) + 'px';   // من اليمين لليسار
      d.style.fontSize = Math.round(size * .55) + 'px';
      d.dataset.ch = p.w[i];
      grid.appendChild(d); cells[k] = d;
    });
  }
  // نعاودو نبيّنو اللي تلقى
  for(const p of L.words) if(wordsFound.has(p.w)) cellsOf(p).forEach(k => showCell(k, false));
  for(const k of revealed) if(cells[k] && !cells[k].classList.contains('show')){ cells[k].classList.add('hint'); cells[k].textContent = cells[k].dataset.ch; }
}
function showCell(k, anim){
  const d = cells[k]; if(!d) return;
  d.classList.remove('hint'); d.textContent = d.dataset.ch;
  if(anim){ d.style.animationDelay = '0s'; }
  d.classList.add('show');
}

// العجلة
let wheelSize = 260, pos = [];
function buildWheel(){
  const w = $('wheel');
  const maxW = Math.min(window.innerWidth - 150, 300), maxH = Math.max(180, window.innerHeight * .34);
  wheelSize = Math.max(200, Math.min(maxW, maxH));
  w.style.width = w.style.height = wheelSize + 'px';
  w.querySelectorAll('.lt').forEach(e => e.remove());
  const n = letters.length, R = wheelSize / 2 - 40, cx = wheelSize / 2, cy = wheelSize / 2;
  pos = [];
  letters.forEach((ch, i) => {
    const a = -Math.PI / 2 + i * 2 * Math.PI / n;
    const x = cx + R * Math.cos(a), y = cy + R * Math.sin(a);
    pos.push({ x, y });
    const e = document.createElement('div'); e.className = 'lt'; e.textContent = ch; e.dataset.i = i;
    e.style.left = x + 'px'; e.style.top = y + 'px';
    if(n >= 6){ e.style.width = e.style.height = '50px'; e.style.margin = '-25px 0 0 -25px'; e.style.fontSize = '26px'; }
    w.appendChild(e);
  });
  $('lines').setAttribute('viewBox', `0 0 ${wheelSize} ${wheelSize}`);
  drawLines();
}
function shuffleLetters(rebuild){
  for(let i = letters.length - 1; i > 0; i--){ const j = Math.floor(Math.random() * (i + 1)); [letters[i], letters[j]] = [letters[j], letters[i]]; }
  if(rebuild) buildWheel();
}
$('b-shuffle').onclick = () => { if(dragging) return; shuffleLetters(true); tone(600, .08, 'sine', .06); };

// السحب
let sel = [], dragging = false, cur = null;
const wheel = $('wheel');
function hit(x, y){
  const r = wheel.getBoundingClientRect(), px = x - r.left, py = y - r.top, rad = letters.length >= 6 ? 27 : 31;
  for(let i = 0; i < pos.length; i++){ const dx = px - pos[i].x, dy = py - pos[i].y; if(dx*dx + dy*dy < rad*rad) return i; }
  return -1;
}
function setWordPreview(){
  const s = $('word').firstElementChild; s.className = sel.length ? 'on' : ''; s.textContent = sel.map(i => letters[i]).join('');
}
function drawLines(){
  const svg = $('lines'); let h = '';
  for(let i = 1; i < sel.length; i++){ const a = pos[sel[i-1]], b = pos[sel[i]]; h += `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#1f6fd1" stroke-width="9" stroke-linecap="round" opacity=".85"/>`; }
  if(dragging && sel.length && cur){ const a = pos[sel[sel.length-1]]; h += `<line x1="${a.x}" y1="${a.y}" x2="${cur.x}" y2="${cur.y}" stroke="#1f6fd1" stroke-width="9" stroke-linecap="round" opacity=".5"/>`; }
  svg.innerHTML = h;
  wheel.querySelectorAll('.lt').forEach(e => e.classList.toggle('sel', sel.includes(+e.dataset.i)));
}
wheel.addEventListener('pointerdown', e => {
  if(levelDone || modalOpen) return;
  const i = hit(e.clientX, e.clientY); if(i < 0) return;
  try{ wheel.setPointerCapture(e.pointerId); }catch(_){}
  dragging = true; sel = [i]; SFX.tick(0); haptic(); setWordPreview(); drawLines();
});
wheel.addEventListener('pointermove', e => {
  if(!dragging) return;
  const r = wheel.getBoundingClientRect(); cur = { x: e.clientX - r.left, y: e.clientY - r.top };
  const i = hit(e.clientX, e.clientY);
  if(i >= 0){
    if(!sel.includes(i)){ sel.push(i); SFX.tick(sel.length); haptic(); setWordPreview(); }
    else if(sel.length > 1 && sel[sel.length-2] === i){ sel.pop(); setWordPreview(); }   // رجوع
  }
  drawLines();
});
function endDrag(){
  if(!dragging) return;
  dragging = false; cur = null; drawLines();
  const w = sel.map(i => letters[i]).join(''); sel = [];
  if(w.length >= 2) check(w); else { setWordPreview(); drawLines(); }
}
wheel.addEventListener('pointerup', endDrag); wheel.addEventListener('pointercancel', endDrag);

// التحقق
function flash(cls, text){
  const s = $('word').firstElementChild; s.textContent = text; s.className = 'on ' + cls;
  setTimeout(() => { s.className = ''; drawLines(); }, 650);
}
function check(w){
  const p = L.words.find(x => x.w === w);
  if(p){
    if(wordsFound.has(w)){ flash('dup', w); toast('لقيتها من قبل'); return; }
    wordsFound.add(w); cellsOf(p).forEach((k, i) => setTimeout(() => showCell(k, true), i * 70));
    flash('', w); SFX.ok(); haptic('ok'); save();
    if(wordsFound.size === L.words.length) setTimeout(win, 650 + w.length * 70);
    return;
  }
  if(L.bonus.includes(w)){
    if(bonusFound.has(w)){ flash('dup', w); toast('لقيتها من قبل'); return; }
    bonusFound.add(w); flash('bonus', w); SFX.bonus(); toast(`⭐ كلمة إضافية! +${BONUS_REWARD}`); setCoins(coins + BONUS_REWARD); updateBonus(); save();
    return;
  }
  flash('bad', w); SFX.bad(); haptic('bad');
}
function updateBonus(){ $('bonusn').textContent = bonusFound.size + '/' + L.bonus.length; $('b-bonus').style.visibility = L.bonus.length ? 'visible' : 'hidden'; }
$('b-bonus').onclick = () => {
  const list = [...bonusFound];
  modal(`<h2>⭐</h2><p>كلمات إضافية مخفية فهاد المستوى: <b>${L.bonus.length}</b><br>لقيتي: <b>${list.length}</b>${list.length ? '<br>' + list.join(' ، ') : ''}<br><small>كل كلمة إضافية = ${BONUS_REWARD} قطع نقدية</small></p><button class="big" id="m-ok">حسناً</button>`);
  $('m-ok').onclick = closeModal;
};

// التلميح
$('b-hint').onclick = () => {
  if(levelDone) return;
  if(coins < HINT_COST){ offerVideo(true); return; }
  const empties = [];
  for(const p of L.words){ if(wordsFound.has(p.w)) continue; cellsOf(p).forEach(k => { if(!revealed.has(k) && !cells[k].classList.contains('show')) empties.push(k); }); }
  if(!empties.length) return;
  // نفضّلو أول حرف فكلمة ناقصة
  const k = empties[Math.floor(Math.random() * empties.length)];
  revealed.add(k); const d = cells[k]; d.classList.add('hint'); d.textContent = d.dataset.ch; d.style.animation = 'pop .35s';
  setCoins(coins - HINT_COST); SFX.coin(); save();
  // إلا كملات شي كلمة بالتلميحات
  for(const p of L.words){
    if(wordsFound.has(p.w)) continue;
    if(cellsOf(p).every(c => revealed.has(c) || cells[c].classList.contains('show'))){ wordsFound.add(p.w); cellsOf(p).forEach(c => showCell(c, true)); }
  }
  save();
  if(wordsFound.size === L.words.length) setTimeout(win, 600);
};

// الفيديو
function offerVideo(needCoins){
  modal(`<h2>🎬</h2><p>${needCoins ? 'ما عندكش قطع نقدية كافية.<br>' : ''}شاهد فيديو قصير وخود <b>${VIDEO_REWARD}</b> قطعة نقدية.</p><button class="big" id="m-watch">شاهد الفيديو</button><button class="alt" id="m-no">لا، شكراً</button>`);
  $('m-no').onclick = closeModal;
  $('m-watch').onclick = async () => {
    if(!Ads.isNative){ closeModal(); reward(); return; }           // فالمتصفح: بلا إعلان (للتجربة)
    if(!Ads.rewardedAvailable()){ closeModal(); toast('ما كاين حتى فيديو دابا، عاود من بعد'); return; }
    const ok = await Ads.showRewarded(); closeModal();
    if(ok) reward(); else toast('ما كاين حتى فيديو دابا، عاود من بعد');
  };
}
function reward(){ setCoins(coins + VIDEO_REWARD); SFX.coin(); toast(`+${VIDEO_REWARD} 🪙`); }
$('b-video').onclick = () => offerVideo(false);

// الفوز
function win(){
  if(levelDone) return;
  levelDone = true; SFX.win(); haptic('ok');
  setCoins(coins + LEVEL_REWARD);
  level++; store.set('level', level); st = null; store.set('st', null);
  const last = level >= LEVELS.length;
  const praise = ['ممتاز!', 'رائع!', 'أحسنت!', 'مذهل!', 'عبقري!'][Math.floor(Math.random() * 5)];
  modal(`<h2>${praise}</h2><p>كمّلت المستوى ${level}<br>+${LEVEL_REWARD} 🪙${last ? '<br><br>كمّلت جميع المستويات! مستويات جديدة قريباً ✨' : ''}</p>
    ${last ? '' : '<button class="big" id="m-next">المستوى التالي</button>'}<button class="alt" id="m-menu">القائمة</button>`);
  if(!last) $('m-next').onclick = async () => { closeModal(); await Ads.maybeInterstitial(); startLevel(); };
  $('m-menu').onclick = () => { closeModal(); goMenu(); };
}
function goMenu(){ renderMenu(); show('menu'); }

// ---------- Android ----------
window.addEventListener('resize', () => { if(screen === 'game' && L) layout(); });
if(N && N.isNative){
  try{ N.StatusBar.setStyle({ style: N.Style.Light }); N.StatusBar.setBackgroundColor({ color: '#f4f9ff' }); }catch(e){}
  try{ N.App.addListener('backButton', () => { if(modalOpen){ if(!levelDone) closeModal(); return; } if(screen === 'game'){ goMenu(); return; } N.App.exitApp(); }); }catch(e){}
}

renderMenu(); show('menu');
Ads.init().finally(() => { Ads.showBanner(); renderMenu(); try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} });
setTimeout(() => { try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} }, 2500);

// للتجربة
window.__kz = { check, get L(){ return L; }, get level(){ return level; }, get coins(){ return coins; }, startLevel, get found(){ return wordsFound; } };
})();
