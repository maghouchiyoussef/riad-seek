// تحدي المليون — مسابقة ثقافية
(function(){
'use strict';
const N = window.Native;
const Ads = window.Ads || { init:async()=>{}, showBanner(){}, hideBanner(){}, maybeInterstitial:async()=>{}, rewardedAvailable:()=>false, showRewarded:async()=>false, showPrivacyOptions(){}, isNative:false, privacyRequired:false };
const $ = id => document.getElementById(id);
const PRIZES = [100, 200, 300, 500, 1000, 2000, 4000, 8000, 16000, 32000, 64000, 125000, 250000, 500000, 1000000];
const SAFE = [4, 9];                 // بعد السؤال 5 و 10 النقاط مضمونة
const TIERS = [1,1,1,1,1, 2,2,2,2,2, 3,3,3,3,3];
const TIME = [30,30,30,30,30, 40,40,40,40,40, 45,45,45,45,45];
const LETTERS = ['أ','ب','ج','د'];
const fmt = n => n.toLocaleString('en-US');

const store = {
  get(k, d){ try{ const v = localStorage.getItem('tm_' + k); return v === null ? d : JSON.parse(v); }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem('tm_' + k, JSON.stringify(v)); }catch(e){} },
};
let best = store.get('best', 0), games = store.get('games', 0), sound = store.get('sound', true), total = store.get('total', 0);
// ---------- المستويات (حسب مجموع النقاط) ----------
const MAX_LVL = 100;
const need = l => Math.round(3000 * Math.pow(l - 1, 1.6));          // النقاط اللازمة للوصول للمستوى l
const levelOf = t => { let l = 1; while(l < MAX_LVL && t >= need(l + 1)) l++; return l; };
const RANKS = ['مبتدئ','هاوٍ','مثقف','متمكّن','خبير','محترف','عبقري','نابغة','أسطورة','ملك المعرفة'];
const rankOf = l => RANKS[Math.min(RANKS.length - 1, Math.floor((l - 1) / 10))];
let seen = new Set(store.get('seen', []));   // الأسئلة اللي تشافت (باش ما تتعاودش بزربة)

// ---------- أصوات ----------
let actx = null;
function tone(f, d, type, v, delay){
  if(!sound) return;
  try{
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const t0 = actx.currentTime + (delay || 0), o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(v || .12, t0 + .02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    o.connect(g); g.connect(actx.destination); o.start(t0); o.stop(t0 + d + .05);
  }catch(e){}
}
const SFX = {
  sel(){ tone(500, .12, 'sine', .1); },
  ok(){ [523, 659, 784, 1047].forEach((f,i)=>tone(f, .25, 'triangle', .14, i*.09)); },
  bad(){ tone(220, .35, 'sawtooth', .07); tone(160, .45, 'sawtooth', .07, .2); },
  tick(){ tone(900, .04, 'square', .03); },
  life(){ [700, 900].forEach((f,i)=>tone(f, .15, 'sine', .1, i*.08)); },
  win(){ [523,659,784,1047,1319,1568].forEach((f,i)=>tone(f, .35, 'triangle', .14, i*.12)); },
};
function haptic(k){ try{ if(N && N.isNative){ k === 'ok' ? N.Haptics.notification({ type: N.NotificationType.Success }) : N.Haptics.impact({ style: k === 'bad' ? N.ImpactStyle.Heavy : N.ImpactStyle.Light }); } else if(navigator.vibrate) navigator.vibrate(k === 'bad' ? 60 : 12); }catch(e){} }

// ---------- واجهة ----------
let toastT;
function toast(m){ const e = $('toast'); e.textContent = m; e.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(()=>e.classList.remove('on'), 1600); }
let modalOpen = false;
function modal(html){ $('box').innerHTML = html; $('modal').classList.add('show'); modalOpen = true; }
function closeModal(){ $('modal').classList.remove('show'); modalOpen = false; }
let screen = 'menu';
function show(n){ screen = n; $('menu').classList.toggle('on', n === 'menu'); $('game').classList.toggle('on', n === 'game'); Ads.showBanner(); }

function renderMenu(){
  $('best').textContent = fmt(best); $('games').textContent = games; $('total').textContent = fmt(total);
  const l = levelOf(total), a = need(l), b = need(Math.min(MAX_LVL, l + 1));
  $('rk-title').textContent = '🏅 ' + rankOf(l); $('rk-lvl').textContent = `المستوى ${l} / ${MAX_LVL}`;
  $('rk-bar').style.width = (l >= MAX_LVL ? 100 : Math.min(100, (total - a) / (b - a) * 100)) + '%';
  $('rk-sub').textContent = l >= MAX_LVL ? 'وصلت إلى أعلى مستوى! 👑' : `باقي ${fmt(b - total)} نقطة للمستوى ${l + 1}`;
  $('b-sound').textContent = sound ? '🔊 الصوت' : '🔇 الصوت';
  $('b-privacy').style.display = Ads.privacyRequired ? '' : 'none';
}
$('b-sound').onclick = () => { sound = !sound; store.set('sound', sound); renderMenu(); };
$('b-privacy').onclick = () => Ads.showPrivacyOptions();
$('b-howto').onclick = () => {
  modal(`<h2>طريقة اللعب</h2><p style="text-align:start">❓ أجب عن 15 سؤالاً تزداد صعوبتها تدريجياً.<br>🏆 كل إجابة صحيحة ترفعك في سلّم النقاط حتى المليون.<br>🛡️ بعد السؤال 5 والسؤال 10 تصبح نقاطك مضمونة.<br>🆘 لديك 3 وسائل مساعدة: حذف إجابتين، رأي الجمهور، وتغيير السؤال.<br>🏳️ يمكنك الانسحاب في أي وقت والاحتفاظ بنقاطك.</p><button class="big" id="m-ok">فهمت</button>`);
  $('m-ok').onclick = closeModal;
};
document.addEventListener('ads-ready', () => { if(screen === 'menu') renderMenu(); });

// ---------- اختيار الأسئلة ----------
const shuffle = a => { for(let i = a.length - 1; i > 0; i--){ const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
function pickQuestion(tier, used){
  let pool = QUESTIONS.map((q, i) => i).filter(i => QUESTIONS[i].t === tier && !used.has(i));
  let fresh = pool.filter(i => !seen.has(i));
  if(!fresh.length){ // كاع الأسئلة ديال هاد المستوى تشافو: نبداو من جديد
    QUESTIONS.forEach((q, i) => { if(q.t === tier) seen.delete(i); });
    fresh = pool;
  }
  const i = fresh[Math.floor(Math.random() * fresh.length)];
  used.add(i); seen.add(i); store.set('seen', [...seen]);
  const q = QUESTIONS[i];
  const opts = shuffle(q.a.map((txt, k) => ({ txt, ok: k === 0 })));
  return { cat: q.c, q: q.q, opts };
}

// ---------- اللعب ----------
let step = 0, cur = null, used = new Set(), lifelines = {}, locked = false, secondChance = true, timerId = null, tLeft = 0, tTotal = 30;
function start(){
  step = 0; used = new Set(); lifelines = { f: true, a: true, s: true }; secondChance = true;
  ['l-50','l-aud','l-swap'].forEach(id => $(id).disabled = false);
  games++; store.set('games', games);
  show('game'); next();
}
$('b-play').onclick = start;

function renderLadderBar(){
  $('ladderbar').innerHTML = PRIZES.map((p, i) => `<i class="${i < step ? 'done' : i === step ? 'cur' : ''} ${SAFE.includes(i) ? 'safe' : ''}"></i>`).join('');
}
function next(){
  locked = false;
  cur = pickQuestion(TIERS[step], used);
  $('qn').textContent = `السؤال ${step + 1} من 15`;
  $('pz').textContent = `${fmt(PRIZES[step])} نقطة`;
  $('cat').textContent = cur.cat;
  $('q').textContent = cur.q;
  $('answers').innerHTML = cur.opts.map((o, i) => `<button class="ans" data-i="${i}"><b>${LETTERS[i]}</b><span>${o.txt}</span></button>`).join('');
  $('answers').querySelectorAll('.ans').forEach(b => b.onclick = () => choose(+b.dataset.i));
  renderLadderBar();
  startTimer(TIME[step]);
}
function startTimer(sec){
  clearInterval(timerId); tTotal = sec; tLeft = sec; drawTimer();
  timerId = setInterval(() => {
    if(modalOpen) return;            // نوقفو الوقت ملي تكون نافذة مفتوحة
    tLeft -= 0.25; drawTimer();
    if(tLeft <= 5 && Math.abs(tLeft - Math.round(tLeft)) < .01 && tLeft > 0) SFX.tick();
    if(tLeft <= 0){ clearInterval(timerId); timeUp(); }
  }, 250);
}
function drawTimer(){
  $('tnum').textContent = Math.max(0, Math.ceil(tLeft));
  const frac = Math.max(0, tLeft / tTotal);
  $('tarc').setAttribute('stroke-dashoffset', (131.9 * (1 - frac)).toFixed(1));
  $('tarc').setAttribute('stroke', frac > .33 ? '#f5c542' : '#e5484d');
}
function choose(i){
  if(locked) return;
  locked = true; clearInterval(timerId);
  const btns = [...$('answers').querySelectorAll('.ans')];
  btns[i].classList.add('sel'); SFX.sel();
  const okIdx = cur.opts.findIndex(o => o.ok);
  setTimeout(() => {
    btns[i].classList.remove('sel');
    if(i === okIdx){
      btns[i].classList.add('ok'); SFX.ok(); haptic('ok');
      setTimeout(() => {
        step++;
        if(step === 15){ finish(PRIZES[14], true); return; }
        if(SAFE.includes(step - 1)) toast(`🛡️ ${fmt(PRIZES[step - 1])} نقطة مضمونة!`);
        next();
      }, 1300);
    }else{
      btns[i].classList.add('bad'); btns[okIdx].classList.add('ok'); SFX.bad(); haptic('bad');
      setTimeout(() => lose('wrong'), 1500);
    }
  }, 1200);
}
function timeUp(){
  if(locked) return; locked = true;
  const okIdx = cur.opts.findIndex(o => o.ok);
  $('answers').querySelectorAll('.ans')[okIdx].classList.add('ok'); SFX.bad(); haptic('bad');
  setTimeout(() => lose('time'), 1300);
}
function safePoints(){ let p = 0; SAFE.forEach(s => { if(step > s) p = PRIZES[s]; }); return p; }
function lose(why){
  // فرصة ثانية بإعلان (مرة وحدة فكل محاولة)
  if(secondChance && step >= 2){
    modal(`<h2>${why === 'time' ? 'انتهى الوقت!' : 'إجابة خاطئة!'}</h2><p>هل تريد فرصة ثانية؟<br>شاهد فيديو قصيراً وأكمل من نفس المرحلة بسؤال جديد.</p><button class="big" id="m-sc">🎬 فرصة ثانية</button><button class="alt" id="m-end">لا، أنهِ اللعبة</button>`);
    $('m-end').onclick = () => { closeModal(); finish(safePoints(), false); };
    $('m-sc').onclick = async () => {
      let ok = false;
      if(!Ads.isNative) ok = true;                  // فالمتصفح (للتجربة)
      else if(Ads.rewardedAvailable()) ok = await Ads.showRewarded();
      closeModal();
      if(ok){ secondChance = false; toast('فرصة ثانية! 💪'); next(); }
      else { toast('لا يوجد فيديو الآن'); finish(safePoints(), false); }
    };
    return;
  }
  finish(safePoints(), false);
}
$('b-quit').onclick = () => {
  if(locked) return;
  const keep = step > 0 ? PRIZES[step - 1] : 0;
  modal(`<h2>الانسحاب؟</h2><p>ستنسحب وتحتفظ بـ <b>${fmt(keep)}</b> نقطة.</p><button class="big" id="m-stay">أكمل اللعب</button><button class="alt" id="m-go">انسحب</button>`);
  $('m-stay').onclick = closeModal;
  $('m-go').onclick = () => { closeModal(); clearInterval(timerId); finish(keep, false); };
};
function finish(points, won){
  clearInterval(timerId); locked = true;
  const record = points > best; if(record){ best = points; store.set('best', best); }
  const lvlBefore = levelOf(total); total += points; store.set('total', total); const lvlAfter = levelOf(total);
  const up = lvlAfter > lvlBefore ? `<br>⬆️ وصلت إلى المستوى <b>${lvlAfter}</b> (${rankOf(lvlAfter)})` : '';
  if(won){ SFX.win(); haptic('ok'); }
  modal(`<h2>${won ? '🏆 مبروك المليون!' : (points ? 'انتهت المحاولة' : 'حظاً أوفر')}</h2>
    <p>${won ? 'أجبت عن الأسئلة الخمسة عشر كلها!' : `وصلت إلى السؤال ${Math.min(step + 1, 15)}`}<br>نقاطك: <b style="color:var(--gold);font-size:22px">${fmt(points)}</b>${record && points ? '<br>🎉 رقم قياسي جديد!' : ''}${up}</p>
    <button class="big" id="m-again">العب مرة أخرى</button><button class="alt" id="m-menu">القائمة</button>`);
  const after = async (fn) => { closeModal(); await Ads.maybeInterstitial(); fn(); };
  $('m-again').onclick = () => after(start);
  $('m-menu').onclick = () => after(() => { renderMenu(); show('menu'); });
}

// ---------- وسائل المساعدة ----------
$('l-50').onclick = () => {
  if(locked || !lifelines.f) return; lifelines.f = false; $('l-50').disabled = true; SFX.life();
  const btns = [...$('answers').querySelectorAll('.ans')];
  const wrong = shuffle(cur.opts.map((o, i) => i).filter(i => !cur.opts[i].ok)).slice(0, 2);
  wrong.forEach(i => { btns[i].classList.add('gone'); cur.opts[i].gone = true; });
};
$('l-aud').onclick = () => {
  if(locked || !lifelines.a) return; lifelines.a = false; $('l-aud').disabled = true; SFX.life();
  // الجمهور كيعرف الأسئلة السهلة أكثر من الصعيبة
  const acc = [0.85, 0.65, 0.45][TIERS[step] - 1];
  const live = cur.opts.map((o, i) => i).filter(i => !cur.opts[i].gone);
  const okIdx = cur.opts.findIndex(o => o.ok);
  let pct = {}; let rest = 100;
  const okP = Math.round((acc + Math.random() * 0.12) * 100 * (live.length === 2 ? 1.1 : 1));
  pct[okIdx] = Math.min(95, okP); rest -= pct[okIdx];
  const others = live.filter(i => i !== okIdx);
  others.forEach((i, k) => { const v = k === others.length - 1 ? rest : Math.round(rest * (0.2 + Math.random() * 0.6)); pct[i] = v; rest -= v; });
  // أحياناً فالأسئلة الصعيبة الجمهور كيغلط
  if(TIERS[step] === 3 && Math.random() < 0.15 && others.length){ const w = others[0]; [pct[okIdx], pct[w]] = [pct[w], pct[okIdx]]; }
  const bars = cur.opts.map((o, i) => `<div style="height:${(pct[i] || 0) * 1.3 + 4}px"><span>${pct[i] || 0}%</span><em>${LETTERS[i]}</em></div>`).join('');
  modal(`<h2>👥 رأي الجمهور</h2><div class="bars">${bars}</div><br><button class="big" id="m-ok">حسناً</button>`);
  $('m-ok').onclick = closeModal;
};
$('l-swap').onclick = () => {
  if(locked || !lifelines.s) return; lifelines.s = false; $('l-swap').disabled = true; SFX.life();
  next();
};
$('b-ladder').onclick = () => {
  const list = PRIZES.map((p, i) => `<li class="${i === step ? 'cur' : i < step ? 'done' : ''} ${SAFE.includes(i) ? 'safe' : ''}"><span>${i + 1}</span><span>${fmt(p)}${SAFE.includes(i) ? ' 🛡️' : ''}</span></li>`).reverse().join('');
  modal(`<h2>سلّم النقاط</h2><ul class="ladder">${list}</ul><button class="big" id="m-ok">رجوع</button>`);
  $('m-ok').onclick = closeModal;
};

// ---------- Android ----------
if(N && N.isNative){
  try{ N.StatusBar.setStyle({ style: N.Style.Dark }); N.StatusBar.setBackgroundColor({ color: '#0b2a5b' }); }catch(e){}
  try{ N.App.addListener('backButton', () => { if(modalOpen){ return; } if(screen === 'game'){ $('b-quit').click(); return; } N.App.exitApp(); }); }catch(e){}
}
document.addEventListener('visibilitychange', () => { /* الوقت كيتوقف غير ملي النافذة مفتوحة */ });

renderMenu(); show('menu');
Ads.init().finally(() => { Ads.showBanner(); renderMenu(); try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} });
setTimeout(() => { try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} }, 2500);
window.__tm = { get cur(){ return cur; }, get step(){ return step; }, choose, start };
})();
