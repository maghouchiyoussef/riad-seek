// مجلسي — لعبة دمج بلمسة خليجية
(function(){
'use strict';
const N = window.Native;
const Ads = window.Ads || { init:async()=>{}, showBanner(){}, hideBanner(){}, maybeInterstitial:async()=>{}, rewardedAvailable:()=>false, showRewarded:async()=>false, showPrivacyOptions(){}, isNative:false, privacyRequired:false };
const E = window.Engine;
const $ = id => document.getElementById(id);
const VIDEO_ENERGY = 40, BUY_ENERGY = 30, BUY_COST = 60;
const GUESTS = ['🧕', '👳‍♂️', '👵', '👧', '🧔', '👩'];

// ---------- حفظ ----------
const store = {
  get(k, d){ try{ const v = localStorage.getItem('mj_' + k); return v === null ? d : JSON.parse(v); }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem('mj_' + k, JSON.stringify(v)); }catch(e){} },
};
let S = store.get('state', null);
const firstRun = !S;
if(!S){ S = E.newState(Date.now()); S.seed = (Math.random() * 1e9) | 0; S.orders = [E.makeOrder(S, true), E.makeOrder(S, true), E.makeOrder(S)]; }
let sound = store.get('sound', true);
const save = () => store.set('state', S);

// ---------- أصوات ----------
let actx = null;
function tone(f, d, type, v, delay){
  if(!sound) return;
  try{
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const t0 = actx.currentTime + (delay || 0), o = actx.createOscillator(), gg = actx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0);
    gg.gain.setValueAtTime(0.0001, t0); gg.gain.exponentialRampToValueAtTime(v || .1, t0 + .012); gg.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    o.connect(gg); gg.connect(actx.destination); o.start(t0); o.stop(t0 + d + .05);
  }catch(e){}
}
const SFX = {
  pop(){ tone(520, .08, 'triangle', .07); tone(780, .06, 'sine', .03, .03); },
  merge(t){ const f = [523, 587, 659, 784, 880, 1047][Math.min(5, t - 1)]; tone(f, .18, 'triangle', .1); tone(f * 1.5, .14, 'sine', .05, .05); },
  drop(){ tone(330, .05, 'sine', .04); },
  bad(){ tone(190, .12, 'square', .03); },
  serve(){ [659, 784, 988, 1319].forEach((f, i) => tone(f, .2, 'triangle', .1, i * .07)); },
  coin(){ tone(1500, .06, 'square', .03); tone(2000, .08, 'square', .025, .05); },
  decor(){ [523, 659, 784, 1047, 1319, 1568].forEach((f, i) => tone(f, .3, 'triangle', .11, i * .09)); },
};
function haptic(kind){
  try{
    if(N && N.isNative){
      if(kind === 'ok') N.Haptics.notification({ type: N.NotificationType.Success });
      else N.Haptics.impact({ style: kind === 'big' ? N.ImpactStyle.Medium : N.ImpactStyle.Light });
    }else if(navigator.vibrate) navigator.vibrate(kind === 'big' ? 25 : 8);
  }catch(e){}
}

// ---------- واجهة عامة ----------
let toastT;
function toast(m){ const e = $('toast'); e.textContent = m; e.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => e.classList.remove('on'), 1700); }
let modalOpen = false, modalClosable = true;
function modal(html, closable){ $('box').innerHTML = html; $('modal').classList.add('show'); modalOpen = true; modalClosable = closable !== false; }
function closeModal(){ $('modal').classList.remove('show'); modalOpen = false; }
$('modal').addEventListener('click', e => { if(e.target.id === 'modal' && modalClosable) closeModal(); });
let screen = 'game';
function show(name){ screen = name; ['game', 'room'].forEach(s => $(s).classList.toggle('on', s === name)); if(name === 'game') layout(); else drawRoom(); }

// صور العناصر (للطلبات)
const iconCache = {};
function iconURL(it){ if(!iconCache[it]) iconCache[it] = Items.image(it, 96).toDataURL(); return iconCache[it]; }

// ---------- الشريط العلوي ----------
function fmtT(ms){ const s = Math.ceil(ms / 1000); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; }
function updateTop(){
  const now = Date.now(); E.regen(S, now);
  $('energy').textContent = S.energy;
  $('etimer').textContent = S.energy < E.ENERGY_MAX ? ' ' + fmtT(E.nextEnergyIn(S, now)) : '';
  $('coins').textContent = S.coins; $('stars').textContent = S.stars; $('stars2').textContent = S.stars;
  const t = E.nextTask(S);
  $('b-room').classList.toggle('can', !!t && S.stars >= t.cost);
  $('roomTag').textContent = E.ROOMS[Math.min(E.currentRoom(S), E.ROOMS.length - 1)].name;
}
setInterval(() => { const before = S.energy; updateTop(); if(S.energy !== before) save(); }, 1000);

// ---------- الطلبات ----------
function renderOrders(){
  const box = $('orders'); box.innerHTML = '';
  S.orders.forEach((o, i) => {
    const cells = E.findForOrder(S, o);
    const d = document.createElement('div'); d.className = 'order' + (cells ? ' ready' : '');
    const have = new Set(); const used = [];
    o.req.forEach((it, k) => { const at = S.board.findIndex((x, j) => x === it && !used.includes(j)); if(at >= 0){ used.push(at); have.add(k); } });
    d.innerHTML = `<span class="guest">${GUESTS[o.guest % GUESTS.length]}</span>
      <div class="req">${o.req.map((it, k) => `<span class="${have.has(k) ? 'have' : ''}"><img src="${iconURL(it)}" alt="${E.nameOf(it)}"></span>`).join('')}</div>
      ${cells ? `<button data-i="${i}">قدّمي</button>` : `<div class="rw">🪙${o.coins} ⭐${o.stars}</div>`}`;
    d.onclick = () => { if(!cells) toast('مطلوب: ' + o.req.map(E.nameOf).join(' + ')); };
    const b = d.querySelector('button'); if(b) b.onclick = (ev) => { ev.stopPropagation(); serveOrder(i); };
    box.appendChild(d);
  });
}
function serveOrder(i){
  const res = E.serve(S, i); if(!res) return;
  res.cells.forEach(k => { const [x, y] = cellCenter(k); burst(x, y, 10); fx.push({ k, t0: performance.now(), kind: 'vanish', it: null }); });
  SFX.serve(); haptic('ok');
  toast(`شكراً! 🪙${res.coins}  ⭐${res.stars}`);
  if(selected !== null && !S.board[selected]) select(null);
  save(); renderOrders(); updateTop();
  const t = E.nextTask(S);
  if(t && S.stars >= t.cost && !store.get('hintRoom', false)){ store.set('hintRoom', true); setTimeout(() => toast('عندك نجوم كافية! زيّني المجلس 🏠'), 1800); }
}

// ---------- اللوحة ----------
const cv = $('board'), g = cv.getContext('2d');
let CS = 48, dpr = 1, size = 300, imgs = {};
let selected = null, drag = null, fx = [], parts = [], spawnAnim = {};
function layout(){
  const wrap = $('boardwrap');
  const w = wrap.clientWidth - 16, h = wrap.clientHeight - 8;
  if(w <= 0 || h <= 0) return;
  CS = Math.floor(Math.min(w / E.COLS, h / E.ROWS, 80));
  size = CS * E.COLS;
  dpr = Math.min(3, window.devicePixelRatio || 1);
  cv.style.width = size + 'px'; cv.style.height = CS * E.ROWS + 'px';
  cv.width = Math.round(size * dpr); cv.height = Math.round(CS * E.ROWS * dpr);
  imgs = {};
}
function img(it){ if(!imgs[it]) imgs[it] = Items.image(it, Math.round(CS * .9 * dpr)); return imgs[it]; }
// الخانة 0 فاليمين (RTL)
function cellXY(k){ const r = Math.floor(k / E.COLS), c = k % E.COLS; return [(E.COLS - 1 - c) * CS, r * CS]; }
function cellCenter(k){ const [x, y] = cellXY(k); const b = cv.getBoundingClientRect(); return [x + CS / 2, y + CS / 2, b]; }
function cellAt(px, py){ const c = E.COLS - 1 - Math.floor(px / CS), r = Math.floor(py / CS); if(c < 0 || c >= E.COLS || r < 0 || r >= E.ROWS) return -1; return r * E.COLS + c; }
function rr(x, y, w, h, r){ g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

function frame(now){
  requestAnimationFrame(frame);
  if(screen !== 'game') return;
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, size, CS * E.ROWS);
  // الخانات
  const need = new Set(S.orders.flatMap(o => o.req));
  for(let k = 0; k < E.CELLS; k++){
    const [x, y] = cellXY(k), r = Math.floor(k / E.COLS), c = k % E.COLS;
    g.fillStyle = (r + c) % 2 ? '#f3e2c2' : '#ecd6ae'; rr(x + 1.5, y + 1.5, CS - 3, CS - 3, CS * .16); g.fill();
    const it = S.board[k];
    if(it && need.has(it)){ g.strokeStyle = 'rgba(47,163,107,.85)'; g.lineWidth = 3; rr(x + 3, y + 3, CS - 6, CS - 6, CS * .14); g.stroke(); }
    if(k === selected){ g.strokeStyle = '#e8b84a'; g.lineWidth = 4; rr(x + 2.5, y + 2.5, CS - 5, CS - 5, CS * .15); g.stroke(); }
  }
  // تلميح أول مرة: المولد كينبض
  const pulseGen = S.served === 0 && S.xp < 2;
  // العناصر
  for(let k = 0; k < E.CELLS; k++){
    const it = S.board[k]; if(!it) continue;
    if(drag && drag.k === k && drag.moved) continue;
    let [x, y] = cellXY(k), sc = 1;
    const sa = spawnAnim[k];
    if(sa){ const e = Math.min(1, (now - sa.t0) / 280); const ee = 1 - Math.pow(1 - e, 3); x = sa.x + (x - sa.x) * ee; y = sa.y + (y - sa.y) * ee; sc = .5 + .5 * ee; if(sa.pop) sc = 1 + Math.sin(e * Math.PI) * .25; if(e >= 1) delete spawnAnim[k]; }
    if(E.isGen(it) && pulseGen) sc *= 1 + Math.sin(now / 200) * .05;
    drawItem(it, x + CS / 2, y + CS / 2, sc);
  }
  // اللي كيتسحب
  if(drag && drag.moved){ drawItem(S.board[drag.k], drag.x, drag.y, 1.15); }
  // اختفاء
  fx = fx.filter(f => { const e = (now - f.t0) / 300; return e < 1; });
  parts = parts.filter(p => { const dt = 16; p.t += dt; if(p.t > p.life) return false; const e = p.t / p.life; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += .0005 * dt;
    g.save(); g.globalAlpha = 1 - e; Art.sparkle(g, p.x, p.y, p.r * (1 - e * .4), 1); g.restore(); return true; });
}
function drawItem(it, cx, cy, sc){
  const im = img(it), s = CS * .9 * sc;
  g.drawImage(im, cx - s / 2, cy - s / 2, s, s);
  if(!E.isGen(it)){
    const t = E.tierOf(it);
    g.fillStyle = 'rgba(90,31,58,.85)'; g.beginPath(); g.arc(cx + CS * .32, cy + CS * .32, CS * .12, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#fff'; g.font = `700 ${Math.round(CS * .16)}px Plex, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(t, cx + CS * .32, cy + CS * .33);
  }
}
function burst(x, y, n){ for(let i = 0; i < (n || 7); i++){ const a = Math.random() * Math.PI * 2, v = .04 + Math.random() * .1; parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - .06, r: 3 + Math.random() * 6, t: 0, life: 450 + Math.random() * 300 }); } }

// ---------- اللمس ----------
function local(e){ const b = cv.getBoundingClientRect(); return [e.clientX - b.left, e.clientY - b.top]; }
cv.addEventListener('pointerdown', e => {
  if(modalOpen) return;
  const [x, y] = local(e); const k = cellAt(x, y); if(k < 0) return;
  if(!S.board[k]){ select(null); return; }
  drag = { k, sx: x, sy: y, x, y, moved: false };
  cv.setPointerCapture(e.pointerId);
});
cv.addEventListener('pointermove', e => {
  if(!drag) return;
  const [x, y] = local(e); drag.x = x; drag.y = y;
  if(!drag.moved && Math.hypot(x - drag.sx, y - drag.sy) > CS * .25) drag.moved = true;
});
cv.addEventListener('pointerup', e => {
  if(!drag) return;
  const d = drag; drag = null;
  const [x, y] = local(e);
  if(!d.moved){ tapCell(d.k); return; }
  const to = cellAt(x, y);
  if(to < 0 || to === d.k){ SFX.drop(); return; }
  const before = S.board[to];
  const res = E.move(S, d.k, to);
  if(!res.ok) return;
  if(res.kind === 'merge'){
    const [cx, cy] = cellCenter(to); burst(cx, cy, 9);
    spawnAnim[to] = { t0: performance.now(), x: cellXY(to)[0], y: cellXY(to)[1], pop: true };
    SFX.merge(E.tierOf(res.item)); haptic('big');
    select(to);
    if(E.tierOf(res.item) === E.MAX_TIER) toast('✨ ' + E.nameOf(res.item) + '!');
  } else {
    SFX.drop(); if(res.kind === 'swap') select(to); else select(to);
    void before;
  }
  afterChange();
});
cv.addEventListener('pointercancel', () => { drag = null; });

function tapCell(k){
  const it = S.board[k];
  if(E.isGen(it)){
    E.regen(S, Date.now());
    const res = E.tapGen(S, k, Math.random, Date.now());
    if(!res.ok){
      if(res.why === 'energy') offerEnergy();
      else if(res.why === 'full'){ toast('اللوحة ممتلئة! ادمجي أو بيعي شيئاً'); SFX.bad(); }
      return;
    }
    const [gx, gy] = cellXY(k);
    spawnAnim[res.to] = { t0: performance.now(), x: gx, y: gy };
    SFX.pop(); haptic();
    select(k);
    afterChange();
    return;
  }
  select(k);
}
function select(k){
  selected = k;
  const it = k === null ? null : S.board[k];
  const sellB = $('b-sell');
  if(!it){ $('infoT').innerHTML = S.served === 0 ? '<b>اضغطي على الصندوق ✨</b>ليخرج لك فنجان أو تمرة، ثم اسحبي قطعتين متشابهتين فوق بعض لدمجهما.' : '<b>ادمجي وقدّمي الطلبات</b>اسحبي قطعتين متشابهتين فوق بعض.'; sellB.style.display = 'none'; return; }
  if(E.isGen(it)){ $('infoT').innerHTML = `<b>${E.nameOf(it)}</b>اضغطي عليه ليعطيك قطعة (⚡1)`; sellB.style.display = 'none'; return; }
  const t = E.tierOf(it);
  const next = t < E.MAX_TIER ? E.NAMES[E.chainOf(it)][t] : null;
  $('infoT').innerHTML = `<b>${E.nameOf(it)} · ${t}</b>${next ? 'ادمجي اثنين ← ' + next : 'أعلى مستوى ✨'}`;
  sellB.style.display = ''; sellB.textContent = `بيع 🪙${E.sellValue(it)}`;
  sellB.onclick = () => { const v = E.sell(S, k); if(v){ const [cx, cy] = cellCenter(k); burst(cx, cy, 5); SFX.coin(); select(null); afterChange(); } };
}
function afterChange(){ save(); renderOrders(); updateTop(); }

// ---------- الطاقة والفيديو ----------
function offerEnergy(){
  const can = S.coins >= BUY_COST;
  modal(`<h2>⚡ نفدت الطاقة</h2><p>الطاقة تتجدد وحدها (+1 كل دقيقتين).<br>أو احصلي عليها الآن:</p>
    <button class="big" id="m-vid">🎬 شاهدي فيديو  +${VIDEO_ENERGY}⚡</button>
    <button class="big gold" id="m-buy" style="margin-top:12px">+${BUY_ENERGY}⚡ مقابل 🪙${BUY_COST}</button>
    <button class="alt" id="m-no">لاحقاً</button>`);
  $('m-no').onclick = closeModal;
  $('m-vid').onclick = () => watchVideo();
  $('m-buy').onclick = () => { if(!can){ toast('لا تملكين عملات كافية'); return; } S.coins -= BUY_COST; S.energy += BUY_ENERGY; closeModal(); SFX.coin(); afterChange(); };
}
async function watchVideo(){
  const give = () => { S.energy += VIDEO_ENERGY; SFX.coin(); toast(`⚡ ${VIDEO_ENERGY}+`); afterChange(); };
  if(!Ads.isNative){ closeModal(); give(); return; }
  if(!Ads.rewardedAvailable()){ closeModal(); toast('لا يوجد فيديو الآن، حاولي لاحقاً'); return; }
  const ok = await Ads.showRewarded(); closeModal();
  if(ok) give(); else toast('لا يوجد فيديو الآن، حاولي لاحقاً');
}
$('b-video').onclick = () => {
  modal(`<h2>🎬</h2><p>شاهدي فيديو قصيراً واحصلي على <b>${VIDEO_ENERGY}</b> طاقة ⚡</p><button class="big" id="m-vid">شاهدي الفيديو</button><button class="alt" id="m-no">لا، شكراً</button>`);
  $('m-no').onclick = closeModal; $('m-vid').onclick = () => watchVideo();
};
$('p-energy').onclick = () => offerEnergy();

// ---------- الغرف ----------
const sc = $('scene'), sg = sc.getContext('2d');
function drawRoom(force){
  const r = force !== undefined ? force : Math.min(E.currentRoom(S), E.ROOMS.length - 1);
  const room = E.ROOMS[r];
  const w = sc.clientWidth || 360, d = Math.min(3, window.devicePixelRatio || 1);
  sc.width = Math.round(w * d); sc.height = Math.round(w * .75 * d); sc.style.height = (w * .75) + 'px';
  sg.setTransform(sc.width / 400, 0, 0, sc.height / 300, 0, 0);
  Rooms.draw(sg, r, S.done);
  $('roomName').textContent = room.name;
  const done = room.tasks.filter(t => S.done.includes(t[0]));
  $('progBar').style.width = (done.length / room.tasks.length * 100) + '%';
  $('doneList').innerHTML = done.map(t => `<span>✓ ${t[1]}</span>`).join('');
  const t = force !== undefined ? null : E.nextTask(S);
  if(force !== undefined){ $('taskBox').innerHTML = ''; return; }
  if(!t){ $('taskBox').innerHTML = `<div class="task"><div class="n">أكملتِ كل الغرف! 🎉<small>غرف جديدة قريباً</small></div></div>`; return; }
  $('taskBox').innerHTML = `<div class="task"><div class="n">${t.name}<small>${done.length} / ${room.tasks.length} في ${room.name}</small></div><button class="gobtn" id="b-do" ${S.stars >= t.cost ? '' : 'disabled'}>زيّني ⭐${t.cost}</button></div>
    ${S.stars < t.cost ? `<div style="text-align:center;color:#8a6a5a">تحتاجين ${t.cost - S.stars} ⭐ أخرى — قدّمي طلبات الضيوف لتربحي النجوم</div>` : ''}`;
  const b = $('b-do'); if(b) b.onclick = doDecor;
}
async function doDecor(){
  const res = E.doTask(S); if(!res) return;
  SFX.decor(); haptic('ok');
  save(); drawRoom(res.roomDone ? res.task.room : undefined); updateTop();
  const unlocked = res.gens.map(k => E.nameOf(S.board[k]));
  if(res.roomDone){
    modal(`<h2>${E.ROOMS[res.task.room].name} جاهز! 🎉</h2><p>أحسنتِ! الغرفة التالية: <b>${E.ROOMS[Math.min(res.task.room + 1, E.ROOMS.length - 1)].name}</b></p><button class="big" id="m-ok">رائع</button>`);
    $('m-ok').onclick = async () => { closeModal(); await Ads.maybeInterstitial(); drawRoom(); };
  } else if(unlocked.length){
    modal(`<h2>جديد! ✨</h2><p>فتحتِ <b>${unlocked.join('، ')}</b> على اللوحة. الضيوف سيطلبون أشياء جديدة!</p><button class="big" id="m-ok">هيا</button>`);
    $('m-ok').onclick = () => { closeModal(); };
  } else {
    toast('✨ ' + res.task.name);
    await Ads.maybeInterstitial();
  }
}
$('b-room').onclick = () => show('room');
$('b-back').onclick = () => { show('game'); renderOrders(); };

// ---------- القائمة ----------
$('b-menu').onclick = () => {
  modal(`<h2>مجلسي</h2>
    <button class="alt" id="m-snd">${sound ? '🔊 الصوت: يعمل' : '🔇 الصوت: متوقف'}</button>
    <button class="alt" id="m-help">❓ طريقة اللعب</button>
    ${Ads.privacyRequired ? '<button class="alt" id="m-priv">🔒 خيارات الإعلانات</button>' : ''}
    <a class="alt" style="display:block;text-decoration:none" href="https://maghouchiyoussef.github.io/tahaddi-quiz/majlisi-privacy.html">📄 سياسة الخصوصية</a>
    <button class="big" id="m-close">متابعة</button>`);
  $('m-snd').onclick = () => { sound = !sound; store.set('sound', sound); $('b-menu').onclick(); };
  $('m-help').onclick = help;
  if($('m-priv')) $('m-priv').onclick = () => Ads.showPrivacyOptions();
  $('m-close').onclick = closeModal;
};
function help(){
  modal(`<h2>أهلاً في مجلسي</h2><div class="steps">
    1️⃣ اضغطي على الصندوق ليعطيك قطعة (⚡1)<br>
    2️⃣ اسحبي قطعتين متشابهتين فوق بعض لتصبحا أكبر<br>
    3️⃣ قدّمي للضيوف ما يطلبونه واربحي 🪙 و⭐<br>
    4️⃣ استعملي النجوم لتزيين المجلس 🏠</div>
    <button class="big" id="m-ok">هيا نبدأ</button>`);
  $('m-ok').onclick = closeModal;
}

// ---------- Android ----------
window.addEventListener('resize', () => { if(screen === 'game') layout(); else drawRoom(); });
if(N && N.isNative){
  try{ N.StatusBar.setStyle({ style: N.Style.Light }); N.StatusBar.setBackgroundColor({ color: '#fbf3e6' }); }catch(e){}
  try{ N.App.addListener('backButton', () => {
    if(modalOpen){ if(modalClosable) closeModal(); return; }
    if(screen === 'room'){ show('game'); renderOrders(); return; }
    N.App.exitApp();
  }); }catch(e){}
  try{
    N.App.addListener('pause', () => { save(); if(actx) actx.suspend(); });
    N.App.addListener('resume', () => { if(actx) actx.resume(); updateTop(); });
  }catch(e){}
}
document.addEventListener('visibilitychange', () => { if(document.hidden) save(); else updateTop(); });

layout(); select(null); renderOrders(); updateTop();
const placed = E.placePending(S); if(placed.length) save();
requestAnimationFrame(frame);
if(firstRun) help();
Ads.init().finally(() => { Ads.showBanner(); try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} setTimeout(layout, 300); });
setTimeout(() => { try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} }, 2500);

// للتجربة
window.__mj = { get S(){ return S; }, tapCell, closeModal, cellXY, get CS(){ return CS; }, serveOrder, afterChange, show };
})();
