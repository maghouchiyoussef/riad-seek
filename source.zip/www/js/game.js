// دانة — لعبة مطابقة بلمسة خليجية
(function(){
'use strict';
const N = window.Native;
const Ads = window.Ads || { init:async()=>{}, showBanner(){}, hideBanner(){}, maybeInterstitial:async()=>{}, rewardedAvailable:()=>false, showRewarded:async()=>false, showPrivacyOptions(){}, isNative:false, privacyRequired:false };
const E = window.Engine, LV = window.LEVELS, Art = window.Art;
const $ = id => document.getElementById(id);
const BONUS = 300, HAMMER_COST = 80, MIX_COST = 50, VIDEO_REWARD = 50, EXTRA_MOVES = 5, EXTRA_COST = 120;
const CHAPTERS = [
  ['شاطئ اللؤلؤ', 'حيث تبدأ الحكاية'],
  ['واحة النخيل', 'تمور وظلال'],
  ['مجلس القهوة', 'دلال وفناجين'],
  ['سوق العطور', 'عود وبخور'],
  ['حديقة الورد', 'ورد الطائف'],
];
const TIPS = {
  1: 'بدّلي قطعتين متجاورتين لتكوين صف من 3 قطع متشابهة أو أكثر.',
  2: 'طابقي 4 قطع في صف لتحصلي على قطعة مخططة تمسح سطراً كاملاً!',
  3: 'طابقي 5 قطع على شكل L أو T لتحصلي على قطعة تنفجر حولها.',
  4: 'امسحي كل الرمل بمطابقة القطع الموجودة فوقه.',
  5: 'طابقي 5 قطع في صف لتحصلي على «الدانة الكبرى» ✨ بدّليها مع أي قطعة لتمسح كل قطع ذلك النوع!',
  6: 'جرّبي تبديل قطعتين مميزتين معاً لانفجار أكبر!',
  7: 'الحركات المتبقية في النهاية تمنحك نقاطاً إضافية ⭐',
};

// ---------- حفظ ----------
const store = {
  get(k, d){ try{ const v = localStorage.getItem('dn_' + k); return v === null ? d : JSON.parse(v); }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem('dn_' + k, JSON.stringify(v)); }catch(e){} },
};
let best = store.get('best', []);          // النجوم ديال كل مستوى
let coins = store.get('coins', 150);
let sound = store.get('sound', true);
const unlocked = () => Math.min(LV.length - 1, best.length);   // آخر مستوى مفتوح (0-index)

// ---------- أصوات ----------
let actx = null;
function tone(f, d, type, v, delay){
  if(!sound) return;
  try{
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const t0 = actx.currentTime + (delay || 0), o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(v || .1, t0 + .012); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    o.connect(g); g.connect(actx.destination); o.start(t0); o.stop(t0 + d + .05);
  }catch(e){}
}
const NOTES = [523, 587, 659, 784, 880, 988, 1047, 1175];
const SFX = {
  swap(){ tone(480, .07, 'sine', .05); tone(640, .06, 'sine', .04, .04); },
  bad(){ tone(190, .14, 'square', .035); tone(150, .14, 'square', .03, .08); },
  match(c){ const f = NOTES[Math.min(c, NOTES.length - 1)]; tone(f, .16, 'triangle', .1); tone(f * 1.5, .12, 'sine', .04, .04); },
  special(){ [392, 523, 784, 1047].forEach((f, i) => tone(f, .2, 'triangle', .09, i * .045)); },
  win(){ [523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, .3, 'triangle', .12, i * .1)); },
  lose(){ [392, 330, 262].forEach((f, i) => tone(f, .32, 'triangle', .09, i * .16)); },
  coin(){ tone(1500, .06, 'square', .03); tone(2000, .08, 'square', .025, .05); },
  ding(){ tone(1320, .08, 'sine', .05); },
};
function haptic(kind){
  try{
    if(N && N.isNative){
      if(kind === 'ok') N.Haptics.notification({ type: N.NotificationType.Success });
      else N.Haptics.impact({ style: kind === 'big' ? N.ImpactStyle.Medium : N.ImpactStyle.Light });
    }else if(navigator.vibrate) navigator.vibrate(kind === 'big' ? 30 : 8);
  }catch(e){}
}

// ---------- واجهة عامة ----------
let toastT;
function toast(m){ const e = $('toast'); e.textContent = m; e.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => e.classList.remove('on'), 1600); }
let modalOpen = false, modalClosable = true;
function modal(html, closable){ $('box').innerHTML = html; $('modal').classList.add('show'); modalOpen = true; modalClosable = closable !== false; }
function closeModal(){ $('modal').classList.remove('show'); modalOpen = false; }
$('modal').addEventListener('click', e => { if(e.target.id === 'modal' && modalClosable) closeModal(); });
function setCoins(n){ coins = Math.max(0, n); store.set('coins', coins); ['coins', 'm-coins', 'map-coins'].forEach(id => $(id).textContent = coins); }
let screen = 'menu';
function show(name){
  screen = name;
  ['menu', 'map', 'game'].forEach(s => $(s).classList.toggle('on', s === name));
  running = name === 'game';
  if(running) requestAnimationFrame(frame);
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
const starsTxt = n => '★'.repeat(n) + '☆'.repeat(3 - n);

// ---------- القائمة ----------
function renderMenu(){
  setCoins(coins);
  const u = unlocked();
  $('m-lvl').textContent = best.length ? `المستوى ${u + 1} من ${LV.length}` : '';
  $('b-sound').textContent = sound ? '🔊 الصوت' : '🔇 الصوت';
  $('b-privacy').style.display = Ads.privacyRequired ? '' : 'none';
}
$('b-play').onclick = () => { openMap(); };
$('b-sound').onclick = () => { sound = !sound; store.set('sound', sound); renderMenu(); };
$('b-privacy').onclick = () => Ads.showPrivacyOptions();

// ---------- الخريطة ----------
let mapBuilt = false;
const NODE_GAP = 92;
function buildMap(){
  const path = $('path'); path.innerHTML = '';
  for(let ch = 0; ch < Math.ceil(LV.length / 20); ch++){
    const [name, sub] = CHAPTERS[ch % CHAPTERS.length];
    const h = document.createElement('div'); h.className = 'chapter';
    h.innerHTML = `<b>${name}</b><small>المستويات ${ch * 20 + 1} – ${Math.min(LV.length, ch * 20 + 20)} · ${sub}</small>`;
    path.appendChild(h);
    const wrap = document.createElement('div'); wrap.className = 'nodes';
    const count = Math.min(20, LV.length - ch * 20);
    wrap.style.height = (count * NODE_GAP + 20) + 'px';
    for(let i = 0; i < count; i++){
      const n = ch * 20 + i;
      const b = document.createElement('button'); b.className = 'node'; b.dataset.n = n;
      b.style.top = (i * NODE_GAP + 14) + 'px';
      b.style.left = (50 + Math.sin(n * .9) * 26) + '%';
      b.onclick = () => { if(n <= unlocked()) startLevel(n); else toast('أكملي المستويات السابقة أولاً'); };
      wrap.appendChild(b);
    }
    path.appendChild(wrap);
  }
  mapBuilt = true;
}
function openMap(){
  if(!mapBuilt) buildMap();
  const u = unlocked();
  document.querySelectorAll('.node').forEach(b => {
    const n = +b.dataset.n;
    b.className = 'node' + (n > u ? ' lock' : n === u && !best[n] ? ' cur' : '');
    b.innerHTML = n > u ? '🔒' : `${n + 1}<span class="st">${best[n] ? starsTxt(best[n]) : ''}</span>`;
  });
  setCoins(coins);
  show('map');
  const cur = document.querySelector(`.node[data-n="${u}"]`);
  if(cur) setTimeout(() => cur.scrollIntoView({ block: 'center' }), 30);
}
$('b-mapback').onclick = () => { renderMenu(); show('menu'); };

// ---------- اللوحة والرسم ----------
const cv = $('board'), g = cv.getContext('2d');
let ts = 48, pad = 8, dpr = 1, imgs = [], sandImg = null, bgCanvas = null, bgDirty = true;
let S = null, L = null, lvIndex = 0;
let sprites = new Map();
let effects = [], parts = [], floats = [];
let vSand = [], vScore = 0, vMoves = 0, vCol = [];
let busy = false, selected = null, hint = null, hintT = null, hammerMode = false, running = false;
let extraUsed = 0, goalIcons = [];

function layout(){
  const wrap = $('boardwrap');
  const cs = getComputedStyle(wrap);
  const w = wrap.clientWidth - 16, h = wrap.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom) - $('tools').offsetHeight - 18 - 8;
  if(w <= 0 || h <= 0) return;
  ts = Math.max(24, Math.floor(Math.min((w - 12) / 8, (h - 12) / 8, 76)));
  pad = Math.round(ts * .16);
  dpr = Math.min(3, window.devicePixelRatio || 1);
  const size = ts * 8 + pad * 2;
  cv.style.width = cv.style.height = size + 'px';
  cv.width = cv.height = Math.round(size * dpr);
  const px = Math.round(ts * dpr);
  imgs = [];
  for(let t = 0; t < 6; t++) imgs[t] = Art.image(t, px);
  imgs[-1] = Art.image(-1, px);
  bgDirty = true;
}

function renderBg(){
  const size = cv.width;
  bgCanvas = bgCanvas || document.createElement('canvas');
  bgCanvas.width = bgCanvas.height = size;
  const b = bgCanvas.getContext('2d');
  b.setTransform(dpr, 0, 0, dpr, 0, 0);
  const T = ts, P = pad;
  // إطار اللوحة حول الخانات
  b.save();
  b.shadowColor = 'rgba(122,31,82,.25)'; b.shadowBlur = 14; b.shadowOffsetY = 4;
  for(let r = 0; r < 8; r++) for(let c = 0; c < 8; c++) if(S.mask[r][c]){
    b.fillStyle = '#f3c55a';
    rr(b, P + c * T - 5, P + r * T - 5, T + 10, T + 10, T * .3); b.fill();
  }
  b.restore();
  for(let r = 0; r < 8; r++) for(let c = 0; c < 8; c++) if(S.mask[r][c]){
    b.fillStyle = '#fff8ea'; rr(b, P + c * T - 2, P + r * T - 2, T + 4, T + 4, T * .26); b.fill();
  }
  for(let r = 0; r < 8; r++) for(let c = 0; c < 8; c++){
    if(!S.mask[r][c]) continue;
    const x = P + c * T, y = P + r * T;
    if(vSand[r][c]){
      b.fillStyle = '#efcd8a'; rr(b, x + 1, y + 1, T - 2, T - 2, T * .2); b.fill();
      b.fillStyle = 'rgba(160,110,40,.45)';
      for(let i = 0; i < 6; i++){ b.beginPath(); b.arc(x + T * (.18 + ((i * 37 + r * 11 + c * 7) % 64) / 100), y + T * (.18 + ((i * 53 + r * 5 + c * 13) % 64) / 100), T * .035, 0, 7); b.fill(); }
    } else {
      b.fillStyle = (r + c) % 2 ? 'rgba(249,212,226,.75)' : 'rgba(255,236,243,.9)';
      rr(b, x + 1, y + 1, T - 2, T - 2, T * .2); b.fill();
    }
  }
  bgDirty = false;
}
function rr(g2, x, y, w, h, r){ r = Math.max(0, Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2)); g2.beginPath(); g2.moveTo(x + r, y); g2.arcTo(x + w, y, x + w, y + h, r); g2.arcTo(x + w, y + h, x, y + h, r); g2.arcTo(x, y + h, x, y, r); g2.arcTo(x, y, x + w, y, r); g2.closePath(); }

// ---------- حركات (tweens) ----------
let tweens = [], lastNow = 0;
const ease = { lin: p => p, out: p => 1 - (1 - p) * (1 - p), in: p => p * p, back: p => { const c = 1.7; return 1 + (c + 1) * Math.pow(p - 1, 3) + c * Math.pow(p - 1, 2); }, inOut: p => p < .5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2 };
function anim(dur, step, ez){
  return new Promise(res => tweens.push({ t0: null, dur, step, ez: ez || ease.out, res }));
}

function frame(now){
  if(!running) return;
  const dt = Math.min(50, now - (lastNow || now)); lastNow = now;
  for(let i = tweens.length - 1; i >= 0; i--){
    const tw = tweens[i];
    if(tw.t0 === null) tw.t0 = now;
    const p = Math.min(1, (now - tw.t0) / tw.dur);
    tw.step(tw.ez(p));
    if(p >= 1){ tweens.splice(i, 1); tw.res(); }
  }
  for(let i = parts.length - 1; i >= 0; i--){
    const p = parts[i]; p.life -= dt;
    p.x += p.vx * dt / 16; p.y += p.vy * dt / 16; p.vy += .25 * dt / 16;
    if(p.life <= 0) parts.splice(i, 1);
  }
  draw(now);
  requestAnimationFrame(frame);
}

function draw(now){
  if(!S) return;
  if(bgDirty) renderBg();
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.clearRect(0, 0, cv.width, cv.height);
  g.drawImage(bgCanvas, 0, 0);
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  const T = ts, P = pad;
  // التحديد
  if(selected){
    g.fillStyle = 'rgba(232,184,74,.55)'; rr(g, P + selected[1] * T + 2, P + selected[0] * T + 2, T - 4, T - 4, T * .22); g.fill();
  }
  g.save();
  g.beginPath(); g.rect(P - 6, P - 6, T * 8 + 12, T * 8 + 12); g.clip();
  const hintIds = hint ? hint.map(([r, c]) => S.tiles[r][c] && S.tiles[r][c].id) : [];
  for(const sp of sprites.values()){
    let sc = sp.s;
    if(hintIds.includes(sp.id) && !busy) sc *= 1 + .09 * Math.sin(now / 140);
    const size = T * sc * .94;
    const x = P + sp.x * T + T / 2, y = P + sp.y * T + T / 2;
    if(y < P - T || size <= 0.5) continue;
    g.globalAlpha = sp.a;
    g.drawImage(imgs[sp.sp === 'c' ? -1 : sp.t], x - size / 2, y - size / 2, size, size);
    if(sp.sp === 'h' || sp.sp === 'v') drawStripe(x, y, size, sp.sp, now);
    else if(sp.sp === 'b') drawBombGlow(x, y, size, now);
    else if(sp.sp === 'c') drawRainbow(x, y, size, now);
    g.globalAlpha = 1;
  }
  g.restore();
  // انفجارات
  for(let i = effects.length - 1; i >= 0; i--){
    const e = effects[i]; const p = (now - e.t0) / e.life;
    if(p >= 1){ effects.splice(i, 1); continue; }
    const x = P + e.c * T + T / 2, y = P + e.r * T + T / 2, a = 1 - p;
    g.save();
    if(e.sp === 'h' || e.sp === 'v' || e.sp === 'x'){
      const grd = (vert) => {
        const w = T * (.5 + .4 * (1 - p));
        const gr = vert ? g.createLinearGradient(x - w / 2, 0, x + w / 2, 0) : g.createLinearGradient(0, y - w / 2, 0, y + w / 2);
        gr.addColorStop(0, 'rgba(255,240,180,0)'); gr.addColorStop(.5, `rgba(255,250,220,${a})`); gr.addColorStop(1, 'rgba(255,240,180,0)');
        g.fillStyle = gr;
        if(vert) g.fillRect(x - w / 2, P, w, T * 8); else g.fillRect(P, y - w / 2, T * 8, w);
      };
      if(e.sp !== 'v') grd(false);
      if(e.sp !== 'h') grd(true);
    } else if(e.sp === 'b' || e.sp === 'B'){
      const R = T * (e.sp === 'B' ? 2.6 : 1.6) * (.4 + p);
      const gr = g.createRadialGradient(x, y, 0, x, y, R);
      gr.addColorStop(0, `rgba(255,255,230,${a})`); gr.addColorStop(.6, `rgba(255,200,90,${a * .6})`); gr.addColorStop(1, 'rgba(255,160,60,0)');
      g.fillStyle = gr; g.beginPath(); g.arc(x, y, R, 0, 7); g.fill();
    } else if(e.sp === 'c'){
      g.globalAlpha = a * .6; g.fillStyle = '#fff6fb'; g.fillRect(P, P, T * 8, T * 8);
    } else if(e.sp === 'spark'){
      g.globalAlpha = a; Art.sparkle(g, x, y, T * .45 * (1 - p * .5), 1);
    }
    g.restore();
  }
  for(const p of parts){
    g.globalAlpha = Math.max(0, p.life / p.max);
    g.fillStyle = p.col; g.beginPath(); g.arc(p.x, p.y, p.r, 0, 7); g.fill();
  }
  g.globalAlpha = 1;
  // نصوص طايرة
  for(let i = floats.length - 1; i >= 0; i--){
    const f = floats[i]; const p = (now - f.t0) / f.life;
    if(p >= 1){ floats.splice(i, 1); continue; }
    g.save(); g.globalAlpha = p < .75 ? 1 : (1 - p) * 4;
    g.font = `700 ${f.size}px Plex, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.direction = /^[+\d]/.test(f.text) ? 'ltr' : 'rtl';
    const y = f.y - p * f.rise;
    const sc = f.big ? (p < .2 ? .6 + p * 2 : 1) : 1;
    g.translate(f.x, y); g.scale(sc, sc);
    g.lineWidth = f.size * .18; g.strokeStyle = f.stroke || '#7a1f52'; g.lineJoin = 'round'; g.strokeText(f.text, 0, 0);
    g.fillStyle = f.color || '#fff'; g.fillText(f.text, 0, 0);
    g.restore();
  }
}
function drawStripe(x, y, size, dir, now){
  g.save(); g.translate(x, y); if(dir === 'v') g.rotate(Math.PI / 2);
  const a = .55 + .25 * Math.sin(now / 160);
  g.fillStyle = `rgba(255,255,255,${a})`; g.strokeStyle = 'rgba(122,31,82,.55)'; g.lineWidth = size * .025;
  const w = size * .82;
  rr(g, -w / 2, -size * .2, w, size * .1, size * .05); g.fill(); g.stroke();
  rr(g, -w / 2, size * .1, w, size * .1, size * .05); g.fill(); g.stroke();
  g.fillStyle = `rgba(232,160,40,${.9})`;
  [-1, 1].forEach(s => { g.beginPath(); g.moveTo(s * w / 2 + s * size * .08, 0); g.lineTo(s * w / 2 - s * size * .03, -size * .1); g.lineTo(s * w / 2 - s * size * .03, size * .1); g.closePath(); g.fill(); });
  g.restore();
}
function drawBombGlow(x, y, size, now){
  const p = .5 + .5 * Math.sin(now / 200);
  g.save();
  g.strokeStyle = `rgba(232,184,74,${.6 + .4 * p})`; g.lineWidth = size * .07;
  g.beginPath(); g.arc(x, y, size * (.44 + .03 * p), 0, 7); g.stroke();
  for(let i = 0; i < 4; i++){ const a = now / 700 + i * Math.PI / 2; Art.sparkle(g, x + Math.cos(a) * size * .44, y + Math.sin(a) * size * .44, size * .1, .95); }
  g.restore();
}
function drawRainbow(x, y, size, now){
  g.save();
  for(let i = 0; i < 3; i++){ const a = now / 500 + i * 2.1; Art.sparkle(g, x + Math.cos(a) * size * .3, y + Math.sin(a) * size * .3, size * (.06 + .03 * Math.sin(now / 150 + i)), .95); }
  g.restore();
}

const TCOL = ['#f5dbe7', '#9a4a18', '#f1c14b', '#a466f0', '#e0457b', '#1fbf73'];
function burst(r, c, t, n){
  const x = pad + c * ts + ts / 2, y = pad + r * ts + ts / 2;
  for(let i = 0; i < n; i++){
    const a = Math.random() * 7, v = 1.5 + Math.random() * 3;
    parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 2, r: ts * (.04 + Math.random() * .05), col: t < 0 ? ['#ffd1e6', '#ffe9a8', '#bfe3ff'][i % 3] : TCOL[t], life: 450, max: 450 });
  }
  if(parts.length > 260) parts.splice(0, parts.length - 260);
}
function floatText(text, x, y, opt){ y = Math.max(y, ts * .9); floats.push(Object.assign({ text, x, y, t0: performance.now(), life: 900, rise: ts * .9, size: Math.round(ts * .42) }, opt || {})); }

// ---------- HUD ----------
function goalIcon(gl){
  if(gl.k === 't') return `<img src="${goalIcons[gl.t]}" alt="">`;
  if(gl.k === 'sand') return `<img src="${goalIcons.sand}" alt="">`;
  return '<span class="ico">⭐</span>';
}
function goalLeftView(i){
  const gl = L.goals[i];
  if(gl.k === 't') return Math.max(0, gl.n - vCol[gl.t]);
  if(gl.k === 'sand') return vSand.reduce((a, row) => a + row.reduce((x, y) => x + y, 0), 0);
  return Math.max(0, gl.n - vScore);
}
function renderGoals(){
  $('goals').innerHTML = L.goals.map((gl, i) => {
    const left = goalLeftView(i);
    return `<div class="goal${left === 0 ? ' done' : ''}" id="goal${i}">${goalIcon(gl)}<span>${left === 0 ? '✓' : (gl.k === 'score' ? fmt(left) : left)}</span></div>`;
  }).join('');
}
function updateHud(){
  $('moves').textContent = vMoves;
  $('movesbox').classList.toggle('low', vMoves <= 5 && vMoves > 0);
  L.goals.forEach((gl, i) => {
    const el = $('goal' + i); if(!el) return;
    const left = goalLeftView(i);
    el.classList.toggle('done', left === 0);
    el.querySelector('span').textContent = left === 0 ? '✓' : (gl.k === 'score' ? fmt(left) : left);
  });
  const top = L.s3 * 1.08;
  $('scorefill').style.width = Math.min(100, vScore / top * 100) + '%';
  $('mk2').style.left = (L.s2 / top * 100) + '%';
  $('mk3').style.left = (L.s3 / top * 100) + '%';
  $('mk2').classList.toggle('on', vScore >= L.s2);
  $('mk3').classList.toggle('on', vScore >= L.s3);
  $('scoretx').textContent = fmt(vScore);
}
const fmt = n => n.toLocaleString('en-US');

// ---------- بداية المستوى ----------
function startLevel(n){
  lvIndex = n; L = LV[n];
  closeModal();
  show('game');
  extraUsed = 0;
  $('lvl').textContent = `المستوى ${n + 1}`;
  S = E.create(L, (Math.random() * 2 ** 31) | 0);
  sprites = new Map(); effects = []; parts = []; floats = []; tweens = [];
  vSand = S.sand.map(row => row.slice()); vScore = 0; vMoves = S.moves; vCol = new Array(6).fill(0);
  selected = null; hint = null; hammerMode = false; $('b-hammer').classList.remove('on'); busy = false;
  if(!goalIcons.length){ for(let t = 0; t < 6; t++) goalIcons[t] = Art.image(t, 72).toDataURL(); goalIcons.sand = Art.sandImage(72).toDataURL(); }
  requestAnimationFrame(() => {
    layout();
    const drops = [];
    for(let r = 0; r < 8; r++) for(let c = 0; c < 8; c++){
      const t = S.tiles[r][c]; if(!t) continue;
      const sp = { id: t.id, t: t.t, sp: t.sp, x: c, y: r - 9, s: 1, a: 1 };
      sprites.set(t.id, sp);
      drops.push(anim(420 + c * 30 + (7 - r) * 20, p => { sp.y = r - 9 + 9 * p; }, ease.back));
    }
    renderGoals(); updateHud();
    busy = true;
    Promise.all(drops).then(() => { for(const sp of sprites.values()) sp.y = Math.round(sp.y); });
    showIntro();
  });
}
function goalsHtml(){
  return '<div class="bgoals">' + L.goals.map(gl => `<div class="goal">${goalIcon(gl)}<span>${gl.k === 'sand' ? S.sandLeft : gl.k === 'score' ? fmt(gl.n) : gl.n}</span></div>`).join('') + '</div>';
}
function goalText(){
  return L.goals.map(gl => gl.k === 't' ? `اجمعي ${gl.n} ${Art.NAMES[gl.t]}` : gl.k === 'sand' ? 'امسحي كل الرمل' : `حققي ${fmt(gl.n)} نقطة`).join(' و');
}
function showIntro(){
  const tip = TIPS[lvIndex + 1];
  modal(`<h2>المستوى ${lvIndex + 1}</h2>${goalsHtml()}<p>${goalText()}<br>في <b>${L.moves}</b> حركة</p>${tip ? `<div class="tip">💡 ${tip}</div>` : ''}<button class="big" id="m-go">ابدئي</button>`, false);
  $('m-go').onclick = () => { closeModal(); busy = false; resetHint(lvIndex < 2 ? 1200 : 6000); };
}

// ---------- اللمس ----------
function cellAt(ev){
  const rect = cv.getBoundingClientRect();
  const x = ev.clientX - rect.left - pad, y = ev.clientY - rect.top - pad;
  const c = Math.floor(x / ts), r = Math.floor(y / ts);
  if(r < 0 || r > 7 || c < 0 || c > 7 || !S.mask[r][c]) return null;
  return [r, c];
}
let down = null;
cv.addEventListener('pointerdown', ev => {
  if(busy || modalOpen || !S) return;
  const cell = cellAt(ev); if(!cell) return;
  if(hammerMode){ useHammer(cell); return; }
  down = { cell, x: ev.clientX, y: ev.clientY, moved: false };
  try{ cv.setPointerCapture(ev.pointerId); }catch(e){}
});
cv.addEventListener('pointermove', ev => {
  if(!down || busy) return;
  const dx = ev.clientX - down.x, dy = ev.clientY - down.y;
  if(Math.max(Math.abs(dx), Math.abs(dy)) < ts * .35) return;
  const [r, c] = down.cell;
  const to = Math.abs(dx) > Math.abs(dy) ? [r, c + Math.sign(dx)] : [r + Math.sign(dy), c];
  down = null; selected = null;
  trySwap([r, c], to);
});
cv.addEventListener('pointerup', ev => {
  if(!down) return;
  const cell = down.cell; down = null;
  if(busy) return;
  if(selected && Math.abs(selected[0] - cell[0]) + Math.abs(selected[1] - cell[1]) === 1){ const a = selected; selected = null; trySwap(a, cell); }
  else if(selected && selected[0] === cell[0] && selected[1] === cell[1]) selected = null;
  else { selected = cell; SFX.ding(); }
});
cv.addEventListener('pointercancel', () => { down = null; });

function resetHint(ms){
  hint = null; clearTimeout(hintT);
  hintT = setTimeout(() => { if(!busy && !modalOpen && S && screen === 'game') hint = E.findMove(S); }, ms || 6000);
}

async function trySwap(a, b){
  if(b[0] < 0 || b[0] > 7 || b[1] < 0 || b[1] > 7) return;
  if(!S.tiles[a[0]][a[1]] || !S.tiles[b[0]][b[1]]) return;
  busy = true; hint = null; clearTimeout(hintT);
  const res = E.swap(S, a, b);
  if(!res){ busy = false; return; }
  SFX.swap();
  if(!res.valid){
    await animSwap(res.events[0], false);
    SFX.bad(); haptic();
    await animSwap(res.events[0], true);
    busy = false; resetHint(); return;
  }
  vMoves--; updateHud();
  await playEvents(res.events);
  endTurn();
}

async function playEvents(events){
  for(const ev of events){
    if(ev.type === 'swap') await animSwap(ev, false);
    else if(ev.type === 'convert') await animConvert(ev);
    else if(ev.type === 'clear') await animClear(ev);
    else if(ev.type === 'fall') await animFall(ev);
    else if(ev.type === 'shuffle') await animShuffle(ev);
  }
}
function animSwap(ev, back){
  const A = sprites.get(ev.ida), B = sprites.get(ev.idb);
  const from = back ? ev.b : ev.a, to = back ? ev.a : ev.b;
  return anim(150, p => {
    A.x = from[1] + (to[1] - from[1]) * p; A.y = from[0] + (to[0] - from[0]) * p;
    B.x = to[1] + (from[1] - to[1]) * p; B.y = to[0] + (from[0] - to[0]) * p;
  }, ease.inOut);
}
async function animConvert(ev){
  SFX.special();
  for(const x of ev.list){ const sp = sprites.get(x.id); if(sp){ sp.sp = x.sp; } }
  await anim(350, p => { for(const x of ev.list){ const sp = sprites.get(x.id); if(sp) sp.s = 1 + .25 * Math.sin(p * Math.PI); } });
}
const PRAISE = ['', '', 'جميل!', 'رائع!', 'مذهل!', 'خيالي!', 'أسطوري!'];
async function animClear(ev){
  const now = performance.now();
  for(const x of ev.explosions) effects.push({ r: x.r, c: x.c, sp: x.sp, t0: now, life: x.sp === 'c' ? 420 : 380 });
  if(ev.big) effects.push({ r: ev.cleared[0] ? ev.cleared[0].r : 3, c: ev.cleared[0] ? ev.cleared[0].c : 3, sp: 'B', t0: now, life: 500 });
  if(ev.explosions.length || ev.created.length || ev.big){ SFX.special(); haptic('big'); } else { SFX.match(ev.combo); haptic(); }
  // نقاط
  let sx = 0, sy = 0;
  ev.cleared.forEach(x => { sx += x.c; sy += x.r; });
  if(ev.cleared.length){
    sx = pad + (sx / ev.cleared.length) * ts + ts / 2; sy = pad + (sy / ev.cleared.length) * ts + ts / 2;
    floatText('+' + ev.points, sx, sy);
  }
  if(ev.combo >= 2 || ev.big){
    const w = ev.big ? 'مذهل!' : PRAISE[Math.min(ev.combo, PRAISE.length - 1)];
    floatText(w, pad + ts * 4, pad + ts * 3.6, { size: Math.round(ts * .9), life: 1100, rise: ts * .5, big: true, color: '#ffe48a', stroke: '#7a1f52' });
  }
  ev.cleared.forEach(x => burst(x.r, x.c, x.t, ev.cleared.length > 20 ? 3 : 7));
  flyToGoals(ev.cleared);
  const gone = ev.cleared.map(x => sprites.get(x.id)).filter(Boolean);
  const born = ev.created.map(x => { const sp = { id: x.id, t: x.t, sp: x.sp, x: x.c, y: x.r, s: 0, a: 1 }; return sp; });
  await anim(190, p => { gone.forEach(sp => { sp.s = 1 - p * .8; sp.a = 1 - p; }); });
  ev.cleared.forEach(x => sprites.delete(x.id));
  ev.cleared.forEach(x => { if(x.t >= 0) vCol[x.t]++; });
  ev.sandCleared.forEach(k => { const [r, c] = E.rc(k); vSand[r][c] = 0; effects.push({ r, c, sp: 'spark', t0: performance.now(), life: 400 }); });
  if(ev.sandCleared.length) bgDirty = true;
  vScore += ev.points; updateHud();
  if(born.length){
    born.forEach(sp => sprites.set(sp.id, sp));
    await anim(220, p => born.forEach(sp => { sp.s = p; }), ease.back);
  }
}
function flyToGoals(cleared){
  const rect = cv.getBoundingClientRect();
  const counts = {};
  for(const x of cleared){
    const gi = L.goals.findIndex(gl => gl.k === 't' && gl.t === x.t);
    if(gi < 0 || goalLeftView(gi) === 0) continue;
    counts[gi] = (counts[gi] || 0) + 1;
    if(counts[gi] > 3) continue;
    const target = $('goal' + gi); if(!target) continue;
    const tr = target.getBoundingClientRect();
    const im = document.createElement('img'); im.className = 'fly'; im.src = goalIcons[x.t];
    const x0 = rect.left + pad + x.c * ts + ts / 2 - 17, y0 = rect.top + pad + x.r * ts + ts / 2 - 17;
    im.style.left = x0 + 'px'; im.style.top = y0 + 'px';
    document.body.appendChild(im);
    requestAnimationFrame(() => requestAnimationFrame(() => { im.style.transform = `translate(${tr.left + 6 - x0}px,${tr.top + 4 - y0}px) scale(.8)`; im.style.opacity = '.3'; }));
    setTimeout(() => im.remove(), 600);
  }
}
function animFall(ev){
  const jobs = [];
  for(const m of ev.moves){
    const sp = sprites.get(m.id); if(!sp) continue;
    const d = m.to - m.from;
    jobs.push(anim(110 + Math.sqrt(d) * 85, p => { sp.y = m.from + d * p; sp.x = m.c; }, ease.in));
  }
  for(const s of ev.spawns){
    const sp = { id: s.id, t: s.t, sp: s.sp, x: s.c, y: s.from, s: 1, a: 1 };
    sprites.set(s.id, sp);
    const d = s.to - s.from;
    jobs.push(anim(110 + Math.sqrt(d) * 85, p => { sp.y = s.from + d * p; }, ease.in));
  }
  return Promise.all(jobs).then(() => anim(80, p => {}));
}
async function animShuffle(ev){
  toast('لا توجد حركات… خلط!');
  await sleep(300);
  const jobs = ev.moves.map(m => { const sp = sprites.get(m.id); if(!sp) return null; sp.t = m.t; const x0 = sp.x, y0 = sp.y; return anim(420, p => { sp.x = x0 + (m.c - x0) * p; sp.y = y0 + (m.r - y0) * p; }, ease.inOut); });
  await Promise.all(jobs.filter(Boolean));
}

// ---------- نهاية الدور ----------
async function endTurn(){
  syncCheck();
  if(E.isWon(S, L)) return winSequence();
  if(E.isLost(S, L)) return lose();
  busy = false; resetHint();
}
// احتياط: كنتأكدو باللي الرسم مطابق للحالة
function syncCheck(){
  const ids = new Set();
  for(let r = 0; r < 8; r++) for(let c = 0; c < 8; c++){
    const t = S.tiles[r][c]; if(!t) continue;
    ids.add(t.id);
    let sp = sprites.get(t.id);
    if(!sp){ sp = { id: t.id, t: t.t, sp: t.sp, x: c, y: r, s: 1, a: 1 }; sprites.set(t.id, sp); }
    sp.x = c; sp.y = r; sp.t = t.t; sp.sp = t.sp; sp.s = 1; sp.a = 1;
  }
  for(const id of [...sprites.keys()]) if(!ids.has(id)) sprites.delete(id);
  vScore = S.score; vMoves = S.moves; vCol = S.collected.slice(); vSand = S.sand.map(r => r.slice()); bgDirty = true;
  updateHud();
}

async function winSequence(){
  busy = true; hint = null;
  SFX.win(); haptic('ok');
  floatText('أحسنتِ!', pad + ts * 4, pad + ts * 3.5, { size: Math.round(ts * 1), life: 1300, rise: ts * .4, big: true, color: '#ffe48a' });
  await sleep(900);
  while(S.moves > 0){
    S.moves--; S.score += BONUS; vMoves = S.moves; vScore = S.score;
    const list = [...sprites.values()]; const sp = list[Math.floor(Math.random() * list.length)];
    if(sp){ effects.push({ r: sp.y, c: sp.x, sp: 'spark', t0: performance.now(), life: 450 }); floatText('+' + BONUS, pad + sp.x * ts + ts / 2, pad + sp.y * ts + ts / 2, { size: Math.round(ts * .32) }); }
    SFX.ding(); updateHud();
    await sleep(110);
  }
  await sleep(500);
  const st = E.stars(S.score, L);
  const first = !best[lvIndex];
  if(!best[lvIndex] || st > best[lvIndex]){ best[lvIndex] = st; store.set('best', best); }
  const reward = (first ? 20 : 5) + st * 10;
  setCoins(coins + reward); SFX.coin();
  const last = lvIndex >= LV.length - 1;
  modal(`<h2>${['', 'جيد!', 'رائع!', 'مذهل!'][st]}</h2>
    <div class="stars">${[1, 2, 3].map(i => `<span class="${i <= st ? 'on' : ''}" style="animation-delay:${i * .15}s">⭐</span>`).join('')}</div>
    <p>النقاط: <b>${fmt(S.score)}</b><br><span dir="ltr">+${reward}</span> 🪙${last ? '<br><br>أكملتِ كل المستويات! مستويات جديدة قريباً ✨' : ''}</p>
    ${last ? '' : '<button class="big" id="m-next">المستوى التالي</button>'}
    <button class="alt" id="m-again">إعادة المستوى</button><button class="alt" id="m-map">الخريطة</button>`, false);
  if(!last) $('m-next').onclick = async () => { closeModal(); await Ads.maybeInterstitial(); startLevel(lvIndex + 1); };
  $('m-again').onclick = async () => { closeModal(); await Ads.maybeInterstitial(); startLevel(lvIndex); };
  $('m-map').onclick = () => { closeModal(); openMap(); };
}

function lose(){
  busy = true; SFX.lose();
  const left = E.goalsLeft(S, L);
  const canVideo = extraUsed < 2;
  modal(`<h2>انتهت الحركات!</h2>
    <div class="bgoals">${L.goals.map((gl, i) => `<div class="goal${left[i] === 0 ? ' done' : ''}">${goalIcon(gl)}<span>${left[i] === 0 ? '✓' : gl.k === 'score' ? fmt(left[i]) : left[i]}</span></div>`).join('')}</div>
    <p>أنتِ قريبة جداً! احصلي على <b>${EXTRA_MOVES}</b> حركات إضافية.</p>
    ${canVideo ? `<button class="big" id="m-vid">🎬 شاهدي فيديو +${EXTRA_MOVES}</button>` : ''}
    <button class="big gold" id="m-buy" style="margin-top:12px">+${EXTRA_MOVES} حركات مقابل ${EXTRA_COST} 🪙</button>
    <button class="alt" id="m-retry">إعادة المحاولة</button><button class="alt" id="m-map">الخريطة</button>`, false);
  if(canVideo) $('m-vid').onclick = async () => {
    if(!Ads.isNative){ closeModal(); addMoves(); return; }
    if(!Ads.rewardedAvailable()){ toast('لا يوجد فيديو الآن، حاولي لاحقاً'); return; }
    const ok = await Ads.showRewarded();
    if(ok){ closeModal(); addMoves(); } else toast('لا يوجد فيديو الآن، حاولي لاحقاً');
  };
  $('m-buy').onclick = () => {
    if(coins < EXTRA_COST){ toast('لا تملكين عملات كافية'); return; }
    setCoins(coins - EXTRA_COST); closeModal(); addMoves(true);
  };
  $('m-retry').onclick = async () => { closeModal(); await Ads.maybeInterstitial(); startLevel(lvIndex); };
  $('m-map').onclick = async () => { closeModal(); await Ads.maybeInterstitial(); openMap(); };
}
function addMoves(paid){
  if(!paid) extraUsed++;
  S.moves += EXTRA_MOVES; vMoves = S.moves; updateHud();
  toast(`+${EXTRA_MOVES} حركات`); SFX.coin();
  busy = false; resetHint();
}

// ---------- الأدوات ----------
$('b-hammer').onclick = () => {
  if(busy || modalOpen) return;
  if(hammerMode){ hammerMode = false; $('b-hammer').classList.remove('on'); return; }
  if(coins < HAMMER_COST){ offerVideo(true); return; }
  hammerMode = true; $('b-hammer').classList.add('on'); toast('اختاري القطعة التي تريدين كسرها');
};
async function useHammer(cell){
  hammerMode = false; $('b-hammer').classList.remove('on');
  const res = E.hammer(S, cell[0], cell[1]); if(!res) return;
  setCoins(coins - HAMMER_COST);
  busy = true; hint = null;
  effects.push({ r: cell[0], c: cell[1], sp: 'b', t0: performance.now(), life: 350 });
  await playEvents(res.events);
  endTurn();
}
$('b-mix').onclick = async () => {
  if(busy || modalOpen) return;
  if(coins < MIX_COST){ offerVideo(true); return; }
  setCoins(coins - MIX_COST);
  busy = true; hint = null;
  const ev = E.shuffle(S);
  await animShuffle(ev);
  syncCheck();
  busy = false; resetHint();
};
function offerVideo(need){
  modal(`<h2>🎬</h2><p>${need ? 'لا تملكين عملات كافية.<br>' : ''}شاهدي فيديو قصيراً واحصلي على <b>${VIDEO_REWARD}</b> عملة.</p><button class="big" id="m-watch">شاهدي الفيديو</button><button class="alt" id="m-no">لا، شكراً</button>`);
  $('m-no').onclick = closeModal;
  $('m-watch').onclick = async () => {
    if(!Ads.isNative){ closeModal(); videoReward(); return; }
    if(!Ads.rewardedAvailable()){ closeModal(); toast('لا يوجد فيديو الآن، حاولي لاحقاً'); return; }
    const ok = await Ads.showRewarded(); closeModal();
    if(ok) videoReward(); else toast('لا يوجد فيديو الآن، حاولي لاحقاً');
  };
}
function videoReward(){ setCoins(coins + VIDEO_REWARD); SFX.coin(); toast(`🪙 ${VIDEO_REWARD}+`); }
$('b-video').onclick = () => { if(!modalOpen) offerVideo(false); };

// ---------- الإيقاف ----------
function pauseMenu(){
  if(busy && !modalOpen && tweens.length) return;
  modal(`<h2>استراحة</h2><p>المستوى ${lvIndex + 1}</p>
    <button class="big" id="m-cont">متابعة</button>
    <button class="alt" id="m-restart">إعادة المستوى</button>
    <button class="alt" id="m-snd">${sound ? '🔊 الصوت: يعمل' : '🔇 الصوت: متوقف'}</button>
    <button class="alt" id="m-map">الخريطة</button>`);
  $('m-cont').onclick = closeModal;
  $('m-restart').onclick = () => { closeModal(); startLevel(lvIndex); };
  $('m-snd').onclick = () => { sound = !sound; store.set('sound', sound); pauseMenu(); };
  $('m-map').onclick = () => { closeModal(); openMap(); };
}
$('b-pause').onclick = pauseMenu;

// ---------- Android ----------
window.addEventListener('resize', () => { if(screen === 'game' && S) layout(); });
if(N && N.isNative){
  try{ N.StatusBar.setStyle({ style: N.Style.Light }); N.StatusBar.setBackgroundColor({ color: '#fff3f6' }); }catch(e){}
  try{ N.App.addListener('backButton', () => {
    if(modalOpen){ if(modalClosable) closeModal(); return; }
    if(screen === 'game'){ pauseMenu(); return; }
    if(screen === 'map'){ renderMenu(); show('menu'); return; }
    N.App.exitApp();
  }); }catch(e){}
  try{ N.App.addListener('pause', () => { if(actx) actx.suspend(); }); N.App.addListener('resume', () => { if(actx) actx.resume(); }); }catch(e){}
}

renderMenu(); show('menu');
Ads.init().finally(() => { Ads.showBanner(); renderMenu(); try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} });
setTimeout(() => { try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} }, 2500);

// للتجربة
window.__dn = { get S(){ return S; }, get L(){ return L; }, startLevel, trySwap, get busy(){ return busy; }, setCoins, get sprites(){ return sprites; }, win: () => { L.goals.forEach(g => { if(g.k === 't') S.collected[g.t] = g.n; if(g.k === 'score') S.score = g.n; }); S.sandLeft = 0; S.sand.forEach(r => r.fill(0)); endTurn(); }, lose: () => { S.moves = 0; endTurn(); } };
})();
