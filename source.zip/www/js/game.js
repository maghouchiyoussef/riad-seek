// Memory Match — pairs game
(function(){
'use strict';
const N = window.Native;
const $ = (s) => document.querySelector(s);

/* ---------- i18n ---------- */
const T = {
  en:{ title:'Memory Match', sub:'Find all the pairs!', play:'PLAY', levels:'Levels', settings:'Settings', level:'Level', moves:'Moves', time:'Time',
    win:'Well done!', next:'Next level', replay:'Replay', home:'Home', paused:'Paused', resume:'Resume', restart:'Restart',
    hints:'Hints', hintAd:'Get 2 hints (watch ad)', noHint:'No hints left', gotHints:'+2 hints!', adNo:'Ad not ready, try again soon',
    lang:'Language', sound:'Sound', on:'On', off:'Off', privacy:'Ad choices', close:'Close', combo:'Combo', best:'Best', perfect:'Perfect!',
    locked:'Finish the previous level first', total:'Stars' },
  fr:{ title:'Memory Match', sub:'Trouve toutes les paires !', play:'JOUER', levels:'Niveaux', settings:'Réglages', level:'Niveau', moves:'Coups', time:'Temps',
    win:'Bravo !', next:'Niveau suivant', replay:'Rejouer', home:'Accueil', paused:'Pause', resume:'Reprendre', restart:'Recommencer',
    hints:'Indices', hintAd:'2 indices (voir une pub)', noHint:"Plus d'indices", gotHints:'+2 indices !', adNo:'Pub indisponible, réessaie bientôt',
    lang:'Langue', sound:'Son', on:'Oui', off:'Non', privacy:'Choix pub', close:'Fermer', combo:'Combo', best:'Record', perfect:'Parfait !',
    locked:"Termine d'abord le niveau précédent", total:'Étoiles' },
  ar:{ title:'لعبة التطابق', sub:'اعثر على كل الأزواج!', play:'العب', levels:'المستويات', settings:'الإعدادات', level:'المستوى', moves:'الحركات', time:'الوقت',
    win:'أحسنت!', next:'المستوى التالي', replay:'إعادة', home:'الرئيسية', paused:'إيقاف مؤقت', resume:'متابعة', restart:'إعادة المستوى',
    hints:'التلميحات', hintAd:'تلميحان (شاهد إعلانًا)', noHint:'لا توجد تلميحات', gotHints:'+2 تلميح!', adNo:'الإعلان غير جاهز، جرّب بعد قليل',
    lang:'اللغة', sound:'الصوت', on:'تشغيل', off:'إيقاف', privacy:'خيارات الإعلانات', close:'إغلاق', combo:'كومبو', best:'الأفضل', perfect:'ممتاز!',
    locked:'أكمل المستوى السابق أولًا', total:'النجوم' }
};
const LANG_NAME = { en:'English', fr:'Français', ar:'العربية' };
let lang = 'en';
const t = (k) => T[lang][k];

/* ---------- content (widely supported emoji only) ---------- */
const THEMES = [
  '🐶🐱🐭🐹🐰🦊🐻🐼🐨🐯🦁🐮🐷🐸🐵🐔🐧🐤🦄🐙',
  '🍎🍐🍊🍋🍌🍉🍇🍓🍈🍒🍑🥭🍍🥥🥝🍅🥑🌽',
  '🍩🍪🎂🍰🧁🥧🍫🍬🍭🍮🍯🍦🍧🍨🥞🧇🥐🍿',
  '🐳🐬🐟🐠🐡🦈🐙🦑🦀🦞🦐🐚🐢🌊⚓⛵🏝️🐋',
  '🐪🌴🏜️🦅☕🌙⭐🕌⛺🦂🐎🌵🔥🏺🧭🗝️💎🌅',
  '🚗🚕🚙🚌🚓🚑🚒🚜🚲🛵🚂✈️🚀🚁🚤🛸🚠🏍️',
  '🌸🌻🌹🌷🍀🍁🌈☀️⛅❄️⚡🌍🌋🍄🌺🌼🌙🌊',
  '⚽🏀🏈⚾🎾🏐🏉🎱🏓🏸🥊🎯🎳⛳🏆🥇🛹🎮',
].map(s => Array.from(s.matchAll(/\p{Extended_Pictographic}(️)?/gu), m => m[0]));
const MAX_LEVEL = 120;
function layout(level){
  // [cols, rows]
  if(level <= 3) return [3, 4];
  if(level <= 10) return [4, 4];
  if(level <= 22) return [4, 5];
  if(level <= 40) return [4, 6];
  if(level <= 70) return [5, 6];
  return [6, 6];
}

/* ---------- save ---------- */
function fresh(){ return { level:1, stars:{}, best:{}, hints:3, lang:null, sound:true, wins:0 }; }
let SV = fresh();
function load(){
  try{
    const d = JSON.parse(localStorage.getItem('mm_save') || 'null');
    if(d){ SV = Object.assign(fresh(), d);
      if(!(SV.level >= 1 && SV.level <= MAX_LEVEL)) SV.level = 1;
      if(typeof SV.stars !== 'object' || !SV.stars) SV.stars = {};
      if(typeof SV.best !== 'object' || !SV.best) SV.best = {};
      if(!(SV.hints >= 0)) SV.hints = 3;
    }
  }catch(e){ SV = fresh(); }
}
function save(){ try{ localStorage.setItem('mm_save', JSON.stringify(SV)); }catch(e){} }
function detectLang(){
  if(SV.lang && T[SV.lang]) return SV.lang;
  const n = (navigator.language || 'en').toLowerCase();
  return n.startsWith('ar') ? 'ar' : n.startsWith('fr') ? 'fr' : 'en';
}
const totalStars = () => Object.values(SV.stars).reduce((a, b) => a + b, 0);

/* ---------- audio / haptics ---------- */
let actx = null;
function tone(f, d, type, vol, f2, delay){
  if(!SV.sound) return;
  try{
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    if(actx.state === 'suspended') actx.resume();
    const o = actx.createOscillator(), g = actx.createGain(), now = actx.currentTime + (delay || 0);
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, now); if(f2) o.frequency.exponentialRampToValueAtTime(f2, now + d);
    g.gain.setValueAtTime(0.0001, actx.currentTime); g.gain.setValueAtTime(vol || 0.07, now); g.gain.exponentialRampToValueAtTime(0.0001, now + d);
    o.connect(g); g.connect(actx.destination); o.start(now); o.stop(now + d + 0.02);
  }catch(e){}
}
const sfx = {
  flip(){ tone(520, .06, 'triangle', .05, 700); },
  match(n){ const b = 660 * Math.pow(1.06, Math.min(n, 8)); tone(b, .12, 'triangle', .07); tone(b * 1.5, .16, 'triangle', .06, null, .08); },
  miss(){ tone(220, .18, 'sawtooth', .04, 160); },
  win(){ [523, 659, 784, 1046].forEach((f, i) => tone(f, .22, 'triangle', .08, null, i * .12)); },
  hint(){ tone(880, .3, 'sine', .06, 1320); },
};
function hap(k){ try{ if(!N || !N.isNative) return; if(k === 'ok') N.Haptics.notification({ type: N.NotificationType.Success }); else N.Haptics.impact({ style: N.ImpactStyle.Light }); }catch(e){} }
function toast(m){ const el = $('#toast'); el.textContent = m; el.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('show'), 2000); }

/* ---------- screens ---------- */
function show(id){
  document.querySelectorAll('.scr').forEach(s => s.classList.toggle('show', s.id === id));
  if(id === 'game') Ads.hideBanner(); else Ads.showBanner();
}
const modal = $('#modal'); let modalOpen = false;
function showModal(html, bind){ modal.innerHTML = '<div class="box">' + html + '</div>'; modal.classList.add('show'); modalOpen = true; if(bind) bind(modal); }
function closeModal(){ modal.classList.remove('show'); modal.innerHTML = ''; modalOpen = false; }

function applyLang(){
  document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  $('#tTitle').textContent = t('title'); $('#tSub').textContent = t('sub');
  $('#bPlay').textContent = '▶ ' + t('play'); $('#bLevels').textContent = '🗂 ' + t('levels'); $('#bSet').textContent = '⚙️ ' + t('settings');
  $('#lvTitle').textContent = t('levels'); document.title = t('title');
  $('#lvBack').textContent = lang === 'ar' ? '→' : '←';
  updHome();
}
function updHome(){ $('#hLevel').textContent = '🎯 ' + t('level') + ' ' + SV.level; $('#hStars').textContent = '⭐ ' + totalStars(); }

function showLevels(){
  const g = $('#lvgrid'); g.innerHTML = '';
  $('#lvStars').textContent = '⭐ ' + totalStars();
  const frag = document.createDocumentFragment();
  for(let i = 1; i <= MAX_LEVEL; i++){
    const b = document.createElement('button');
    const st = SV.stars[i] || 0, open = i <= SV.level;
    b.className = 'lv' + (i === SV.level ? ' cur' : '') + (open ? '' : ' lock');
    b.innerHTML = (open ? i : '🔒') + '<small>' + (open && st ? '★'.repeat(st) + '☆'.repeat(3 - st) : open ? '☆☆☆' : '') + '</small>';
    b.onclick = () => { if(!open){ toast(t('locked')); return; } startLevel(i); };
    frag.appendChild(b);
  }
  g.appendChild(frag);
  show('levels');
  const cur = g.children[SV.level - 1]; if(cur) setTimeout(() => cur.scrollIntoView({ block:'center' }), 30);
}

/* ---------- game ---------- */
const G = { level:1, cards:[], open:[], lock:false, moves:0, pairs:0, found:0, combo:0, t0:0, elapsed:0, running:false, paused:false };
let timerIv = 0;
function shuffle(a){ for(let i = a.length - 1; i > 0; i--){ const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

function startLevel(lv){
  closeModal();
  G.level = lv;
  const [cols, rows] = layout(lv);
  const pairs = cols * rows / 2;
  const theme = THEMES[(lv - 1) % THEMES.length];
  const picks = shuffle(theme.slice()).slice(0, pairs);
  const deck = shuffle(picks.concat(picks));
  G.cards = deck.map((e, i) => ({ e, i, done:false, open:false }));
  G.open = []; G.lock = false; G.moves = 0; G.pairs = pairs; G.found = 0; G.combo = 0; G.elapsed = 0; G.running = false; G.paused = false;
  const grid = $('#grid'); grid.innerHTML = '';
  grid.style.gridTemplateColumns = 'repeat(' + cols + ', var(--cw))';
  G.cards.forEach(c => {
    const el = document.createElement('div'); el.className = 'card';
    el.innerHTML = '<div class="inner"><div class="face back"></div><div class="face front">' + c.e + '</div></div>';
    el.addEventListener('pointerdown', (ev) => { ev.preventDefault(); tapCard(c); });
    c.el = el; grid.appendChild(el);
  });
  $('#gLevel').textContent = '🎯 ' + lv;
  updStats(); updHint();
  show('game');
  size(cols, rows); requestAnimationFrame(() => size(cols, rows));
  // quick preview of all cards at the start of early levels
  if(lv <= 2){
    G.lock = true;
    setTimeout(() => G.cards.forEach(c => c.el.classList.add('open')), 250);
    setTimeout(() => { G.cards.forEach(c => c.el.classList.remove('open')); G.lock = false; }, 1700);
  }
}
function size(cols, rows){
  const [c0, r0] = cols ? [cols, rows] : layout(G.level);
  const b = $('#board').getBoundingClientRect();
  const gap = Math.max(5, Math.min(10, b.width / 60));
  const cw = Math.max(24, Math.floor(Math.min((b.width - gap * (c0 - 1) - 8) / c0, ((b.height - gap * (r0 - 1) - 8) / r0) / 1.18, 120)));
  const g = $('#grid'); g.style.setProperty('--cw', cw + 'px'); g.style.setProperty('--ch', Math.floor(cw * 1.18) + 'px'); g.style.setProperty('--gap', gap + 'px');
}
window.addEventListener('resize', () => { if($('#game').classList.contains('show')) size(); });

function tapCard(c){
  if(G.lock || G.paused || c.done || c.open || modalOpen) return;
  if(!G.running){ G.running = true; G.t0 = Date.now() - G.elapsed * 1000; startTimer(); }
  c.open = true; c.el.classList.add('open'); sfx.flip(); hap();
  G.open.push(c);
  if(G.open.length === 2){
    G.moves++; updStats();
    const [a, b] = G.open;
    if(a.e === b.e){
      G.open = []; G.combo++;
      setTimeout(() => {
        a.done = b.done = true; a.el.classList.add('done'); b.el.classList.add('done');
        sfx.match(G.combo); hap('ok');
        if(G.combo >= 2) comboFx(G.combo);
        setTimeout(() => { a.el.classList.add('fade'); b.el.classList.add('fade'); }, 500);
        G.found++;
        if(G.found === G.pairs) setTimeout(win, 650);
      }, 260);
    } else {
      G.lock = true; G.combo = 0;
      setTimeout(() => { a.el.classList.add('bad'); b.el.classList.add('bad'); sfx.miss(); }, 330);
      setTimeout(() => {
        [a, b].forEach(x => { x.open = false; x.el.classList.remove('open', 'bad'); });
        G.open = []; G.lock = false;
      }, 900);
    }
  }
}
function comboFx(n){
  const el = $('#combo'); el.textContent = t('combo') + ' x' + n + '!';
  el.classList.remove('show'); void el.offsetWidth; el.classList.add('show');
}
function startTimer(){ clearInterval(timerIv); timerIv = setInterval(() => { if(!G.paused && G.running){ G.elapsed = (Date.now() - G.t0) / 1000; updStats(); } }, 250); }
function fmtT(s){ s = Math.floor(s); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
function updStats(){ $('#gMoves').textContent = '👆 ' + G.moves; $('#gTime').textContent = '⏱ ' + fmtT(G.elapsed); }
function updHint(){ $('#gHint').textContent = SV.hints > 0 ? '💡' + SV.hints : '💡🎬'; }

async function reward(){
  if(!Ads.isNative) return true; // browser preview
  if(!Ads.rewardedAvailable()){ toast(t('adNo')); return false; }
  return !!(await Ads.showRewarded());
}
async function useHint(){
  if(G.lock || G.paused || modalOpen) return;
  if(SV.hints <= 0){
    G.paused = true;
    showModal('<h2>💡 ' + t('hints') + '</h2><p>' + t('noHint') + '</p><button class="btn pnk" id="ad">🎬 ' + t('hintAd') + '</button><button class="btn alt sm" id="cl">' + t('close') + '</button>', (m) => {
      m.querySelector('#cl').onclick = () => { closeModal(); resumeT(); };
      m.querySelector('#ad').onclick = async () => {
        const ok = await reward(); closeModal(); resumeT();
        if(ok){ SV.hints += 2; save(); updHint(); toast(t('gotHints')); }
      };
    });
    return;
  }
  SV.hints--; save(); updHint(); sfx.hint();
  G.lock = true;
  G.open.forEach(c => { c.open = false; }); G.open = [];
  const hidden = G.cards.filter(c => !c.done);
  hidden.forEach(c => c.el.classList.add('open'));
  setTimeout(() => { hidden.forEach(c => { c.el.classList.remove('open'); c.open = false; }); G.lock = false; }, 1300);
}
function resumeT(){ G.paused = false; if(G.running) G.t0 = Date.now() - G.elapsed * 1000; }

function pause(){
  if(!$('#game').classList.contains('show') || modalOpen) return;
  G.paused = true;
  showModal('<h2>' + t('paused') + '</h2><button class="btn grn" id="r">▶ ' + t('resume') + '</button><button class="btn alt sm" id="rs">🔄 ' + t('restart') + '</button><button class="btn alt sm" id="h">🏠 ' + t('home') + '</button>', (m) => {
    m.querySelector('#r').onclick = () => { closeModal(); resumeT(); };
    m.querySelector('#rs').onclick = () => { closeModal(); startLevel(G.level); };
    m.querySelector('#h').onclick = () => { closeModal(); clearInterval(timerIv); goHome(); };
  });
}
function starsFor(moves, pairs){ return moves <= Math.ceil(pairs * 1.5) ? 3 : moves <= Math.ceil(pairs * 2.2) ? 2 : 1; }

function win(){
  clearInterval(timerIv); G.running = false;
  const st = starsFor(G.moves, G.pairs), lv = G.level;
  SV.stars[lv] = Math.max(SV.stars[lv] || 0, st);
  const prevBest = SV.best[lv];
  if(!prevBest || G.moves < prevBest) SV.best[lv] = G.moves;
  if(lv === SV.level && SV.level < MAX_LEVEL) SV.level = lv + 1;
  SV.wins++; save();
  sfx.win(); hap('ok'); confetti();
  Ads.showBanner();
  showModal('<h2>' + (st === 3 ? t('perfect') : t('win')) + '</h2><div class="stars"><span>⭐</span><span>⭐</span><span>⭐</span></div>' +
    '<div class="kv"><div><small>' + t('moves') + '</small><b>' + G.moves + '</b></div><div><small>' + t('time') + '</small><b>' + fmtT(G.elapsed) + '</b></div><div><small>' + t('best') + '</small><b>' + SV.best[lv] + '</b></div></div>' +
    (lv < MAX_LEVEL ? '<button class="btn grn" id="nx">' + (lang === 'ar' ? '◀ ' : '▶ ') + t('next') + '</button>' : '') +
    '<div class="row"><button class="btn alt sm" id="rp">🔄 ' + t('replay') + '</button><button class="btn alt sm" id="lv">🗂 ' + t('levels') + '</button></div>', (m) => {
      const sp = m.querySelectorAll('.stars span');
      for(let i = 0; i < st; i++) setTimeout(() => { sp[i].classList.add('on'); tone(880 + i * 220, .12, 'triangle', .06); }, 300 + i * 280);
      const nx = m.querySelector('#nx');
      if(nx) nx.onclick = async () => { closeModal(); await maybeInter(); startLevel(lv + 1); };
      m.querySelector('#rp').onclick = async () => { closeModal(); await maybeInter(); startLevel(lv); };
      m.querySelector('#lv').onclick = () => { closeModal(); showLevels(); };
    });
}
const sessionStart = Date.now();
async function maybeInter(){
  if(Date.now() - sessionStart < 120000 || SV.wins < 3) return false;
  try{ return await Ads.maybeInterstitial(); }catch(e){ return false; }
}
function goHome(){ updHome(); show('home'); }

/* confetti */
const fx = $('#fx'), fctx = fx.getContext('2d'); let parts = [], fxRun = false;
function confetti(){
  const d = Math.min(window.devicePixelRatio || 1, 2); fx.width = innerWidth * d; fx.height = innerHeight * d; fctx.setTransform(d, 0, 0, d, 0, 0);
  const cols = ['#ffd23f', '#ff5fa2', '#3fd27a', '#4fb4ff', '#ff9f1c', '#b072ff'];
  for(let i = 0; i < 110; i++) parts.push({ x: innerWidth / 2 + (Math.random() - .5) * 60, y: innerHeight * 0.35, vx: (Math.random() - .5) * 560, vy: -Math.random() * 560 - 120, r: Math.random() * 6, vr: (Math.random() - .5) * 12, c: cols[i % cols.length], l: 2.4 });
  if(!fxRun){ fxRun = true; let last = performance.now();
    const step = (n) => { const dt = Math.min(.05, (n - last) / 1000); last = n; fctx.clearRect(0, 0, innerWidth, innerHeight);
      parts = parts.filter(p => (p.l -= dt) > 0);
      for(const p of parts){ p.vy += 900 * dt; p.vx *= .99; p.x += p.vx * dt; p.y += p.vy * dt; p.r += p.vr * dt;
        fctx.save(); fctx.globalAlpha = Math.min(1, p.l); fctx.translate(p.x, p.y); fctx.rotate(p.r); fctx.fillStyle = p.c; fctx.fillRect(-5, -3, 10, 6); fctx.restore(); }
      if(parts.length) requestAnimationFrame(step); else { fxRun = false; fctx.clearRect(0, 0, innerWidth, innerHeight); } };
    requestAnimationFrame(step); }
}

function showSettings(){
  showModal('<h2>⚙️ ' + t('settings') + '</h2><p>' + t('lang') + '</p><div class="row" id="lr"></div><p>' + t('sound') + '</p>' +
    '<button class="btn alt sm" id="snd">' + (SV.sound ? '🔊 ' + t('on') : '🔇 ' + t('off')) + '</button>' +
    (Ads.privacyRequired ? '<button class="btn alt sm" id="prv">🔒 ' + t('privacy') + '</button>' : '') +
    '<button class="btn grn" id="cl">' + t('close') + '</button>', (m) => {
      ['ar','en','fr'].forEach(L => { const b = document.createElement('button'); b.className = 'btn sm ' + (L === lang ? '' : 'alt'); b.textContent = LANG_NAME[L];
        b.onclick = () => { lang = L; SV.lang = L; save(); applyLang(); showSettings(); }; m.querySelector('#lr').appendChild(b); });
      m.querySelector('#snd').onclick = () => { SV.sound = !SV.sound; save(); showSettings(); };
      const pv = m.querySelector('#prv'); if(pv) pv.onclick = () => Ads.showPrivacyOptions();
      m.querySelector('#cl').onclick = closeModal;
    });
}

/* wiring */
$('#bPlay').onclick = () => startLevel(SV.level);
$('#bLevels').onclick = showLevels;
$('#bSet').onclick = showSettings;
$('#lvBack').onclick = goHome;
$('#gPause').onclick = pause;
$('#gHint').onclick = useHint;

try{
  N.App.addListener('backButton', () => {
    if(modalOpen){
      if($('#game').classList.contains('show') && G.found < G.pairs){ closeModal(); resumeT(); }
      else if(G.found === G.pairs && $('#game').classList.contains('show')){ closeModal(); showLevels(); }
      else closeModal();
      return;
    }
    if($('#game').classList.contains('show')){ pause(); return; }
    if($('#levels').classList.contains('show')){ goHome(); return; }
    N.App.exitApp();
  });
  N.App.addListener('pause', () => { pause(); save(); if(actx) actx.suspend(); });
  N.App.addListener('resume', () => { if(actx) actx.resume(); });
}catch(e){}
document.addEventListener('visibilitychange', () => { if(document.hidden){ pause(); save(); } });

/* start */
load(); lang = detectLang(); applyLang();
try{ N && N.isNative && N.StatusBar.setStyle({ style: N.Style.Dark }); }catch(e){}
try{ N && N.isNative && N.StatusBar.setBackgroundColor({ color: '#3a2896' }); }catch(e){}
Ads.init().finally(() => { if(!$('#game').classList.contains('show')) Ads.showBanner(); try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} });
setTimeout(() => { try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} }, 2500);
window.__mm = { G, SV: () => SV, startLevel, THEMES, win, showLevels, setLang: (l) => { lang = l; applyLang(); } };
})();
