// زينة — لعبة تطابق القطع بلمسة خليجية
(function(){
'use strict';
const N = window.Native;
const Ads = window.Ads || { init:async()=>{}, showBanner(){}, hideBanner(){}, maybeInterstitial:async()=>{}, rewardedAvailable:()=>false, showRewarded:async()=>false, showPrivacyOptions(){}, isNative:false, privacyRequired:false };
const E = window.Engine, LV = window.LEVELS, Art = window.Art;
const $ = id => document.getElementById(id);
const UNDO_COST = 30, MAGNET_COST = 60, MIX_COST = 40, VIDEO_REWARD = 50, RESCUE_COST = 100, RESCUE_N = 3;
const CHAPTERS = [
  ['المجلس', 'قهوة ودلال'],
  ['سوق الذهب', 'خواتم وأساور'],
  ['الواحة', 'نخيل وتمور'],
  ['شاطئ اللؤلؤ', 'صدف ولآلئ'],
  ['ليلة العيد', 'فوانيس وبخور'],
];
const TIPS = {
  1: 'اضغطي على قطعة لتنتقل إلى الشريط. اجمعي 3 قطع متشابهة لتختفي!',
  2: 'القطع المغطاة باهتة — لا يمكن أخذها حتى تزيلي ما فوقها.',
  4: 'انتبهي! إذا امتلأ الشريط بـ 7 قطع تخسرين المستوى.',
  6: 'استعملي ↩️ للتراجع، و🧲 لجمع 3 قطع تلقائياً، و🔀 لخلط القطع.',
  10: 'أنهي المستوى بسرعة لتحصلي على 3 نجوم ⭐',
};

// ---------- حفظ ----------
const store = {
  get(k, d){ try{ const v = localStorage.getItem('zn_' + k); return v === null ? d : JSON.parse(v); }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem('zn_' + k, JSON.stringify(v)); }catch(e){} },
};
let best = store.get('best', []);
let coins = store.get('coins', 150);
let sound = store.get('sound', true);
const unlocked = () => Math.min(LV.length - 1, best.length);

// ---------- أصوات ----------
let actx = null;
function tone(f, d, type, v, delay){
  if(!sound) return;
  try{
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const t0 = actx.currentTime + (delay || 0), o = actx.createOscillator(), gg = actx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0);
    gg.gain.setValueAtTime(0.0001, t0); gg.gain.exponentialRampToValueAtTime(v || .1, t0 + .012); gg.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    o.connect(gg); gg.connect(actx.destination); o.start(t0); o.stop(t0 + d + .05);
  }catch(e){}
}
const SFX = {
  tap(){ tone(660, .07, 'triangle', .07); tone(990, .05, 'sine', .03, .03); },
  bad(){ tone(190, .12, 'square', .03); },
  match(){ [784, 988, 1319].forEach((f, i) => tone(f, .16, 'triangle', .09, i * .05)); },
  win(){ [523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, .3, 'triangle', .12, i * .1)); },
  lose(){ [392, 330, 262].forEach((f, i) => tone(f, .32, 'triangle', .09, i * .16)); },
  coin(){ tone(1500, .06, 'square', .03); tone(2000, .08, 'square', .025, .05); },
  whoosh(){ tone(300, .12, 'sine', .05); tone(500, .1, 'sine', .04, .05); },
};
function haptic(kind){
  try{
    if(N && N.isNative){
      if(kind === 'ok') N.Haptics.notification({ type: N.NotificationType.Success });
      else N.Haptics.impact({ style: kind === 'big' ? N.ImpactStyle.Medium : N.ImpactStyle.Light });
    }else if(navigator.vibrate) navigator.vibrate(kind === 'big' ? 30 : 8);
  }catch(e){}
}

// ---------- واجهة عامة ----------
let toastT;
function toast(m){ const e = $('toast'); e.textContent = m; e.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => e.classList.remove('on'), 1600); }
let modalOpen = false, modalClosable = true;
function modal(html, closable){ $('box').innerHTML = html; $('modal').classList.add('show'); modalOpen = true; modalClosable = closable !== false; }
function closeModal(){ $('modal').classList.remove('show'); modalOpen = false; }
$('modal').addEventListener('click', e => { if(e.target.id === 'modal' && modalClosable) closeModal(); });
function setCoins(n){ coins = Math.max(0, n); store.set('coins', coins); ['coins', 'm-coins', 'map-coins'].forEach(id => $(id).textContent = coins); }
let screen = 'menu', running = false;
function show(name){
  screen = name;
  ['menu', 'map', 'game'].forEach(s => $(s).classList.toggle('on', s === name));
  running = name === 'game';
  if(running){ layout(); requestAnimationFrame(frame); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
const starsTxt = n => '★'.repeat(n) + '☆'.repeat(3 - n);

// ---------- القائمة ----------
function renderMenu(){
  setCoins(coins);
  const u = unlocked();
  $('m-lvl').textContent = best.length ? `المستوى ${u + 1} من ${LV.length}` : '';
  $('b-sound').textContent = sound ? '🔊 الصوت' : '🔇 الصوت';
  $('b-privacy').style.display = Ads.privacyRequired ? '' : 'none';
}
$('b-play').onclick = () => openMap();
$('b-sound').onclick = () => { sound = !sound; store.set('sound', sound); renderMenu(); };
$('b-privacy').onclick = () => Ads.showPrivacyOptions();

// ---------- الخريطة ----------
let mapBuilt = false;
const NODE_GAP = 92;
function buildMap(){
  const path = $('path'); path.innerHTML = '';
  for(let ch = 0; ch < Math.ceil(LV.length / 20); ch++){
    const [name, sub] = CHAPTERS[ch % CHAPTERS.length];
    const h = document.createElement('div'); h.className = 'chapter';
    h.innerHTML = `<b>${name}</b><small>المستويات ${ch * 20 + 1} – ${Math.min(LV.length, ch * 20 + 20)} · ${sub}</small>`;
    path.appendChild(h);
    const wrap = document.createElement('div'); wrap.className = 'nodes';
    const count = Math.min(20, LV.length - ch * 20);
    wrap.style.height = (count * NODE_GAP + 20) + 'px';
    for(let i = 0; i < count; i++){
      const n = ch * 20 + i;
      const b = document.createElement('button'); b.className = 'node'; b.dataset.n = n;
      b.style.top = (i * NODE_GAP + 14) + 'px';
      b.style.left = (50 + Math.sin(n * .9) * 26) + '%';
      b.onclick = () => { if(n <= unlocked()) startLevel(n); else toast('أكملي المستويات السابقة أولاً'); };
      wrap.appendChild(b);
    }
    path.appendChild(wrap);
  }
  mapBuilt = true;
}
function openMap(){
  if(!mapBuilt) buildMap();
  const u = unlocked();
  document.querySelectorAll('.node').forEach(b => {
    const n = +b.dataset.n;
    b.className = 'node' + (n > u ? ' lock' : n === u && !best[n] ? ' cur' : '');
    b.innerHTML = n > u ? '🔒' : `${n + 1}<span class="st">${best[n] ? starsTxt(best[n]) : ''}</span>`;
  });
  setCoins(coins);
  show('map');
  const cur = document.querySelector(`.node[data-n="${u}"]`);
  if(cur) setTimeout(() => cur.scrollIntoView({ block: 'center' }), 30);
}
$('b-mapback').onclick = () => { renderMenu(); show('menu'); };

// ---------- اللوحة ----------
const cv = $('board'), g = cv.getContext('2d');
let S = null, L = null, lvIndex = 0;
let W = 300, H = 400, dpr = 1, T = 48, slotT = 40, ox = 0, oy = 0, trayY = 0, trayX = 0, depth = 4;
let minX = 0, minY = 0;
let sprites = new Map(), parts = [], tileImgs = [], tileBase = null;
let busy = false, over = false, elapsed = 0, lastTick = 0, rescues = 0, shake = null;

function layout(){
  if(!S) return;
  const wrap = $('boardwrap');
  const cs = getComputedStyle(wrap);
  const w = wrap.clientWidth - 12;
  const h = wrap.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom) - $('tools').offsetHeight - 12 - 8;
  if(w <= 0 || h <= 0) return;
  W = w; H = h;
  dpr = Math.min(3, window.devicePixelRatio || 1);
  cv.style.width = W + 'px'; cv.style.height = H + 'px';
  cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
  // الشريط
  slotT = Math.min(Math.floor((W - 24) / 7), 62);
  const trayH = slotT * 1.32;
  trayY = H - trayH - 4; trayX = (W - slotT * 7) / 2;
  // اللوحة
  let maxX = 0, maxY = 0, maxZ = 0; minX = 1e9; minY = 1e9;
  S.tiles.forEach(t => { minX = Math.min(minX, t.x); minY = Math.min(minY, t.y); maxX = Math.max(maxX, t.x); maxY = Math.max(maxY, t.y); maxZ = Math.max(maxZ, t.z); });
  const cols = (maxX - minX + 2) / 2, rows = (maxY - minY + 2) / 2;
  const availH = trayY - 16;
  T = Math.floor(Math.min((W - 16) / (cols + .25), availH / (rows + .35), 84));
  depth = Math.max(3, Math.round(T * .07));
  const bw = cols * T, bh = rows * T + maxZ * depth;
  ox = (W - bw) / 2 + maxZ * depth * .5; oy = (availH - bh) / 2 + 8 + maxZ * depth;
  // صور القطع
  const px = Math.round(T * .82 * dpr);
  tileImgs = []; for(let i = 0; i < Art.COUNT; i++) tileImgs[i] = Art.image(i, px);
  tileBase = null;
  sprites.forEach(sp => { const p = targetOf(sp.id); sp.x = p.x; sp.y = p.y; sp.s = p.s; });
}
function boardPos(t){ return { x: ox + (t.x - minX) / 2 * T - t.z * depth * .6, y: oy + (t.y - minY) / 2 * T - t.z * depth, s: 1 }; }
function slotPos(i){ return { x: trayX + i * slotT + slotT * .06, y: trayY + slotT * .16, s: slotT * .88 / T }; }
let vTray = []; // ترتيب الشريط اللي كيبان
function targetOf(id){
  const t = S.tiles[id];
  const i = vTray.indexOf(id);
  if(i >= 0) return slotPos(i);
  return boardPos(t);
}
function retarget(){ sprites.forEach(sp => { const p = targetOf(sp.id); sp.tx = p.x; sp.ty = p.y; sp.ts = p.s; }); }

function startLevel(n){
  lvIndex = n; L = LV[n];
  S = E.create(L);
  sprites = new Map(); parts = []; vTray = [];
  S.tiles.forEach(t => sprites.set(t.id, { id: t.id, x: 0, y: 0, s: 1, a: 1, tx: 0, ty: 0, ts: 1, dying: 0, born: performance.now() + t.z * 60 + Math.random() * 120 }));
  busy = false; over = false; elapsed = 0; rescues = 0;
  $('lvl').textContent = `المستوى ${n + 1}`;
  show('game');
  layout(); retarget();
  sprites.forEach(sp => { sp.x = sp.tx; sp.y = sp.ty - 40; sp.s = sp.ts; sp.a = 0; });
  updateHud();
  setCoins(coins);
  lastTick = performance.now();
  const tip = TIPS[n + 1];
  if(tip){ modal(`<h2>المستوى ${n + 1}</h2><div class="tip">${tip}</div><button class="big" id="m-go">ابدئي</button>`); $('m-go').onclick = closeModal; }
}

function updateHud(){
  const left = S.total - S.cleared;
  $('left').textContent = `🧩 ${left}`;
  const s = Math.floor(elapsed / 1000);
  $('clock').textContent = `⏱ ${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

// ---------- الرسم ----------
function rr(x, y, w, h, r){ r = Math.max(0, Math.min(r, w / 2, h / 2)); g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
function drawTile(sp, t, free){
  const s = sp.s, size = T * .96 * s, x = sp.x + T * .02 * s, y = sp.y + T * .02 * s, d = depth * Math.max(.6, s), r = size * .18;
  g.save(); g.globalAlpha = sp.a;
  if(sp.dying){ const k = sp.dying; g.translate(x + size / 2, y + size / 2); g.scale(1 + k * .3, 1 + k * .3); g.translate(-x - size / 2, -y - size / 2); g.globalAlpha = sp.a * (1 - k); }
  // الحافة
  g.fillStyle = '#b98a2a'; rr(x, y + d, size, size, r); g.fill();
  // الوجه
  const gr = g.createLinearGradient(x, y, x, y + size);
  gr.addColorStop(0, '#fffdf6'); gr.addColorStop(1, '#f4ead2');
  g.fillStyle = gr; rr(x, y, size, size, r); g.fill();
  g.strokeStyle = 'rgba(169,120,30,.55)'; g.lineWidth = Math.max(1, T * .025 * s); g.stroke();
  const img = tileImgs[t.t];
  if(img){ const is = size * .86; g.drawImage(img, x + (size - is) / 2, y + (size - is) / 2, is, is); }
  if(!free){ g.fillStyle = 'rgba(30,60,56,.42)'; rr(x, y, size, size, r); g.fill(); }
  g.restore();
}
function drawTray(){
  const x = trayX - 8, y = trayY, w = slotT * 7 + 16, h = slotT * 1.32;
  g.fillStyle = 'rgba(15,61,56,.25)'; rr(x, y + 5, w, h, 18); g.fill();
  const gr = g.createLinearGradient(0, y, 0, y + h); gr.addColorStop(0, '#2a8a7e'); gr.addColorStop(1, '#1f6a63');
  g.fillStyle = gr; rr(x, y, w, h, 18); g.fill();
  g.strokeStyle = '#e8b84a'; g.lineWidth = 3; rr(x + 1.5, y + 1.5, w - 3, h - 3, 17); g.stroke();
  for(let i = 0; i < 7; i++){
    g.fillStyle = 'rgba(255,255,255,.12)';
    rr(trayX + i * slotT + slotT * .06, trayY + slotT * .16, slotT * .88, slotT * .88, slotT * .16); g.fill();
  }
  if(vTray.length >= 5 && !over){
    g.strokeStyle = `rgba(224,69,123,${.5 + .5 * Math.sin(performance.now() / 150)})`; g.lineWidth = 4;
    rr(x - 2, y - 2, w + 4, h + 4, 20); g.stroke();
  }
}
function frame(now){
  if(!running) return;
  requestAnimationFrame(frame);
  if(!S) return;
  const dt = Math.min(50, now - lastTick); lastTick = now;
  if(!modalOpen && !over && S.picks > 0){ elapsed += dt; if(Math.floor(elapsed / 1000) !== Math.floor((elapsed - dt) / 1000)) updateHud(); }
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, W, H);
  // تحريك
  const k = 1 - Math.pow(.0005, dt / 1000 * 2.2);
  sprites.forEach(sp => {
    if(now < sp.born) { sp.a = 0; return; }
    sp.x += (sp.tx - sp.x) * k; sp.y += (sp.ty - sp.y) * k; sp.s += (sp.ts - sp.s) * k;
    if(!sp.dying) sp.a = Math.min(1, sp.a + dt / 200);
  });
  drawTray();
  // اللوحة: من التحت للفوق
  const board = S.tiles.filter(t => t.state === 'board' && vTray.indexOf(t.id) < 0).sort((a, b) => a.z - b.z || a.y - b.y || a.x - b.x);
  for(const t of board){
    const sp = sprites.get(t.id); if(!sp) continue;
    let dx = 0; if(shake && shake.id === t.id){ const e = (now - shake.t0) / 300; if(e < 1) dx = Math.sin(e * 30) * 4 * (1 - e); else shake = null; }
    sp.x += dx; drawTile(sp, t, E.isFree(S, t)); sp.x -= dx;
  }
  // الشريط
  vTray.forEach(id => { const sp = sprites.get(id); if(sp) drawTile(sp, S.tiles[id], true); });
  // اللي كيطيرو أو كيختفيو
  sprites.forEach(sp => { if(sp.flying && !sp.dying && vTray.indexOf(sp.id) < 0) drawTile(sp, S.tiles[sp.id], true); });
  sprites.forEach(sp => {
    if(sp.dying){ sp.dying = Math.min(1, sp.dying + dt / 260); drawTile(sp, S.tiles[sp.id], true); if(sp.dying >= 1) sprites.delete(sp.id); }
  });
  // شرارات
  parts = parts.filter(p => { p.t += dt; if(p.t > p.life) return false; const e = p.t / p.life; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += .0006 * dt;
    g.save(); g.globalAlpha = 1 - e; Art.sparkle(g, p.x, p.y, p.r * (1 - e * .5), 1); g.restore(); return true; });
}

// ---------- اللعب ----------
function hitTest(px, py){
  const cand = S.tiles.filter(t => t.state === 'board').sort((a, b) => b.z - a.z || b.y - a.y || b.x - a.x);
  for(const t of cand){
    const p = boardPos(t);
    if(px >= p.x && px <= p.x + T && py >= p.y && py <= p.y + T + depth) return t;
  }
  return null;
}
cv.addEventListener('pointerdown', e => {
  if(!S || busy || over || modalOpen) return;
  const r = cv.getBoundingClientRect();
  const t = hitTest(e.clientX - r.left, e.clientY - r.top);
  if(!t) return;
  if(!E.isFree(S, t)){ shake = { id: t.id, t0: performance.now() }; SFX.bad(); return; }
  doPick(t.id);
});

async function doPick(id){
  const before = vTray.slice();
  const res = E.pick(S, id);
  if(!res.ok) return;
  SFX.tap(); haptic();
  // كنحطوها فالبلاصة ديالها (مع اللي غادي يتمسحو)
  const vis = before.slice(); vis.splice(res.slot, 0, id);
  vTray = vis; retarget();
  updateHud();
  if(res.cleared.length){
    busy = true;
    await sleep(230);
    res.cleared.forEach(cid => { const sp = sprites.get(cid); if(sp){ sp.dying = .01; burst(sp.x + slotT * .44, sp.y + slotT * .44); } });
    vTray = vTray.filter(i => !res.cleared.includes(i)); retarget();
    SFX.match(); haptic('big');
    busy = false;
  }
  if(res.won) return winSequence();
  if(res.lost) return loseSequence();
}
function burst(x, y){
  for(let i = 0; i < 7; i++){ const a = Math.random() * Math.PI * 2, v = .05 + Math.random() * .12; parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - .08, r: 4 + Math.random() * 6, t: 0, life: 500 + Math.random() * 300 }); }
}

async function winSequence(){
  over = true; busy = true;
  await sleep(450);
  SFX.win(); haptic('ok');
  for(let i = 0; i < 20; i++) burst(W * Math.random(), H * .3 * Math.random() + H * .2);
  await sleep(600);
  const sec = elapsed / 1000;
  const st = sec <= L.t3 ? 3 : sec <= L.t2 ? 2 : 1;
  const first = !best[lvIndex];
  if(!best[lvIndex] || st > best[lvIndex]){ best[lvIndex] = st; store.set('best', best); }
  const reward = (first ? 15 : 5) + st * 5 + (first && (lvIndex + 1) % 10 === 0 ? 50 : 0);
  setCoins(coins + reward); SFX.coin();
  const last = lvIndex >= LV.length - 1;
  const s = Math.round(sec);
  modal(`<h2>${['', 'جيد!', 'رائع!', 'مذهل!'][st]}</h2>
    <div class="stars">${[1, 2, 3].map(i => `<span class="${i <= st ? 'on' : ''}" style="animation-delay:${i * .15}s">⭐</span>`).join('')}</div>
    <p>الوقت: <b dir="ltr">${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}</b><br><span dir="ltr">+${reward}</span> 🪙${last ? '<br><br>أكملتِ كل المستويات! مستويات جديدة قريباً ✨' : ''}</p>
    ${last ? '' : '<button class="big" id="m-next">المستوى التالي</button>'}
    <button class="alt" id="m-again">إعادة المستوى</button><button class="alt" id="m-map">الخريطة</button>`, false);
  if(!last) $('m-next').onclick = async () => { closeModal(); await Ads.maybeInterstitial(); startLevel(lvIndex + 1); };
  $('m-again').onclick = async () => { closeModal(); await Ads.maybeInterstitial(); startLevel(lvIndex); };
  $('m-map').onclick = () => { closeModal(); openMap(); };
}

async function loseSequence(){
  over = true; busy = true;
  await sleep(500);
  SFX.lose();
  const canVideo = rescues < 2;
  modal(`<h2>امتلأ الشريط!</h2>
    <p>أرجعي آخر <b>${RESCUE_N}</b> قطع إلى اللوحة وأكملي اللعب.</p>
    ${canVideo ? `<button class="big" id="m-vid">🎬 شاهدي فيديو وأكملي</button>` : ''}
    <button class="big gold" id="m-buy" style="margin-top:12px">أكملي مقابل ${RESCUE_COST} 🪙</button>
    <button class="alt" id="m-retry">إعادة المحاولة</button><button class="alt" id="m-map">الخريطة</button>`, false);
  if(canVideo) $('m-vid').onclick = async () => {
    if(!Ads.isNative){ closeModal(); rescue(); return; }
    if(!Ads.rewardedAvailable()){ toast('لا يوجد فيديو الآن، حاولي لاحقاً'); return; }
    const ok = await Ads.showRewarded();
    if(ok){ closeModal(); rescue(); } else toast('لا يوجد فيديو الآن، حاولي لاحقاً');
  };
  $('m-buy').onclick = () => {
    if(coins < RESCUE_COST){ toast('لا تملكين عملات كافية'); return; }
    setCoins(coins - RESCUE_COST); closeModal(); rescue(true);
  };
  $('m-retry').onclick = async () => { closeModal(); await Ads.maybeInterstitial(); startLevel(lvIndex); };
  $('m-map').onclick = async () => { closeModal(); await Ads.maybeInterstitial(); openMap(); };
}
function rescue(paid){
  if(!paid) rescues++;
  E.rescue(S, RESCUE_N);
  vTray = S.tray.slice(); retarget();
  SFX.whoosh(); toast('أكملي! 💪');
  over = false; busy = false; updateHud();
}

// ---------- الأدوات ----------
function canUse(cost){
  if(!S || busy || over || modalOpen) return false;
  if(coins < cost){ offerVideo(true); return false; }
  return true;
}
$('b-undo').onclick = () => {
  if(!S || busy || over || modalOpen) return;
  if(!S.history.length){ toast('لا يوجد ما يمكن التراجع عنه'); return; }
  if(!canUse(UNDO_COST)) return;
  setCoins(coins - UNDO_COST);
  E.undo(S); vTray = S.tray.slice(); retarget(); SFX.whoosh(); updateHud();
};
$('b-magnet').onclick = async () => {
  if(!canUse(MAGNET_COST)) return;
  const res = E.magnet(S); if(!res){ toast('لا يمكن الآن'); return; }
  setCoins(coins - MAGNET_COST);
  busy = true;
  // القطع اللي جات من اللوحة كتطير للشريط ومن بعد كتختفي
  res.ids.forEach((id, i) => { const sp = sprites.get(id); if(sp){ sp.flying = true; const p = slotPos(Math.min(6, vTray.length + i)); sp.tx = p.x; sp.ty = p.y; sp.ts = p.s; } });
  SFX.whoosh();
  await sleep(320);
  res.ids.forEach(id => { const sp = sprites.get(id); if(sp){ sp.dying = .01; burst(sp.x + slotT * .44, sp.y + slotT * .44); } });
  vTray = S.tray.slice(); retarget();
  SFX.match(); haptic('big'); updateHud();
  busy = false;
  if(res.won) winSequence();
};
$('b-mix').onclick = async () => {
  if(!canUse(MIX_COST)) return;
  setCoins(coins - MIX_COST);
  E.shuffle(S);
  busy = true; SFX.whoosh();
  const cx = W / 2, cy = trayY / 2;
  S.tiles.forEach(t => { if(t.state === 'board'){ const sp = sprites.get(t.id); if(sp){ sp.tx = cx - T / 2; sp.ty = cy - T / 2; } } });
  await sleep(300);
  retarget();
  await sleep(250);
  busy = false;
};
function offerVideo(need){
  modal(`<h2>🎬</h2><p>${need ? 'لا تملكين عملات كافية.<br>' : ''}شاهدي فيديو قصيراً واحصلي على <b>${VIDEO_REWARD}</b> عملة.</p><button class="big" id="m-watch">شاهدي الفيديو</button><button class="alt" id="m-no">لا، شكراً</button>`);
  $('m-no').onclick = closeModal;
  $('m-watch').onclick = async () => {
    if(!Ads.isNative){ closeModal(); videoReward(); return; }
    if(!Ads.rewardedAvailable()){ closeModal(); toast('لا يوجد فيديو الآن، حاولي لاحقاً'); return; }
    const ok = await Ads.showRewarded(); closeModal();
    if(ok) videoReward(); else toast('لا يوجد فيديو الآن، حاولي لاحقاً');
  };
}
function videoReward(){ setCoins(coins + VIDEO_REWARD); SFX.coin(); toast(`🪙 ${VIDEO_REWARD}+`); }
$('b-video').onclick = () => { if(!modalOpen) offerVideo(false); };

// ---------- الإيقاف ----------
function pauseMenu(){
  if(over) return;
  modal(`<h2>استراحة</h2><p>المستوى ${lvIndex + 1}</p>
    <button class="big" id="m-cont">متابعة</button>
    <button class="alt" id="m-restart">إعادة المستوى</button>
    <button class="alt" id="m-snd">${sound ? '🔊 الصوت: يعمل' : '🔇 الصوت: متوقف'}</button>
    <button class="alt" id="m-map">الخريطة</button>`);
  $('m-cont').onclick = closeModal;
  $('m-restart').onclick = () => { closeModal(); startLevel(lvIndex); };
  $('m-snd').onclick = () => { sound = !sound; store.set('sound', sound); pauseMenu(); };
  $('m-map').onclick = () => { closeModal(); openMap(); };
}
$('b-pause').onclick = pauseMenu;

// ---------- Android ----------
window.addEventListener('resize', () => { if(screen === 'game' && S){ layout(); retarget(); } });
if(N && N.isNative){
  try{ N.StatusBar.setStyle({ style: N.Style.Light }); N.StatusBar.setBackgroundColor({ color: '#eef8f6' }); }catch(e){}
  try{ N.App.addListener('backButton', () => {
    if(modalOpen){ if(modalClosable) closeModal(); return; }
    if(screen === 'game'){ pauseMenu(); return; }
    if(screen === 'map'){ renderMenu(); show('menu'); return; }
    N.App.exitApp();
  }); }catch(e){}
  try{ N.App.addListener('pause', () => { if(actx) actx.suspend(); }); N.App.addListener('resume', () => { if(actx) actx.resume(); }); }catch(e){}
}

renderMenu(); show('menu');
Ads.init().finally(() => { Ads.showBanner(); renderMenu(); try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} });
setTimeout(() => { try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} }, 2500);

// للتجربة
window.__zn = { closeModal, get S(){ return S; }, get L(){ return L; }, startLevel, doPick, get busy(){ return busy; }, get over(){ return over; }, setCoins, get vTray(){ return vTray; }, get sprites(){ return sprites; }, boardPos: t => boardPos(t) };
})();
