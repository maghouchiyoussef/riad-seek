// Twist Out — Screw Puzzle. UI, rendering, input.
(function(){
'use strict';
const $ = (s) => document.querySelector(s);
const N = window.Native;
const TW = window.TW;

// ---------- i18n ----------
const L = {
 en:{sub:'Unscrew. Sort. Relax.',play:'Play',levels:'Levels',settings:'Settings',level:'LEVEL',left:'SCREWS',win:'Level Clear!',lose:'No space left!',next:'Next',retry:'Retry',home:'Home',cont:'+1 slot (ad)',resume:'Resume',sound:'Sound',vib:'Vibration',privacy:'Privacy options',close:'Close',boostAd:'Out of boosters! Watch an ad for +2?',yes:'Watch ad',no:'No thanks',adNo:'Ad not ready, try later',hint:'Tap a free screw. Match 3 of the same color in a box!',pause:'Paused',blocked:'Blocked! Remove the plates on top first',noMag:'No free screw of that color',slotMax:'Maximum slots reached',lv:'Level',g1:'Nice!',g2:'Great!',g3:'Awesome!'},
 ar:{sub:'فكّ. رتّب. استرخِ.',play:'العب',levels:'المراحل',settings:'الإعدادات',level:'المرحلة',left:'البراغي',win:'أحسنت! أنهيت المرحلة',lose:'امتلأت الخانات!',next:'التالي',retry:'أعد المحاولة',home:'الرئيسية',cont:'+1 خانة (إعلان)',resume:'متابعة',sound:'الصوت',vib:'الاهتزاز',privacy:'خيارات الخصوصية',close:'إغلاق',boostAd:'انتهت المعززات! شاهد إعلانًا لتحصل على 2 إضافية؟',yes:'شاهد الإعلان',no:'لا، شكرًا',adNo:'الإعلان غير جاهز، حاول لاحقًا',hint:'اضغط على برغي حر، واجمع 3 من نفس اللون في الصندوق!',pause:'متوقف مؤقتًا',blocked:'مغطى! أزل الألواح التي فوقه أولًا',noMag:'لا يوجد برغي حر بهذا اللون',slotMax:'وصلت للحد الأقصى من الخانات',lv:'المرحلة',g1:'جميل!',g2:'رائع!',g3:'مذهل!'},
 fr:{sub:'Dévisse. Trie. Détends-toi.',play:'Jouer',levels:'Niveaux',settings:'Réglages',level:'NIVEAU',left:'VIS',win:'Niveau réussi !',lose:'Plus de place !',next:'Suivant',retry:'Réessayer',home:'Accueil',cont:'+1 case (pub)',resume:'Reprendre',sound:'Son',vib:'Vibration',privacy:'Options de confidentialité',close:'Fermer',boostAd:'Plus de bonus ! Regarder une pub pour +2 ?',yes:'Regarder',no:'Non merci',adNo:'Pub indisponible, réessayez',hint:'Touche une vis libre. 3 de la même couleur dans une boîte !',pause:'Pause',blocked:'Bloquée ! Retire d’abord les planches du dessus',noMag:'Aucune vis libre de cette couleur',slotMax:'Nombre maximum de cases',lv:'Niveau',g1:'Bien !',g2:'Super !',g3:'Génial !'},
 es:{sub:'Desatornilla. Ordena. Relájate.',play:'Jugar',levels:'Niveles',settings:'Ajustes',level:'NIVEL',left:'TORNILLOS',win:'¡Nivel superado!',lose:'¡Sin espacio!',next:'Siguiente',retry:'Reintentar',home:'Inicio',cont:'+1 hueco (anuncio)',resume:'Continuar',sound:'Sonido',vib:'Vibración',privacy:'Opciones de privacidad',close:'Cerrar',boostAd:'¡Sin potenciadores! ¿Ver un anuncio para +2?',yes:'Ver anuncio',no:'No, gracias',adNo:'Anuncio no disponible',hint:'Toca un tornillo libre. ¡3 del mismo color en una caja!',pause:'Pausa',blocked:'¡Bloqueado! Quita primero las tablas de arriba',noMag:'No hay tornillo libre de ese color',slotMax:'Máximo de huecos',lv:'Nivel',g1:'¡Bien!',g2:'¡Genial!',g3:'¡Increíble!'},
 pt:{sub:'Desparafuse. Organize. Relaxe.',play:'Jogar',levels:'Níveis',settings:'Ajustes',level:'NÍVEL',left:'PARAFUSOS',win:'Nível concluído!',lose:'Sem espaço!',next:'Próximo',retry:'Tentar de novo',home:'Início',cont:'+1 espaço (anúncio)',resume:'Continuar',sound:'Som',vib:'Vibração',privacy:'Opções de privacidade',close:'Fechar',boostAd:'Sem reforços! Ver anúncio para +2?',yes:'Ver anúncio',no:'Não, obrigado',adNo:'Anúncio indisponível',hint:'Toque num parafuso livre. 3 da mesma cor numa caixa!',pause:'Pausado',blocked:'Bloqueado! Remova primeiro as tábuas de cima',noMag:'Nenhum parafuso livre dessa cor',slotMax:'Máximo de espaços',lv:'Nível',g1:'Boa!',g2:'Ótimo!',g3:'Incrível!'},
};
const lang = (() => { const l = (navigator.language || 'en').slice(0,2).toLowerCase(); return L[l] ? l : 'en'; })();
const t = (k) => (L[lang][k] || L.en[k] || k);
if(lang === 'ar'){ document.documentElement.lang = 'ar'; document.documentElement.dir = 'rtl'; }

// ---------- save ----------
let SV = { lvl:1, slot:2, mag:2, snd:1, vib:1, stars:{} };
try{ Object.assign(SV, JSON.parse(localStorage.getItem('tw_save') || '{}')); }catch(e){}
const save = () => { try{ localStorage.setItem('tw_save', JSON.stringify(SV)); }catch(e){} };

// ---------- audio / haptics ----------
let AC = null;
function tone(f, d, type, vol, slide){
  if(!SV.snd) return;
  try{
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    const o = AC.createOscillator(), g = AC.createGain();
    o.type = type || 'sine'; o.frequency.value = f;
    if(slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, f*slide), AC.currentTime + d);
    g.gain.value = vol || .08; g.gain.exponentialRampToValueAtTime(.0001, AC.currentTime + d);
    o.connect(g); g.connect(AC.destination); o.start(); o.stop(AC.currentTime + d);
  }catch(e){}
}
const sndTwist = () => { tone(900,.05,'square',.03,1.3); setTimeout(()=>tone(1200,.05,'square',.03,1.2),50); };
const sndDrop = () => tone(260,.12,'triangle',.07,.7);
const sndBox = () => [660,880].forEach((f,i)=>setTimeout(()=>tone(f,.12,'triangle',.08),i*80));
const sndFall = () => tone(180,.35,'sawtooth',.04,.4);
const sndWin = () => [523,659,784,1047].forEach((f,i)=>setTimeout(()=>tone(f,.25,'triangle',.09),i*120));
const sndBad = () => tone(140,.18,'square',.05,.8);
function buzz(ms){ if(!SV.vib) return; try{ N && N.isNative ? N.Haptics.vibrate({duration: ms||20}) : navigator.vibrate && navigator.vibrate(ms||20); }catch(e){} }

// ---------- canvas ----------
const W = 360, H = 600, SR = TW.SR;
const COL = [['#ff8a80','#d32f2f'],['#82b1ff','#1e5fd8'],['#b9f6ca','#2e9d4a'],['#fff59d','#e0b000'],['#ea80fc','#8e24aa'],['#ffcc80','#ef6c00'],['#84ffff','#00838f']];
const WOOD = [['#e9c08a','#b67b3f'],['#d9a066','#9c5e2b'],['#f0d3a3','#c08b52'],['#c98f5b','#87502a'],['#e3b27a','#a86a34']];
const cv = $('#cv'), ctx = cv.getContext('2d');
let scale = 1, dpr = 1;
function fit(){
  const wrap = $('#boardWrap'); if(!wrap.clientWidth) return;
  dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  scale = Math.min(wrap.clientWidth / W, wrap.clientHeight / H);
  cv.style.width = W*scale + 'px'; cv.style.height = H*scale + 'px';
  cv.width = Math.round(W*scale*dpr); cv.height = Math.round(H*scale*dpr);
}
addEventListener('resize', fit);

// layout
const BOX_Y = 38, BOX_W = 132, BOX_H = 56, BOX_X = [96, 264];
const BUF_Y = 108;
function boxHole(i, k){ return [BOX_X[i] - 36 + k*36, BOX_Y + 2]; }
function bufHole(k, cap){ const gap = 40, x0 = W/2 - (cap-1)*gap/2; return [x0 + k*gap, BUF_Y]; }

// ---------- state ----------
let level = 1, lv = null, st = null, state = 'idle';
let flights = [], falling = [], leaving = [], entering = [0,0], fx = [], shakes = [];
let pendBox = [0,0], pendBuf = 0, maxBuf = 0, magUsed = false, slotAdUsed = false;

function startLevel(n){
  level = n; lv = TW.buildLevel(n); st = TW.newState(lv);
  flights = []; falling = []; leaving = []; fx = []; shakes = []; entering = [1,1];
  pendBox = [0,0]; pendBuf = 0; maxBuf = 0; slotAdUsed = false;
  state = 'play'; updHud(); show('game'); setTimeout(fit, 0);
  if(n <= 2) setTimeout(() => toast(t('hint')), 300);
}
function updHud(){
  $('#gLevel').textContent = level;
  $('#gLeft').textContent = st ? st.screws.filter(s=>s.alive).length : 0;
  $('#cSlot').textContent = SV.slot; $('#cMag').textContent = SV.mag;
}

// ---------- input ----------
function pt(e){ const r = cv.getBoundingClientRect(); return [(e.clientX - r.left)/r.width*W, (e.clientY - r.top)/r.height*H]; }
cv.addEventListener('pointerdown', (e) => {
  if(state !== 'play') return;
  e.preventDefault();
  const [x,y] = pt(e);
  let hit = null;
  for(const s of st.screws){ if(!s.alive) continue; if(Math.hypot(s.x-x, s.y-y) < SR+9){ if(!hit || s.plate > hit.plate) hit = s; } }
  // a plate drawn above the hit point steals the touch (screw is hidden)
  if(hit){
    for(let i=st.plates.length-1;i>hit.plate;i--){ const p = st.plates[i]; if(p.alive && TW.inPlate(p, x, y, 0)){ hit = null; shakePlate(i); return; } }
    doTap(hit.id);
  } else {
    for(let i=st.plates.length-1;i>=0;i--){ const p = st.plates[i]; if(p.alive && TW.inPlate(p, x, y, 0)){ shakePlate(i); return; } }
  }
});
function shakePlate(i){ shakes.push({p:i, t:0}); sndBad(); buzz(15); }

function doTap(sid){
  const s = st.screws[sid];
  if(!TW.accessible(st, s)){
    toast(t('blocked')); sndBad(); buzz(30);
    for(let i=s.plate+1;i<st.plates.length;i++){ const p = st.plates[i]; if(p.alive && TW.inPlate(p, s.x, s.y, SR*0.55)) shakes.push({p:i, t:0}); }
    return;
  }
  const bi = st.boxes.findIndex(b => b && b.color===s.color && b.n<3);
  let target, kind;
  if(bi >= 0){ target = boxHole(bi, st.boxes[bi].n); kind = 'box'; }
  else if(st.buf.length < st.cap){ target = bufHole(st.buf.length, st.cap); kind = 'buf'; }
  else { toast(t('lose')); sndBad(); return; }
  const oldBox = bi >= 0 ? st.boxes[bi] : null;
  const bufBefore = st.buf.length;
  const res = TW.tap(st, sid);
  if(!res.ok) return;
  sndTwist(); buzz(12);
  const fl = { x:s.x, y:s.y, sx:s.x, sy:s.y, tx:target[0], ty:target[1], color:s.color, t:0, dur:.32, rot:0 };
  if(kind === 'box'){
    if(res.filled){
      const lb = { slot:bi, color:oldBox.color, pend:1, t:-1 };
      leaving.push(lb); entering[bi] = -1; // new box waits
      fl.done = () => { lb.pend--; sndDrop(); };
    } else { pendBox[bi]++; fl.done = () => { pendBox[bi]--; sndDrop(); }; }
  } else {
    pendBuf++; fl.done = () => { pendBuf--; sndDrop(); };
  }
  flights.push(fl);
  maxBuf = Math.max(maxBuf, st.buf.length);
  res.fell.forEach(pid => { const p = st.plates[pid]; falling.push({...p, vy:-60, vx:(Math.random()-.5)*60, va:(Math.random()-.5)*3, t:0}); setTimeout(sndFall, 120); });
  updHud();
  if(res.win) setTimeout(win, 900);
  else if(res.lose) setTimeout(lose, 700);
}

// ---------- boosters ----------
$('#bSlot').onclick = () => {
  if(state !== 'play') return;
  if(st.cap >= 7){ toast(t('slotMax')); return; }
  if(SV.slot <= 0){ offerAd(); return; }
  SV.slot--; save(); st.cap++; updHud(); tone(700,.15,'triangle',.08); buzz(15);
};
$('#bMag').onclick = () => {
  if(state !== 'play') return;
  if(SV.mag <= 0){ offerAd(); return; }
  const bi = st.boxes.findIndex(b => b && b.n < 3); if(bi < 0) return;
  const col = st.boxes[bi].color;
  const free = st.screws.filter(s => s.alive && s.color===col && TW.accessible(st,s));
  if(!free.length){ toast(t('noMag')); return; }
  SV.mag--; save(); updHud();
  free.slice(0, 3 - st.boxes[bi].n).forEach((s,i) => setTimeout(() => { if(state==='play') doTap(s.id); }, i*180));
};
$('#bRe').onclick = () => { if(state === 'play') startLevel(level); };
function offerAd(){
  const was = state; state = 'modal';
  modal(`<p style="font-size:18px">${t('boostAd')}</p>
    <button class="btn grn" id="aYes">▶ ${t('yes')}</button>
    <button class="btn alt sm" id="aNo">${t('no')}</button>`);
  $('#aNo').onclick = () => { closeModal(); state = was; };
  $('#aYes').onclick = async () => { if(await rewarded()){ SV.slot += 2; SV.mag += 2; save(); updHud(); closeModal(); state = was; toast('+2 ➕  +2 🧲'); } };
}
async function rewarded(){
  if(!Ads.isNative) return true; // web preview only
  if(!Ads.rewardedAvailable()){ toast(t('adNo')); return false; }
  return !!(await Ads.showRewarded());
}

// ---------- end ----------
function win(){
  if(state !== 'play') return;
  state = 'over'; sndWin(); buzz(60);
  const stars = maxBuf <= 2 ? 3 : maxBuf <= 4 ? 2 : 1;
  SV.lvl = Math.max(SV.lvl, level+1); SV.stars[level] = Math.max(SV.stars[level]||0, stars);
  if(level % 5 === 0){ SV.slot++; SV.mag++; }
  save();
  modal(`<h2>${t('win')}</h2><div class="stars" id="st"><span>⭐</span><span>⭐</span><span>⭐</span></div>
    <button class="btn grn big" id="mNext" style="padding:14px 40px">${t('next')} ▶</button>
    <button class="btn alt sm" id="mHome">${t('home')}</button>`);
  [...document.querySelectorAll('#st span')].forEach((s,i) => { if(i < stars) setTimeout(() => { s.classList.add('on'); tone(600+i*150,.15,'triangle',.08); }, 250+i*300); });
  $('#mNext').onclick = async () => { await afterRound(); closeModal(); startLevel(level+1); };
  $('#mHome').onclick = () => { closeModal(); goHome(); };
}
async function afterRound(){ if(level >= 3){ try{ await Ads.maybeInterstitial(); }catch(e){} } }
function lose(){
  if(state !== 'play') return;
  state = 'over'; sndBad(); buzz(80);
  const canAd = !slotAdUsed && st.cap < 7;
  modal(`<h2>${t('lv')} ${level}</h2><p>${t('lose')}</p>
    ${canAd ? `<button class="btn grn" id="mCont">▶ ${t('cont')}</button>` : ''}
    <button class="btn big" id="mRetry" style="padding:14px 40px">${t('retry')}</button>
    <button class="btn alt sm" id="mHome">${t('home')}</button>`);
  if(canAd) $('#mCont').onclick = async () => { if(!(await rewarded())) return; slotAdUsed = true; st.cap++; closeModal(); state = 'play'; };
  $('#mRetry').onclick = async () => { await afterRound(); closeModal(); startLevel(level); };
  $('#mHome').onclick = () => { closeModal(); goHome(); };
}

// ---------- ui ----------
function modal(html){ const m = $('#modal'); m.innerHTML = '<div class="box">' + html + '</div>'; m.classList.add('show'); }
function closeModal(){ $('#modal').classList.remove('show'); $('#modal').innerHTML = ''; }
let toastT = 0;
function toast(s){ const e = $('#toast'); e.textContent = s; e.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => e.classList.remove('show'), 2200); }
function say(s){ const m = $('#msg'); m.textContent = s; m.classList.remove('show'); void m.offsetWidth; m.classList.add('show'); }
function show(id){
  document.querySelectorAll('.scr').forEach(s => s.classList.toggle('show', s.id === id));
  if(id === 'game') Ads.hideBanner(); else Ads.showBanner();
}
function goHome(){ state = 'idle'; $('#hLevel').textContent = t('lv') + ' ' + SV.lvl; $('#hBest').textContent = '⭐ ' + Object.values(SV.stars).reduce((a,b)=>a+b,0); show('home'); }
function buildMap(){
  const g = $('#lvgrid'); g.innerHTML = '';
  const total = Math.max(40, SV.lvl + 9);
  for(let i=1;i<=total;i++){
    const b = document.createElement('button'); b.className = 'lv' + (i === SV.lvl ? ' cur' : i > SV.lvl ? ' lock' : '');
    b.innerHTML = i > SV.lvl ? '🔒' : i + (SV.stars[i] ? '<small>' + '★'.repeat(SV.stars[i]) + '</small>' : '');
    if(i <= SV.lvl) b.onclick = () => startLevel(i);
    g.appendChild(b);
  }
  $('#mTitle').textContent = t('levels'); $('#mBest').textContent = '⭐ ' + Object.values(SV.stars).reduce((a,b)=>a+b,0);
  show('map');
  const c = g.querySelector('.cur'); if(c) setTimeout(() => c.scrollIntoView({block:'center'}), 0);
}
function settings(){
  const row = (id, label, on) => `<div class="setrow"><span>${label}</span><button class="btn sm ${on?'grn':'alt'}" id="${id}">${on?'ON':'OFF'}</button></div>`;
  modal(`<h2>${t('settings')}</h2>${row('sSnd',t('sound'),SV.snd)}${row('sVib',t('vib'),SV.vib)}
    ${Ads.privacyRequired ? `<button class="btn alt sm" id="sPriv">🔒 ${t('privacy')}</button>` : ''}
    <button class="btn" id="sClose">${t('close')}</button>`);
  $('#sSnd').onclick = () => { SV.snd = SV.snd ? 0 : 1; save(); settings(); };
  $('#sVib').onclick = () => { SV.vib = SV.vib ? 0 : 1; save(); settings(); };
  const p = $('#sPriv'); if(p) p.onclick = () => Ads.showPrivacyOptions();
  $('#sClose').onclick = closeModal;
}
function pause(){
  if(state !== 'play') return; state = 'modal';
  modal(`<h2>${t('pause')}</h2><button class="btn grn" id="pR">▶ ${t('resume')}</button>
    <button class="btn alt sm" id="pRe">${t('retry')}</button><button class="btn alt sm" id="pH">${t('home')}</button>`);
  $('#pR').onclick = () => { closeModal(); state = 'play'; };
  $('#pRe').onclick = () => { closeModal(); startLevel(level); };
  $('#pH').onclick = () => { closeModal(); goHome(); };
}
$('#bPlay').onclick = () => startLevel(SV.lvl);
$('#bMap').onclick = buildMap;
$('#bSet').onclick = settings;
$('#mBack').onclick = goHome;
$('#bPause').onclick = pause;
try{ N && N.App && N.App.addListener('backButton', () => {
  if($('#modal').classList.contains('show')){ const r = $('#pR'); if(r) r.click(); else if(state !== 'over') { closeModal(); state = 'play'; } return; }
  if($('#game').classList.contains('show')) pause();
  else if($('#map').classList.contains('show')) goHome();
  else N.App.exitApp();
}); N && N.App && N.App.addListener('pause', () => { if($('#game').classList.contains('show')) pause(); }); }catch(e){}

// ---------- drawing ----------
function rr(x, y, w, h, r){ ctx.beginPath(); ctx.moveTo(x+r,y); ctx.arcTo(x+w,y,x+w,y+h,r); ctx.arcTo(x+w,y+h,x,y+h,r); ctx.arcTo(x,y+h,x,y,r); ctx.arcTo(x,y,x+w,y,r); ctx.closePath(); }
function screw(x, y, c, rot, s){
  s = s || 1; const r = SR*s;
  ctx.save(); ctx.translate(x, y);
  ctx.beginPath(); ctx.arc(1.5, 2.5, r, 0, 7); ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.fill();
  const g = ctx.createRadialGradient(-r*.35, -r*.4, r*.1, 0, 0, r); g.addColorStop(0, '#fff'); g.addColorStop(.3, COL[c][0]); g.addColorStop(1, COL[c][1]);
  ctx.beginPath(); ctx.arc(0, 0, r, 0, 7); ctx.fillStyle = g; ctx.fill();
  ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(0,0,0,.25)'; ctx.stroke();
  ctx.rotate(rot || 0); ctx.strokeStyle = 'rgba(40,20,0,.55)'; ctx.lineWidth = 3*s; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(-r*.5,0); ctx.lineTo(r*.5,0); ctx.moveTo(0,-r*.5); ctx.lineTo(0,r*.5); ctx.stroke();
  ctx.restore();
}
function hole(x, y, r){ ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fillStyle = 'rgba(40,20,5,.55)'; ctx.fill(); ctx.beginPath(); ctx.arc(x, y+1, r, 0, Math.PI); ctx.strokeStyle = 'rgba(255,255,255,.25)'; ctx.lineWidth = 1; ctx.stroke(); }
function plateShape(p, ox, oy, extraRot){
  ctx.save(); ctx.translate(p.x + (ox||0), p.y + (oy||0)); ctx.rotate(p.a + (extraRot||0));
  const wd = WOOD[p.hue % WOOD.length];
  ctx.fillStyle = 'rgba(0,0,0,.25)'; rr(-p.w/2+3, -p.h/2+5, p.w, p.h, 12); ctx.fill();
  const g = ctx.createLinearGradient(0, -p.h/2, 0, p.h/2); g.addColorStop(0, wd[0]); g.addColorStop(1, wd[1]);
  ctx.fillStyle = g; rr(-p.w/2, -p.h/2, p.w, p.h, 12); ctx.fill();
  ctx.strokeStyle = 'rgba(70,35,10,.6)'; ctx.lineWidth = 2; ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,.12)'; ctx.lineWidth = 1.2;
  for(let k=-p.h/2+9;k<p.h/2-4;k+=9){ ctx.beginPath(); ctx.moveTo(-p.w/2+10, k); ctx.bezierCurveTo(-p.w/6, k+3, p.w/6, k-3, p.w/2-10, k); ctx.stroke(); }
  ctx.restore();
}
function draw(dt){
  ctx.setTransform(scale*dpr,0,0,scale*dpr,0,0);
  ctx.clearRect(0,0,W,H);
  // board
  ctx.fillStyle = 'rgba(30,15,5,.28)'; rr(6, 134, W-12, 436, 18); ctx.fill();
  // boxes
  for(let i=0;i<2;i++){
    const lb = leaving.find(l => l.slot===i);
    if(lb){ drawBox(i, lb.color, 3 - lb.pend, lb.t > 0 ? -lb.t*260 : 0); }
    const b = st.boxes[i];
    if(b && !lb){ const off = entering[i] < 1 ? (1-entering[i])*-120 : 0; drawBox(i, b.color, b.n - pendBox[i], off); }
  }
  // buffer
  for(let k=0;k<st.cap;k++){ const [x,y] = bufHole(k, st.cap); ctx.beginPath(); ctx.arc(x,y,SR+5,0,7); ctx.fillStyle='rgba(30,15,5,.45)'; ctx.fill(); ctx.strokeStyle='rgba(255,230,190,.35)'; ctx.lineWidth=1.5; ctx.stroke(); }
  const shown = st.buf.length - pendBuf;
  for(let k=0;k<shown;k++){ const [x,y] = bufHole(k, st.cap); screw(x, y, st.buf[k], 0, .92); }
  // plates + screws (low → high)
  for(const p of st.plates){
    if(!p.alive) continue;
    const sh = shakes.find(s => s.p===p.id); const ox = sh ? Math.sin(sh.t*60)*4*(1-sh.t/.35) : 0;
    plateShape(p, ox, 0);
    // holes for removed screws
    for(const s of lv.screws) if(s.plate===p.id && !st.screws[s.id].alive) hole(s.x+ox, s.y, SR*.65);
    for(const sid of p.screws){ const s = st.screws[sid]; hole(s.x+ox, s.y, SR*.7); screw(s.x+ox, s.y, s.color, (s.x*7)%3); }
  }
  shakes = shakes.filter(s => (s.t += dt) < .35);
  // falling plates
  for(let k=falling.length-1;k>=0;k--){ const f = falling[k]; f.t += dt; f.vy += 900*dt; f.y += f.vy*dt; f.x += f.vx*dt; f.a += f.va*dt; if(f.y > H+150){ falling.splice(k,1); continue; } ctx.globalAlpha = Math.max(0, 1 - f.t*.6); plateShape(f, 0, 0); ctx.globalAlpha = 1; }
  // flights
  for(let k=flights.length-1;k>=0;k--){
    const f = flights[k]; f.t += dt; const p = Math.min(1, f.t/f.dur), e = 1-(1-p)*(1-p);
    const x = f.sx + (f.tx-f.sx)*e, y = f.sy + (f.ty-f.sy)*e - Math.sin(p*Math.PI)*40;
    screw(x, y, f.color, f.t*25, 1 - .1*p);
    if(p >= 1){ flights.splice(k,1); f.done && f.done(); }
  }
  // leaving / entering boxes
  for(let k=leaving.length-1;k>=0;k--){ const l = leaving[k]; if(l.pend <= 0){ if(l.t < 0){ l.t = 0; sndBox(); say([t('g1'),t('g2'),t('g3')][Math.floor(Math.random()*3)]); } l.t += dt*2.2; if(l.t > 1){ leaving.splice(k,1); entering[l.slot] = 0; } } }
  for(let i=0;i<2;i++) if(entering[i] >= 0 && entering[i] < 1) entering[i] = Math.min(1, entering[i] + dt*3);
}
function drawBox(i, c, n, oy){
  const x = BOX_X[i] - BOX_W/2, y = BOX_Y - BOX_H/2 + oy;
  ctx.fillStyle = 'rgba(0,0,0,.25)'; rr(x+2, y+4, BOX_W, BOX_H, 14); ctx.fill();
  const g = ctx.createLinearGradient(0, y, 0, y+BOX_H); g.addColorStop(0, COL[c][0]); g.addColorStop(1, COL[c][1]);
  ctx.fillStyle = g; rr(x, y, BOX_W, BOX_H, 14); ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,.6)'; ctx.lineWidth = 2; ctx.stroke();
  for(let k=0;k<3;k++){ const [hx,hy] = boxHole(i,k); hole(hx, hy+oy, SR*.8); if(k < n) screw(hx, hy+oy, c, 0, .92); }
}
let last = performance.now();
function loop(now){
  const dt = Math.min(.05, (now-last)/1000); last = now;
  if($('#game').classList.contains('show') && st) draw(dt);
  requestAnimationFrame(loop);
}

// ---------- logo ----------
function drawLogo(){
  const c = $('#logoCv'), x = c.getContext('2d');
  const s = c.width/360; x.setTransform(s,0,0,s,0,0);
  const plate = (px,py,w,h,a,wd) => { x.save(); x.translate(px,py); x.rotate(a); x.fillStyle='rgba(0,0,0,.3)'; x.beginPath(); x.roundRect(-w/2+4,-h/2+6,w,h,16); x.fill(); const g=x.createLinearGradient(0,-h/2,0,h/2); g.addColorStop(0,wd[0]); g.addColorStop(1,wd[1]); x.fillStyle=g; x.beginPath(); x.roundRect(-w/2,-h/2,w,h,16); x.fill(); x.strokeStyle='rgba(70,35,10,.6)'; x.lineWidth=3; x.stroke(); x.restore(); };
  const sc = (px,py,ci,r) => { const g=x.createRadialGradient(px-r*.35,py-r*.4,r*.1,px,py,r); g.addColorStop(0,'#fff'); g.addColorStop(.3,COL[ci][0]); g.addColorStop(1,COL[ci][1]); x.beginPath(); x.arc(px,py,r,0,7); x.fillStyle=g; x.fill(); x.strokeStyle='rgba(40,20,0,.6)'; x.lineWidth=r*.22; x.lineCap='round'; x.beginPath(); x.moveTo(px-r*.5,py); x.lineTo(px+r*.5,py); x.moveTo(px,py-r*.5); x.lineTo(px,py+r*.5); x.stroke(); };
  plate(180,95,250,62,-.18,WOOD[0]); plate(170,120,200,58,.22,WOOD[3]);
  sc(90,128,0,20); sc(250,112,1,20); sc(180,70,2,18); sc(108,72,3,18); sc(258,72,4,17);
}

// ---------- init ----------
function applyText(){
  $('#tSub').textContent = t('sub'); $('#bPlay').textContent = '▶ ' + t('play');
  $('#bMap').textContent = t('levels'); $('#bSet').textContent = t('settings');
  $('#lLevel').textContent = t('level'); $('#lLeft').textContent = t('left');
}
applyText(); drawLogo(); goHome(); requestAnimationFrame(loop);
window.__tw = { startLevel, get st(){ return st; }, get state(){ return state; }, doTap };
Ads.init().finally(() => { if(!$('#game').classList.contains('show')) Ads.showBanner(); try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} });
})();
