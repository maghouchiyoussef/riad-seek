// Desert Dash — Gulf endless runner (original characters & art)
(function(){
'use strict';
const N = window.Native;
const $ = (s) => document.querySelector(s);
const cv = $('#cv'), ctx = cv.getContext('2d');

/* ================= i18n ================= */
const T = {
  en:{ title:'Desert Dash', sub:'Gulf Runner', play:'PLAY', shop:'Characters', settings:'Settings', hint:'Swipe to move, jump and slide',
    tut:['Swipe ← → to change lanes','Swipe ↑ to jump','Swipe ↓ to slide'], score:'Score', best:'Best', coins:'Coins', newBest:'New record!',
    over:'Game over', revive:'Continue?', reviveBtn:'Continue (watch ad)', noThanks:'No thanks', again:'Play again', home:'Home', x2:'Double coins (watch ad)', got:'Coins doubled!',
    paused:'Paused', resume:'Resume', choose:'Choose your runner', boy:'Boy', girl:'Girl', lang:'Language', sound:'Sound', on:'On', off:'Off', privacy:'Ad choices', close:'Close',
    owned:'Owned', use:'Use', inUse:'Selected', buy:'Buy', noCoins:'Not enough coins', adNo:'Ad not ready, try again soon',
    outfits:['Classic','Sky','Royal','Emerald','Golden','Night'], magnet:'Magnet', shield:'Shield', dbl:'x2 Coins' },
  fr:{ title:'Desert Dash', sub:'Course du Golfe', play:'JOUER', shop:'Personnages', settings:'Réglages', hint:'Glisse pour bouger, sauter et glisser',
    tut:['Glisse ← → pour changer de voie','Glisse ↑ pour sauter','Glisse ↓ pour glisser'], score:'Score', best:'Record', coins:'Pièces', newBest:'Nouveau record !',
    over:'Partie terminée', revive:'Continuer ?', reviveBtn:'Continuer (voir une pub)', noThanks:'Non merci', again:'Rejouer', home:'Accueil', x2:'Doubler les pièces (pub)', got:'Pièces doublées !',
    paused:'Pause', resume:'Reprendre', choose:'Choisis ton coureur', boy:'Garçon', girl:'Fille', lang:'Langue', sound:'Son', on:'Oui', off:'Non', privacy:'Choix pub', close:'Fermer',
    owned:'Acquis', use:'Choisir', inUse:'Choisi', buy:'Acheter', noCoins:'Pas assez de pièces', adNo:'Pub indisponible, réessaie bientôt',
    outfits:['Classique','Ciel','Royal','Émeraude','Doré','Nuit'], magnet:'Aimant', shield:'Bouclier', dbl:'Pièces x2' },
  ar:{ title:'سباق الصحراء', sub:'عدّاء الخليج', play:'العب', shop:'الشخصيات', settings:'الإعدادات', hint:'اسحب للتحرك والقفز والانزلاق',
    tut:['اسحب ← → لتغيير المسار','اسحب ↑ للقفز','اسحب ↓ للانزلاق'], score:'النتيجة', best:'الأفضل', coins:'العملات', newBest:'رقم قياسي جديد!',
    over:'انتهت الجولة', revive:'تكمل؟', reviveBtn:'أكمل (شاهد إعلانًا)', noThanks:'لا شكرًا', again:'العب مرة أخرى', home:'الرئيسية', x2:'ضاعف العملات (إعلان)', got:'تمت مضاعفة العملات!',
    paused:'إيقاف مؤقت', resume:'متابعة', choose:'اختر شخصيتك', boy:'ولد', girl:'بنت', lang:'اللغة', sound:'الصوت', on:'تشغيل', off:'إيقاف', privacy:'خيارات الإعلانات', close:'إغلاق',
    owned:'مملوك', use:'اختيار', inUse:'مختار', buy:'شراء', noCoins:'العملات غير كافية', adNo:'الإعلان غير جاهز، جرّب بعد قليل',
    outfits:['كلاسيك','سماوي','ملكي','زمردي','ذهبي','ليلي'], magnet:'مغناطيس', shield:'درع', dbl:'عملات ×2' }
};
const LANG_NAME = { en:'English', fr:'Français', ar:'العربية' };
let lang = 'en';
const t = (k) => T[lang][k];

/* ================= save ================= */
const OUTFITS = [
  { price:0,    robe:'#f4f1ea', robe2:'#d9d3c4', head:'#e8e3d8', check:'#d0263a', band:'#1b1b1b', g:{ robe:'#1d1d24', robe2:'#3a3340', head:'#e86aa0', trim:'#e8b84a' } },
  { price:400,  robe:'#bfe3ff', robe2:'#8cc4ef', head:'#ffffff', check:'#2f7fd1', band:'#1b1b1b', g:{ robe:'#2f7fd1', robe2:'#1f5fa6', head:'#bfe3ff', trim:'#ffffff' } },
  { price:1000, robe:'#c9b6ff', robe2:'#9b80e8', head:'#ffffff', check:'#6a3fd1', band:'#2a1450', g:{ robe:'#5b2fb5', robe2:'#40208a', head:'#d8c6ff', trim:'#ffd23f' } },
  { price:2000, robe:'#b7f0cf', robe2:'#7fd3a6', head:'#ffffff', check:'#1e9a52', band:'#0f3d22', g:{ robe:'#178a54', robe2:'#0f6b40', head:'#b7f0cf', trim:'#ffffff' } },
  { price:4000, robe:'#ffe7a3', robe2:'#f2c45a', head:'#fff6d6', check:'#c58f22', band:'#5a3a00', g:{ robe:'#c58f22', robe2:'#a06f12', head:'#ffe7a3', trim:'#fff6d6' } },
  { price:8000, robe:'#2b2f45', robe2:'#1b1e2e', head:'#40e0ff', check:'#ff4fd8', band:'#0b0b14', g:{ robe:'#1b1e2e', robe2:'#2b2f45', head:'#ff4fd8', trim:'#40e0ff' } },
];
function freshSave(){ return { coins:0, best:0, gender:null, outfit:0, owned:[0], lang:null, sound:true, runs:0 }; }
let SV = freshSave();
function load(){
  try{
    const d = JSON.parse(localStorage.getItem('dd_save') || 'null');
    if(d){ SV = Object.assign(freshSave(), d);
      if(!Array.isArray(SV.owned)) SV.owned = [0];
      if(!isFinite(SV.coins) || SV.coins < 0) SV.coins = 0;
      if(!isFinite(SV.best) || SV.best < 0) SV.best = 0;
      if(!(SV.outfit >= 0 && SV.outfit < OUTFITS.length) || SV.owned.indexOf(SV.outfit) < 0) SV.outfit = 0;
      if(SV.gender !== 'boy' && SV.gender !== 'girl') SV.gender = null;
    }
  }catch(e){ SV = freshSave(); }
}
function save(){ try{ localStorage.setItem('dd_save', JSON.stringify(SV)); }catch(e){} }
function detectLang(){
  if(SV.lang && T[SV.lang]) return SV.lang;
  const n = (navigator.language || 'en').toLowerCase();
  return n.startsWith('ar') ? 'ar' : n.startsWith('fr') ? 'fr' : 'en';
}

/* ================= audio / haptics ================= */
let actx = null;
function tone(f, d, type, vol, f2){
  if(!SV.sound) return;
  try{
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    if(actx.state === 'suspended') actx.resume();
    const o = actx.createOscillator(), g = actx.createGain(), now = actx.currentTime;
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, now);
    if(f2) o.frequency.exponentialRampToValueAtTime(f2, now + d);
    g.gain.setValueAtTime(vol || 0.07, now); g.gain.exponentialRampToValueAtTime(0.0001, now + d);
    o.connect(g); g.connect(actx.destination); o.start(now); o.stop(now + d);
  }catch(e){}
}
const sfx = {
  coin(){ tone(1320, .08, 'square', .035); },
  jump(){ tone(300, .18, 'triangle', .07, 700); },
  slide(){ tone(500, .18, 'sawtooth', .03, 180); },
  lane(){ tone(600, .05, 'triangle', .03); },
  hit(){ tone(160, .35, 'sawtooth', .09, 60); },
  power(){ tone(660, .1, 'triangle', .07); setTimeout(() => tone(990, .15, 'triangle', .07), 90); },
  shield(){ tone(240, .2, 'square', .06, 480); },
};
function hap(kind){
  try{
    if(!N || !N.isNative) return;
    if(kind === 'hit') N.Haptics.notification({ type: N.NotificationType.Error });
    else N.Haptics.impact({ style: N.ImpactStyle.Light });
  }catch(e){}
}
function toast(m){ const el = $('#toast'); el.textContent = m; el.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('show'), 2000); }

/* ================= world ================= */
const LANE = 2.4, CAM_Z = 6, CAM_H = 6, ZMAX = 95;
const BIOMES = [
  { sky:['#ffb36b','#ffd9a0','#fff1d6'], ground:'#e8c48a', ground2:'#dcb377', road:'#f0d29b', road2:'#e6c387', edge:'#c99a55', deco:'desert' },
  { sky:['#ff9a6b','#ffc59a','#ffe7cc'], ground:'#c9a06a', ground2:'#bf955e', road:'#d9b88a', road2:'#ccab7d', edge:'#8a5a2b', deco:'souk' },
  { sky:['#5aa9ff','#9fd0ff','#e2f2ff'], ground:'#8e98a8', ground2:'#848e9e', road:'#5b6474', road2:'#545d6c', edge:'#e8e8e8', deco:'city' },
  { sky:['#3f7fd9','#7fb6f0','#cfe8ff'], ground:'#3a8fb8', ground2:'#3584ab', road:'#9a8a78', road2:'#8f7f6d', edge:'#ffd23f', deco:'port' },
];
const BIOME_LEN = 900;
let W = 0, H = 0, DPR = 1, S0 = 50, F = 300, HY = 300, CX = 0;
function resize(){
  DPR = Math.min(window.devicePixelRatio || 1, 2);
  W = window.innerWidth; H = window.innerHeight;
  cv.width = Math.round(W * DPR); cv.height = Math.round(H * DPR);
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  const ww = Math.min(W, H * 0.62);
  S0 = ww * 0.31 / LANE; F = S0 * CAM_Z; CX = W / 2;
  HY = H * 0.8 - CAM_H * S0;
}
window.addEventListener('resize', resize);

let camX = 0;
function proj(x, y, z){
  const zz = z + CAM_Z; if(zz < 0.3) return null;
  const s = F / zz;
  return { x: CX + (x - camX) * s, y: HY + (CAM_H - y) * s, s };
}

/* ================= game state ================= */
const G = {
  state:'menu', // menu | play | dead | pause | count
  dist:0, speed:8, coins:0, objs:[], deco:[], nextRow:60, nextDeco:0,
  p:{ lane:1, x:0, y:0, vy:0, slide:0, run:0, inv:0 },
  magnet:0, shield:0, dbl:0, revived:false, t:0, runStart:0, flash:0, shake:0, tut:0,
};
function laneX(l){ return (l - 1) * LANE; }
function biomeAt(d){ return BIOMES[Math.floor(d / BIOME_LEN) % BIOMES.length]; }
function rnd(a, b){ return a + Math.random() * (b - a); }
function pick(a){ return a[Math.floor(Math.random() * a.length)]; }

function resetRun(){
  G.dist = 0; G.speed = 13; G.coins = 0; G.objs = []; G.nextRow = 55; G.revived = false;
  G.p = { lane:1, x:0, y:0, vy:0, slide:0, run:0, inv:0 };
  G.magnet = G.shield = G.dbl = 0; G.flash = 0; G.shake = 0; G.runStart = Date.now();
  G.tut = SV.runs < 2 ? 9 : 0;
}

/* spawning */
function spawnRow(wz){
  const b = biomeAt(wz);
  const free = Math.floor(Math.random() * 3);
  const lanes = [0, 1, 2];
  let placed = 0;
  for(const l of lanes){
    if(l === free) continue;
    const r = Math.random();
    let type = null;
    if(r < 0.30) type = 'block'; else if(r < 0.55) type = 'low'; else if(r < 0.75) type = 'bar';
    if(!type) continue;
    placed++;
    const o = { kind:'ob', type, lane:l, wz, d:0.5, h:1 };
    if(type === 'block'){
      o.v = b.deco === 'desert' ? 'camel' : b.deco === 'souk' ? 'cart' : b.deco === 'city' ? 'car' : 'box';
      o.d = o.v === 'box' ? 4.5 : o.v === 'cart' ? 2.6 : o.v === 'car' ? 3.2 : 2.2; o.h = o.v === 'box' ? 2.4 : o.v === 'camel' ? 2.3 : 1.7;
      o.c = pick(['#d0263a','#2f7fd1','#1e9a52','#ff8a1c','#6a3fd1']);
    } else if(type === 'low'){ o.d = 0.45; o.h = 0.95; }
    else { o.d = 0.4; o.h = 2.4; }
    G.objs.push(o);
  }
  if(placed === 0 && Math.random() < 0.6){
    const l = (free + 1 + Math.floor(Math.random() * 2)) % 3;
    G.objs.push({ kind:'ob', type:'low', lane:l, wz, d:0.45, h:0.95 });
  }
  // coins in free lane
  if(Math.random() < 0.75){
    const n = 5 + Math.floor(Math.random() * 4);
    for(let i = 0; i < n; i++) G.objs.push({ kind:'coin', lane:free, wz: wz - 2 - i * 1.7, y:0.9 });
  }
  // coin arc over a low barrier
  const low = G.objs.find(o => o.wz === wz && o.type === 'low');
  if(low && Math.random() < 0.5){
    for(let i = -2; i <= 2; i++) G.objs.push({ kind:'coin', lane:low.lane, wz: wz + i * 1.4, y: 0.9 + 1.4 * (1 - (i * i) / 5) });
  }
  // power-up
  if(Math.random() < 0.07){
    G.objs.push({ kind:'pw', lane:free, wz: wz + 7, y:1.1, p: pick(['magnet','shield','dbl']) });
  }
}
function spawnDeco(wz){
  const b = biomeAt(wz);
  for(const side of [-1, 1]){
    if(Math.random() < 0.25) continue;
    let o = { wz, side, t:b.deco };
    if(b.deco === 'desert'){ const r = Math.random(); o.v = r < 0.45 ? 'palm' : r < 0.62 ? 'tent' : r < 0.8 ? 'rest' : 'dune'; }
    else if(b.deco === 'souk') o.v = Math.random() < 0.65 ? 'stall' : 'palm';
    else if(b.deco === 'city') o.v = 'tower';
    else o.v = Math.random() < 0.55 ? 'stack' : 'crane';
    o.h = o.v === 'tower' ? rnd(10, 26) : o.v === 'stack' ? rnd(3, 6) : o.v === 'crane' ? 12 : 0;
    o.w = o.v === 'tower' ? rnd(3, 5) : 3.2;
    o.c = pick(['#d0263a','#2f7fd1','#1e9a52','#ff8a1c','#6a3fd1','#e8b84a']);
    const half = o.v === 'tower' ? o.w / 2 : o.v === 'stack' ? 1.4 : o.v === 'stall' ? 1.7 : o.v === 'dune' ? 3.5 : o.v === 'tent' ? 2.1 : o.v === 'rest' ? 1.7 : o.v === 'palm' ? 0.9 : 1.2;
    o.x = side * (4.4 + half + rnd(0, 3));
    G.deco.push(o);
  }
}

/* ================= drawing ================= */
function quad(a, b, c, d, fill){
  if(!a || !b || !c || !d) return;
  ctx.fillStyle = fill; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.lineTo(c.x, c.y); ctx.lineTo(d.x, d.y); ctx.closePath(); ctx.fill();
}
function shade(hex, k){
  const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
  r = Math.max(0, Math.min(255, r * k)) | 0; g = Math.max(0, Math.min(255, g * k)) | 0; b = Math.max(0, Math.min(255, b * k)) | 0;
  return '#' + ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1);
}
// box: center x, half width hw, base y0, height h, front z, depth d
function box(x, hw, y0, h, z, d, col){
  const z2 = z + d;
  if(z2 + CAM_Z < 0.4) return;
  const zf = Math.max(z, -CAM_Z + 0.4);
  const f1 = proj(x - hw, y0, zf), f2 = proj(x + hw, y0, zf), f3 = proj(x + hw, y0 + h, zf), f4 = proj(x - hw, y0 + h, zf);
  const b1 = proj(x - hw, y0, z2), b2 = proj(x + hw, y0, z2), b3 = proj(x + hw, y0 + h, z2), b4 = proj(x - hw, y0 + h, z2);
  if(!f1 || !b1) return;
  // side faces
  if(x - hw > camX) quad(f1, b1, b4, f4, shade(col, .72));
  if(x + hw < camX) quad(f2, b2, b3, f3, shade(col, .72));
  // top
  if(y0 + h < CAM_H) quad(f4, f3, b3, b4, shade(col, 1.18));
  quad(f1, f2, f3, f4, col);
  return { f1, f2, f3, f4 };
}
function emoji(ch, x, y, z, size){
  const p = proj(x, y, z); if(!p) return;
  const px = size * p.s;
  if(px < 4) return;
  ctx.font = px + 'px "Noto Color Emoji","Apple Color Emoji","Segoe UI Emoji",sans-serif';
  ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
  ctx.fillText(ch, p.x, p.y + px * 0.12);
}
function fogAlpha(z){ return Math.max(0, Math.min(1, (ZMAX - z) / 18)); }

function drawSky(b){
  const g = ctx.createLinearGradient(0, 0, 0, HY);
  g.addColorStop(0, b.sky[0]); g.addColorStop(.6, b.sky[1]); g.addColorStop(1, b.sky[2]);
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, HY + 2);
  // sun
  ctx.fillStyle = 'rgba(255,250,220,.85)'; ctx.beginPath(); ctx.arc(W * 0.78, HY * 0.45, Math.max(18, W * 0.07), 0, 7); ctx.fill();
  // far skyline silhouette
  ctx.fillStyle = 'rgba(120,80,60,.18)';
  const off = (G.dist * 0.3) % 120;
  for(let i = -1; i < W / 60 + 2; i++){
    const xx = i * 60 - off * 0.5, hh = 14 + ((i * 37) % 5) * 7;
    ctx.fillRect(xx, HY - hh, 34, hh);
    if(i % 3 === 0){ ctx.beginPath(); ctx.arc(xx + 17, HY - hh, 12, Math.PI, 0); ctx.fill(); ctx.fillRect(xx + 15, HY - hh - 26, 4, 14); }
  }
}
function drawGround(b){
  ctx.fillStyle = b.ground; ctx.fillRect(0, HY, W, H - HY);
  const step = 3, off = G.dist % (step * 2);
  const half = LANE * 1.5 + 0.3;
  for(let z = ZMAX; z > -CAM_Z + 0.5; z -= step){
    const za = z - off, zb = za + step;
    if(zb + CAM_Z < 0.4) continue;
    const zA = Math.max(za, -CAM_Z + 0.4);
    const idx = Math.floor((za + G.dist) / step);
    // side ground stripes
    quad(proj(-60, 0, zA), proj(60, 0, zA), proj(60, 0, zb), proj(-60, 0, zb), idx % 2 ? b.ground : b.ground2);
    quad(proj(-half, 0, zA), proj(half, 0, zA), proj(half, 0, zb), proj(-half, 0, zb), idx % 2 ? b.road : b.road2);
  }
  // road edges + lane lines
  ctx.lineCap = 'round';
  for(const ex of [-half, half]){
    const a = proj(ex, 0, -CAM_Z + 0.5), c = proj(ex, 0, ZMAX);
    ctx.strokeStyle = b.edge; ctx.lineWidth = Math.max(2, S0 * 0.12);
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(c.x, c.y); ctx.stroke();
  }
  ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = Math.max(1, S0 * 0.05);
  ctx.setLineDash([S0 * 0.6, S0 * 0.6]); ctx.lineDashOffset = -(G.dist * S0 * 0.2);
  for(const lx of [-LANE / 2, LANE / 2]){
    const a = proj(lx, 0, -CAM_Z + 0.5), c = proj(lx, 0, ZMAX);
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(c.x, c.y); ctx.stroke();
  }
  ctx.setLineDash([]);
  // horizon haze
  const g = ctx.createLinearGradient(0, HY, 0, HY + 40);
  g.addColorStop(0, b.sky[2]); g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g; ctx.fillRect(0, HY, W, 40);
}

function drawDeco(o, z){
  ctx.globalAlpha = fogAlpha(z);
  if(o.v === 'palm'){ spr(SPR.palm, o.x, z, 3, 5, o.side < 0); }
  else if(o.v === 'tent'){ spr(SPR.tent, o.x, z, 4.2, 2.7); }
  else if(o.v === 'rest'){ spr(SPR.camelRest, o.x, z, 3.4, 1.8, o.side > 0); }
  else if(o.v === 'dune'){
    const p = proj(o.x, 0, z); if(p){ ctx.fillStyle = '#d9aa66'; ctx.beginPath(); ctx.ellipse(p.x, p.y, 3.5 * p.s, 1.6 * p.s, 0, Math.PI, 0); ctx.fill(); }
  }
  else if(o.v === 'stall'){
    box(o.x, 1.5, 0, 2.2, z, 2.5, '#b07a45');
    const s = o.side;
    const a = proj(o.x - 1.7, 2.2, z), bb = proj(o.x + 1.7, 2.2, z), c = proj(o.x + 1.7, 2.9, z + 0.4), d = proj(o.x - 1.7, 2.9, z + 0.4);
    if(a && bb && c && d){
      const n = 6; for(let i = 0; i < n; i++){
        const L = (k, P, Q) => ({ x: P.x + (Q.x - P.x) * k, y: P.y + (Q.y - P.y) * k });
        quad(L(i / n, a, bb), L((i + 1) / n, a, bb), L((i + 1) / n, d, c), L(i / n, d, c), i % 2 ? '#fff4e0' : o.c);
      }
    }
    void s;
  }
  else if(o.v === 'tower'){
    const r = box(o.x, o.w / 2, 0, o.h, z, o.w, o.c === '#e8b84a' ? '#d8c49a' : shade(o.c, .85));
    if(r && r.f1){
      ctx.fillStyle = 'rgba(255,240,180,.55)';
      const cols = 3, rows = Math.floor(o.h / 2);
      const wx = (r.f2.x - r.f1.x), wy = (r.f1.y - r.f4.y);
      if(wx > 12) for(let i = 0; i < cols; i++) for(let j = 0; j < rows; j++)
        ctx.fillRect(r.f4.x + wx * (0.15 + i * 0.28), r.f4.y + wy * (0.06 + j / rows * 0.9), wx * 0.14, wy / rows * 0.4);
    }
  }
  else if(o.v === 'stack'){
    const hh = Math.round(o.h / 1.3);
    for(let i = 0; i < hh; i++) box(o.x, 1.4, i * 1.3, 1.25, z, 4, ['#d0263a','#2f7fd1','#1e9a52','#ff8a1c'][((i + Math.round(o.x)) % 4 + 4) % 4]);
  }
  else if(o.v === 'crane'){
    box(o.x, 0.3, 0, o.h, z, 0.6, '#ffb000');
    box(o.x - o.side * 2.5, 3, o.h - 0.6, 0.6, z, 0.6, '#ffb000');
  }
  ctx.globalAlpha = 1;
}

function drawCoin(o, z){
  const p = proj(laneX(o.lane), o.y, z); if(!p) return;
  const r = 0.42 * p.s; if(r < 1) return;
  const sq = Math.abs(Math.cos(G.t * 5 + o.wz * 0.7));
  ctx.globalAlpha = fogAlpha(z);
  ctx.fillStyle = '#b8780c'; ctx.beginPath(); ctx.ellipse(p.x, p.y, Math.max(r * 0.25, r * sq), r, 0, 0, 7); ctx.fill();
  ctx.fillStyle = '#ffd23f'; ctx.beginPath(); ctx.ellipse(p.x, p.y, Math.max(r * 0.18, r * sq * 0.8), r * 0.8, 0, 0, 7); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,.7)'; ctx.beginPath(); ctx.ellipse(p.x - r * 0.2 * sq, p.y - r * 0.3, r * 0.15 * sq + 0.5, r * 0.2, 0, 0, 7); ctx.fill();
  ctx.globalAlpha = 1;
}
function drawPw(o, z){
  const p = proj(laneX(o.lane), o.y + Math.sin(G.t * 4) * 0.15, z); if(!p) return;
  const r = 0.75 * p.s; if(r < 2) return;
  ctx.globalAlpha = fogAlpha(z);
  const g = ctx.createRadialGradient(p.x, p.y, r * 0.2, p.x, p.y, r * 1.3);
  g.addColorStop(0, 'rgba(255,255,255,.95)'); g.addColorStop(1, 'rgba(176,114,255,0)');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x, p.y, r * 1.3, 0, 7); ctx.fill();
  ctx.font = (r * 1.3) + 'px "Noto Color Emoji",sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(o.p === 'magnet' ? '🧲' : o.p === 'shield' ? '🛡️' : '💰', p.x, p.y + r * 0.05);
  ctx.globalAlpha = 1;
}
function drawOb(o, z){
  const x = laneX(o.lane);
  ctx.globalAlpha = fogAlpha(z);
  // shadow
  const s1 = proj(x - 1.05, 0, z - 0.1), s2 = proj(x + 1.05, 0, z - 0.1), s3 = proj(x + 1.05, 0, z + o.d + 0.2), s4 = proj(x - 1.05, 0, z + o.d + 0.2);
  quad(s1, s2, s3, s4, 'rgba(0,0,0,.15)');
  if(o.type === 'low'){
    const r = box(x, 1.05, 0, o.h, z, o.d, '#ffffff');
    if(r && r.f1){
      ctx.save(); ctx.beginPath(); ctx.moveTo(r.f1.x, r.f1.y); ctx.lineTo(r.f2.x, r.f2.y); ctx.lineTo(r.f3.x, r.f3.y); ctx.lineTo(r.f4.x, r.f4.y); ctx.closePath(); ctx.clip();
      ctx.fillStyle = '#e63946'; const w = r.f2.x - r.f1.x, hh = r.f1.y - r.f4.y;
      for(let i = -2; i < 8; i++){ ctx.beginPath(); ctx.moveTo(r.f4.x + i * w / 6, r.f1.y); ctx.lineTo(r.f4.x + (i + 1) * w / 6, r.f1.y); ctx.lineTo(r.f4.x + (i + 2) * w / 6, r.f4.y); ctx.lineTo(r.f4.x + (i + 1) * w / 6, r.f4.y); ctx.fill(); }
      void hh; ctx.restore();
    }
  } else if(o.type === 'bar'){
    box(x - 1.05, 0.12, 0, 2.4, z, 0.3, '#5a5f6a');
    box(x + 1.05, 0.12, 0, 2.4, z, 0.3, '#5a5f6a');
    const r = box(x, 1.15, 1.35, 0.85, z, 0.35, '#ffd23f');
    if(r && r.f1){
      ctx.fillStyle = '#1b1b1b'; const w = r.f2.x - r.f1.x;
      for(let i = 0; i < 5; i += 2) ctx.fillRect(r.f4.x + w * i / 5, r.f4.y, w / 5, r.f1.y - r.f4.y);
    }
  } else {
    if(o.v === 'camel') spr(SPR.camel, x, z, 2.2, 2.6);
    else if(o.v === 'cart') spr(SPR.cart, x, z, 2.3, 2.4);
    else if(o.v === 'car') spr(SPR.car(o.c), x, z, 2.2, 1.8);
    else {
      const r = box(x, 1.1, 0, o.h, z, o.d, o.c);
      if(r && r.f1){
        ctx.strokeStyle = 'rgba(0,0,0,.25)'; ctx.lineWidth = Math.max(1, r.f1.s * 0.06);
        const w = r.f2.x - r.f1.x;
        for(let i = 1; i < 6; i++){ ctx.beginPath(); ctx.moveTo(r.f1.x + w * i / 6, r.f1.y); ctx.lineTo(r.f1.x + w * i / 6, r.f4.y); ctx.stroke(); }
      }
    }
  }
  ctx.globalAlpha = 1;
}

/* runner (seen from behind) */
function drawRunner(c, cx, cy, sc, ph, mode, gender, outfit){
  SPR.drawRunner(c, cx, cy, sc, ph, mode, gender, OUTFITS[outfit] || OUTFITS[0]);
}
function spr(img, x, z, wU, hU, flip){
  const p = proj(x, 0, z); if(!p) return;
  const w = wU * p.s, h = hU * p.s; if(w < 2) return;
  if(flip){ ctx.save(); ctx.translate(p.x, 0); ctx.scale(-1, 1); ctx.drawImage(img, -w / 2, p.y - h, w, h); ctx.restore(); }
  else ctx.drawImage(img, p.x - w / 2, p.y - h, w, h);
}
/* sky birds */
const birds = [];
let nextBird = 3;
function updBirds(dt, b){
  nextBird -= dt;
  if(nextBird <= 0 && (b.deco === 'desert' || b.deco === 'port')){
    nextBird = rnd(5, 11);
    const dir = Math.random() < 0.5 ? 1 : -1, n = b.deco === 'port' ? 1 + Math.floor(Math.random() * 3) : 1;
    for(let i = 0; i < n; i++) birds.push({ kind: b.deco === 'desert' ? 'falcon' : 'gull', x: dir > 0 ? -60 - i * 40 : W + 60 + i * 40, y: HY * rnd(0.2, 0.7) + i * 14, v: dir * rnd(50, 90), s: rnd(0.35, 0.6), ph: Math.random() * 6 });
  }
  for(let i = birds.length - 1; i >= 0; i--){ const q = birds[i]; q.x += q.v * dt; q.ph += dt * 7; q.y += Math.sin(q.ph * 0.3) * 0.2; if(q.x < -120 || q.x > W + 120) birds.splice(i, 1); }
}
function drawBirds(){
  for(const q of birds){
    const fr = SPR.birds[q.kind][Math.sin(q.ph) > 0 ? 0 : 1], w = 120 * q.s, h = 70 * q.s;
    ctx.save(); ctx.translate(q.x, q.y); if(q.v < 0) ctx.scale(-1, 1); ctx.drawImage(fr, -w / 2, -h / 2, w, h); ctx.restore();
  }
}

/* particles */
const parts = [];
function burst(x, y, col, n){ if(parts.length > 40) return; for(let i = 0; i < n; i++) parts.push({ x, y, vx: rnd(-90, 90), vy: rnd(-180, -60), l: rnd(.2, .4), c: col }); }

/* ================= loop ================= */
let last = performance.now();
function frame(now){
  let dt = (now - last) / 1000; last = now;
  if(dt > 0.05) dt = 0.05;
  update(dt); render(dt);
  requestAnimationFrame(frame);
}

function update(dt){
  G.t += dt;
  updBirds(dt, biomeAt(G.dist));
  const p = G.p;
  if(G.state === 'menu'){
    G.dist += 7 * dt; p.run += dt * 9; camX += (0 - camX) * 0.1;
    spawnDecoUpTo(); cleanup();
    return;
  }
  if(G.state !== 'play') return;
  // speed
  G.speed = Math.min(34, 13 + G.dist * 0.0045);
  const dz = G.speed * dt;
  G.dist += dz;
  p.run += dt * (6 + G.speed * 0.35);
  // lane lerp
  const tx = laneX(p.lane);
  p.x += (tx - p.x) * Math.min(1, dt * 16);
  camX += (p.x * 0.55 - camX) * Math.min(1, dt * 8);
  // jump physics
  if(p.y > 0 || p.vy > 0){ p.vy -= 34 * dt; p.y += p.vy * dt; if(p.y <= 0){ p.y = 0; p.vy = 0; if(p.slideQueued){ p.slide = 0.7; p.slideQueued = false; } } }
  if(p.slide > 0) p.slide -= dt;
  if(p.inv > 0) p.inv -= dt;
  if(G.magnet > 0) G.magnet -= dt;
  if(G.dbl > 0) G.dbl -= dt;
  if(G.flash > 0) G.flash -= dt;
  if(G.shake > 0) G.shake -= dt;
  if(G.tut > 0) G.tut -= dt;
  // spawn
  while(G.nextRow - G.dist < ZMAX){
    spawnRow(G.nextRow);
    G.nextRow += Math.max(15, G.speed * 1.05) + rnd(0, 9);
  }
  spawnDecoUpTo();
  // collisions
  const ph = p.slide > 0 ? 0.9 : 1.85;
  for(const o of G.objs){
    if(o.dead) continue;
    const z = o.wz - G.dist;
    if(o.kind === 'coin'){
      if(G.magnet > 0 && z < 14 && z > -1){ o.mag = true; }
      if(o.mag){
        const cx = laneX(o.lane), k = Math.min(1, dt * 10);
        o.mx = (o.mx === undefined ? cx : o.mx); o.mx += (p.x - o.mx) * k; o.y += (p.y + 1 - o.y) * k; o.wz += (G.dist - o.wz) * k;
        if(Math.abs(o.wz - G.dist) < 1) collect(o);
        continue;
      }
      if(z > -0.8 && z < 0.8 && Math.abs(laneX(o.lane) - p.x) < 1.1 && Math.abs((p.y + 0.9) - o.y) < 1.2) collect(o);
    } else if(o.kind === 'pw'){
      if(z > -0.8 && z < 0.8 && Math.abs(laneX(o.lane) - p.x) < 1.1){ o.dead = true; power(o.p); }
    } else {
      if(z > 0.5 || z + o.d < -0.5) continue;
      if(Math.abs(laneX(o.lane) - p.x) > 1.05) continue;
      let hit = false;
      if(o.type === 'low') hit = p.y < o.h - 0.05;
      else if(o.type === 'bar') hit = p.y + ph > 1.35 && p.y < 2.2;
      else hit = p.y < o.h - 0.1;
      if(hit && p.inv <= 0) crash(o);
    }
  }
  cleanup();
  // hud
  $('#sScore').textContent = Math.floor(G.dist) + ' m';
  $('#sCoins').textContent = '🪙 ' + G.coins;
  drawPwHud();
  const tut = $('#tut');
  if(G.tut > 0){ const i = G.tut > 6 ? 0 : G.tut > 3 ? 1 : 2; tut.textContent = t('tut')[i]; tut.style.display = 'block'; }
  else tut.style.display = 'none';
}
function spawnDecoUpTo(){
  while(G.nextDeco - G.dist < ZMAX){ spawnDeco(G.nextDeco); G.nextDeco += rnd(5, 9); }
}
function cleanup(){
  if(G.objs.length > 0 && G.objs.some(o => o.dead || o.wz - G.dist < -CAM_Z - 6)) G.objs = G.objs.filter(o => !o.dead && o.wz + (o.d || 0) - G.dist > -CAM_Z - 1);
  if(G.deco.length > 0 && G.deco[0].wz - G.dist < -CAM_Z - 6) G.deco = G.deco.filter(o => o.wz - G.dist > -CAM_Z - 6);
}
function collect(o){
  o.dead = true; G.coins += G.dbl > 0 ? 2 : 1; sfx.coin();
  const pp = proj(G.p.x, G.p.y + 1, 0); if(pp) burst(pp.x, pp.y - 30, '#fff3a0', 2);
}
function power(k){
  sfx.power(); hap('light');
  if(k === 'magnet') G.magnet = 10; else if(k === 'shield') G.shield = 1; else G.dbl = 12;
  toast(k === 'magnet' ? '🧲 ' + t('magnet') : k === 'shield' ? '🛡️ ' + t('shield') : '💰 ' + t('dbl'));
}
function drawPwHud(){
  const box = $('#pw'); let h = '';
  if(G.magnet > 0) h += '<div class="pwi">🧲<i><b style="width:' + (G.magnet / 10 * 100) + '%"></b></i></div>';
  if(G.dbl > 0) h += '<div class="pwi">💰<i><b style="width:' + (G.dbl / 12 * 100) + '%"></b></i></div>';
  if(G.shield > 0) h += '<div class="pwi">🛡️</div>';
  if(box.innerHTML !== h) box.innerHTML = h;
}
function crash(o){
  if(G.shield > 0){
    G.shield = 0; o.dead = true; G.p.inv = 1; G.flash = 0.3; sfx.shield(); hap('hit');
    const pp = proj(laneX(o.lane), 1, Math.max(0.5, o.wz - G.dist)); if(pp) burst(pp.x, pp.y, '#9fd0ff', 14);
    return;
  }
  sfx.hit(); hap('hit'); G.shake = 0.35; G.flash = 0.25;
  G.state = 'dead';
  setTimeout(gameOver, 650);
}

function render(dt){
  const b = biomeAt(G.dist);
  ctx.save();
  if(G.shake > 0) ctx.translate(rnd(-6, 6), rnd(-6, 6));
  drawSky(b);
  drawBirds();
  drawGround(b);
  // collect drawables, far to near
  const list = [];
  for(const o of G.deco){ const z = o.wz - G.dist; if(z < ZMAX && z > -CAM_Z + 0.5) list.push([z + (o.d || 0), 0, o, z]); }
  for(const o of G.objs){ if(o.dead) continue; const z = o.wz - G.dist; if(z < ZMAX && z > -CAM_Z + 0.5) list.push([o.kind === 'ob' ? z + o.d * 0.5 : z, 1, o, z]); }
  list.push([0.05, 2, null, 0]);
  list.sort((a, c) => c[0] - a[0]);
  for(const [, kind, o, z] of list){
    if(kind === 0) drawDeco(o, z);
    else if(kind === 2) drawPlayer();
    else if(o.kind === 'coin'){
      if(o.mag){ const pz = o.wz - G.dist; const pr = proj(o.mx, o.y, pz); if(pr){ ctx.fillStyle = '#ffd23f'; ctx.beginPath(); ctx.arc(pr.x, pr.y, 0.35 * pr.s, 0, 7); ctx.fill(); } }
      else drawCoin(o, z);
    }
    else if(o.kind === 'pw') drawPw(o, z);
    else drawOb(o, z);
  }
  // particles
  for(let i = parts.length - 1; i >= 0; i--){
    const q = parts[i]; q.l -= dt; if(q.l <= 0){ parts.splice(i, 1); continue; }
    q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 500 * dt;
    ctx.globalAlpha = Math.min(1, q.l * 3); ctx.fillStyle = q.c; ctx.beginPath(); ctx.arc(q.x, q.y, 2.5, 0, 7); ctx.fill();
  }
  ctx.globalAlpha = 1;
  ctx.restore();
  if(G.flash > 0){ ctx.fillStyle = 'rgba(255,255,255,' + (G.flash * 2) + ')'; ctx.fillRect(0, 0, W, H); }
}
function drawPlayer(){
  const p = G.p;
  const pr = proj(p.x, 0, 0); if(!pr) return;
  const sc = pr.s;
  const feetY = pr.y - p.y * sc;
  // ground shadow at y=0
  ctx.fillStyle = 'rgba(0,0,0,.18)'; ctx.beginPath(); ctx.ellipse(pr.x, pr.y, 0.6 * sc * Math.max(.4, 1 - p.y * 0.3), 0.16 * sc, 0, 0, 7); ctx.fill();
  if(p.inv > 0 && Math.floor(p.inv * 12) % 2 === 0) ctx.globalAlpha = 0.45;
  const mode = G.state === 'menu' ? 'run' : p.slide > 0 ? 'slide' : p.y > 0.05 ? 'jump' : 'run';
  drawRunner(ctx, pr.x, feetY, sc, p.run, mode, SV.gender || 'boy', SV.outfit);
  ctx.globalAlpha = 1;
  if(G.shield > 0){
    ctx.strokeStyle = 'rgba(120,200,255,.8)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(pr.x, feetY - sc, sc * 0.75, sc * 1.15, 0, 0, 7); ctx.stroke();
  }
  if(G.magnet > 0){
    ctx.strokeStyle = 'rgba(255,80,80,' + (0.3 + 0.2 * Math.sin(G.t * 10)) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(pr.x, feetY - sc, sc * 1.4, 0, 7); ctx.stroke();
  }
}

/* ================= input ================= */
let sx = 0, sy = 0, st = 0, swiped = false, pid = null;
cv.addEventListener('pointerdown', (e) => { pid = e.pointerId; sx = e.clientX; sy = e.clientY; st = performance.now(); swiped = false; });
cv.addEventListener('pointermove', (e) => {
  if(e.pointerId !== pid || swiped) return;
  const dx = e.clientX - sx, dy = e.clientY - sy, th = Math.max(24, W * 0.06);
  if(Math.abs(dx) > th || Math.abs(dy) > th){ swiped = true; swipe(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'r' : 'l') : (dy > 0 ? 'd' : 'u')); }
});
cv.addEventListener('pointerup', (e) => { if(e.pointerId === pid) pid = null; });
cv.addEventListener('pointercancel', () => { pid = null; });
window.addEventListener('keydown', (e) => {
  const k = { ArrowLeft:'l', ArrowRight:'r', ArrowUp:'u', ArrowDown:'d', a:'l', d:'r', w:'u', s:'d', ' ':'u' }[e.key];
  if(k){ e.preventDefault(); swipe(k); }
});
function swipe(dir){
  if(G.state !== 'play') return;
  const p = G.p;
  if(dir === 'l' && p.lane > 0){ p.lane--; sfx.lane(); }
  else if(dir === 'r' && p.lane < 2){ p.lane++; sfx.lane(); }
  else if((dir === 'l' && p.lane === 0) || (dir === 'r' && p.lane === 2)){ G.shake = 0.1; }
  else if(dir === 'u'){ if(p.y <= 0.01){ p.vy = 12; p.y = 0.001; p.slide = 0; sfx.jump(); } }
  else if(dir === 'd'){ if(p.y > 0.05){ p.vy = -26; p.slideQueued = true; } else { p.slide = 0.7; sfx.slide(); } }
}

/* ================= screens ================= */
const modal = $('#modal');
let modalOpen = false, modalOnClose = null;
function showModal(html, bind, onClose){
  modal.innerHTML = '<div class="box">' + html + '</div>';
  modal.classList.add('show'); modalOpen = true; modalOnClose = onClose || null;
  if(bind) bind(modal);
}
function closeModal(){ modal.classList.remove('show'); modal.innerHTML = ''; modalOpen = false; const f = modalOnClose; modalOnClose = null; if(f) f(); }

function applyLang(){
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  $('#tTitle').textContent = t('title'); $('#tSub').textContent = t('sub');
  $('#bPlay').textContent = '▶ ' + t('play');
  $('#bShop').textContent = '👕 ' + t('shop'); $('#bSet').textContent = '⚙️ ' + t('settings');
  $('#tHint').textContent = t('hint');
  document.title = t('title');
  updHome();
}
function updHome(){ $('#hBest').textContent = '🏆 ' + SV.best; $('#hCoins').textContent = '🪙 ' + SV.coins; }

function goHome(){
  G.state = 'menu'; G.objs = []; G.p = { lane:1, x:0, y:0, vy:0, slide:0, run:0, inv:0 };
  $('#hud').classList.remove('show'); $('#pw').innerHTML = ''; $('#tut').style.display = 'none';
  $('#home').classList.add('show'); updHome();
  Ads.showBanner();
}
function startRun(){
  if(!SV.gender){ chooseGender(startRun); return; }
  resetRun();
  $('#home').classList.remove('show'); $('#hud').classList.add('show');
  Ads.hideBanner();
  G.state = 'play';
  try{ actx = actx || new (window.AudioContext || window.webkitAudioContext)(); if(actx.state === 'suspended') actx.resume(); }catch(e){}
}
function pauseGame(){
  if(G.state !== 'play') return;
  G.state = 'pause';
  showModal('<h2>' + t('paused') + '</h2><button class="btn grn" id="r">▶ ' + t('resume') + '</button><button class="btn alt" id="h">🏠 ' + t('home') + '</button>',
    (m) => { m.querySelector('#r').onclick = () => { closeModal(); countdown(); }; m.querySelector('#h').onclick = () => { closeModal(); endRun(false); }; });
}
function countdown(cb){
  G.state = 'count';
  const el = $('#count'); let n = 3; el.style.display = 'flex'; el.textContent = n;
  const iv = setInterval(() => {
    n--; if(n > 0){ el.textContent = n; tone(600, .08, 'triangle', .05); return; }
    clearInterval(iv); el.style.display = 'none'; G.state = 'play'; if(cb) cb();
  }, 600);
}
async function reward(){
  if(!Ads.isNative) return true; // browser preview only
  if(!Ads.rewardedAvailable()){ toast(t('adNo')); return false; }
  return !!(await Ads.showRewarded());
}

function gameOver(){
  if(G.state !== 'dead') return;
  if(!G.revived && G.dist > 60){
    // revive offer with 5s countdown
    let left = 5, stopped = false;
    showModal('<h2>' + t('revive') + '</h2><div class="ring" id="rg"><span id="rn">5</span></div>' +
      '<button class="btn ad" id="rv">🎬 ' + t('reviveBtn') + '</button><button class="btn alt sm" id="nt">' + t('noThanks') + '</button>',
      (m) => {
        const iv = setInterval(() => {
          if(stopped) return clearInterval(iv);
          left -= 0.1; const rg = m.querySelector('#rg'); if(!rg){ clearInterval(iv); return; }
          rg.style.setProperty('--p', Math.max(0, left / 5 * 100) + '%'); m.querySelector('#rn').textContent = Math.ceil(Math.max(0, left));
          if(left <= 0){ clearInterval(iv); stopped = true; closeModal(); endRun(true); }
        }, 100);
        m.querySelector('#nt').onclick = () => { stopped = true; clearInterval(iv); closeModal(); endRun(true); };
        m.querySelector('#rv').onclick = async () => {
          stopped = true; clearInterval(iv);
          const ok = await reward();
          closeModal();
          if(ok) revive(); else endRun(true);
        };
      });
    return;
  }
  endRun(true);
}
function revive(){
  G.revived = true;
  G.objs = G.objs.filter(o => o.kind !== 'ob' || o.wz - G.dist > 35);
  G.p.inv = 2.5; G.p.y = 0; G.p.vy = 0; G.p.slide = 0;
  countdown();
}
function endRun(showResult){
  const dist = Math.floor(G.dist), coins = G.coins;
  const isBest = dist > SV.best;
  SV.coins += coins; if(isBest) SV.best = dist; SV.runs++; save();
  G.state = 'over';
  $('#hud').classList.remove('show'); $('#pw').innerHTML = ''; $('#tut').style.display = 'none';
  if(!showResult){ goHome(); maybeInter(); return; }
  Ads.showBanner();
  let doubled = false;
  showModal('<h2>' + t('over') + '</h2>' + (isBest ? '<p style="color:#ffd23f;font-weight:700">🏆 ' + t('newBest') + '</p>' : '') +
    '<div class="big">' + dist + ' m</div>' +
    '<div class="stats"><div><small>' + t('best') + '</small><b>' + SV.best + ' m</b></div><div><small>' + t('coins') + '</small><b id="cc">🪙 ' + coins + '</b></div></div>' +
    (coins > 0 ? '<button class="btn ad sm" id="x2">🎬 ' + t('x2') + '</button>' : '') +
    '<button class="btn grn" id="ag">▶ ' + t('again') + '</button><button class="btn alt sm" id="hm">🏠 ' + t('home') + '</button>',
    (m) => {
      const x2 = m.querySelector('#x2');
      if(x2) x2.onclick = async () => {
        if(doubled) return;
        const ok = await reward(); if(!ok) return;
        doubled = true; SV.coins += coins; save(); x2.remove();
        m.querySelector('#cc').textContent = '🪙 ' + (coins * 2); sfx.power(); toast(t('got'));
      };
      m.querySelector('#ag').onclick = async () => { closeModal(); await maybeInter(); startRun(); };
      m.querySelector('#hm').onclick = () => { closeModal(); goHome(); maybeInter(); };
    });
}
const sessionStart = Date.now();
async function maybeInter(){ if(Date.now() - sessionStart > 120000 && SV.runs >= 3){ try{ return await Ads.maybeInterstitial(); }catch(e){} } return false; }

function chooseGender(after){
  const html = '<h2>' + t('choose') + '</h2><div class="gsel"><button id="gb"><canvas width="110" height="150"></canvas>' + t('boy') + '</button><button id="gg"><canvas width="110" height="150"></canvas>' + t('girl') + '</button></div>';
  showModal(html, (m) => {
    const cvs = m.querySelectorAll('canvas');
    preview(cvs[0], 'boy', 0); preview(cvs[1], 'girl', 0);
    m.querySelector('#gb').onclick = () => { SV.gender = 'boy'; save(); closeModal(); if(after) after(); };
    m.querySelector('#gg').onclick = () => { SV.gender = 'girl'; save(); closeModal(); if(after) after(); };
  });
}
function preview(c, gender, outfit){
  const x = c.getContext('2d'), d = Math.min(window.devicePixelRatio || 1, 2);
  const w = c.width, h = c.height; c.width = w * d; c.height = h * d; c.style.width = w + 'px'; c.style.height = h + 'px';
  x.scale(d, d);
  drawRunner(x, w / 2, h - 10, h * 0.42, 0.6, 'idle', gender, outfit);
}
function showShop(){
  const g = SV.gender || 'boy';
  let html = '<h2>👕 ' + t('shop') + '</h2><div class="chips"><div class="chip">🪙 ' + SV.coins + '</div></div>' +
    '<div class="gsel"><button id="gb" class="' + (g === 'boy' ? 'on' : '') + '">' + t('boy') + '</button><button id="gg" class="' + (g === 'girl' ? 'on' : '') + '">' + t('girl') + '</button></div><div class="grid">';
  OUTFITS.forEach((o, i) => {
    const own = SV.owned.indexOf(i) >= 0, on = SV.outfit === i;
    html += '<button class="it' + (on ? ' on' : '') + (own ? '' : ' lock') + '" data-i="' + i + '"><canvas width="80" height="96"></canvas>' + t('outfits')[i] +
      '<small>' + (on ? '✔ ' + t('inUse') : own ? t('use') : '🪙 ' + o.price) + '</small></button>';
  });
  html += '</div><button class="btn grn" id="cl">' + t('close') + '</button>';
  showModal(html, (m) => {
    m.querySelectorAll('.it').forEach(b => {
      const i = +b.dataset.i; preview(b.querySelector('canvas'), g, i);
      b.onclick = () => {
        if(SV.owned.indexOf(i) >= 0){ SV.outfit = i; save(); showShop(); return; }
        if(SV.coins < OUTFITS[i].price){ toast(t('noCoins')); tone(150, .15, 'square', .05); return; }
        SV.coins -= OUTFITS[i].price; SV.owned.push(i); SV.outfit = i; save(); sfx.power(); showShop(); updHome();
      };
    });
    m.querySelector('#gb').onclick = () => { SV.gender = 'boy'; save(); showShop(); };
    m.querySelector('#gg').onclick = () => { SV.gender = 'girl'; save(); showShop(); };
    m.querySelector('#cl').onclick = () => { closeModal(); updHome(); };
  });
}
function showSettings(){
  showModal('<h2>⚙️ ' + t('settings') + '</h2><p>' + t('lang') + '</p><div class="row" id="lr"></div><p>' + t('sound') + '</p>' +
    '<button class="btn alt sm" id="snd">' + (SV.sound ? '🔊 ' + t('on') : '🔇 ' + t('off')) + '</button>' +
    (Ads.privacyRequired ? '<button class="btn alt sm" id="prv">🔒 ' + t('privacy') + '</button>' : '') +
    '<button class="btn grn" id="cl">' + t('close') + '</button>', (m) => {
      ['ar','en','fr'].forEach(L => {
        const b = document.createElement('button'); b.className = 'btn sm ' + (L === lang ? '' : 'alt'); b.textContent = LANG_NAME[L];
        b.onclick = () => { lang = L; SV.lang = L; save(); applyLang(); showSettings(); };
        m.querySelector('#lr').appendChild(b);
      });
      m.querySelector('#snd').onclick = () => { SV.sound = !SV.sound; save(); showSettings(); };
      const pv = m.querySelector('#prv'); if(pv) pv.onclick = () => Ads.showPrivacyOptions();
      m.querySelector('#cl').onclick = closeModal;
    });
}

$('#bPlay').onclick = startRun;
$('#bShop').onclick = showShop;
$('#bSet').onclick = showSettings;
$('#pause').onclick = pauseGame;

/* android / lifecycle */
try{
  N.App.addListener('backButton', () => {
    if(G.state === 'play'){ pauseGame(); return; }
    if(modalOpen){
      if(G.state === 'pause'){ closeModal(); countdown(); return; }
      if(G.state === 'over' || G.state === 'dead') return; // must choose a button
      closeModal(); return;
    }
    N.App.exitApp();
  });
  N.App.addListener('pause', () => { pauseGame(); save(); if(actx) actx.suspend(); });
  N.App.addListener('resume', () => { if(actx) actx.resume(); last = performance.now(); });
}catch(e){}
document.addEventListener('visibilitychange', () => { if(document.hidden){ pauseGame(); save(); } else last = performance.now(); });

/* start */
load(); lang = detectLang(); resize(); applyLang();
spawnDecoUpTo();
requestAnimationFrame((n) => { last = n; requestAnimationFrame(frame); });
try{ N && N.isNative && N.StatusBar.setBackgroundColor({ color: '#1a2a4a' }); }catch(e){}
try{ N && N.isNative && N.StatusBar.setStyle({ style: N.Style.Dark }); }catch(e){}
Ads.init().finally(() => { if(G.state === 'menu') Ads.showBanner(); try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} });
setTimeout(() => { try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} }, 2500);
if(!SV.gender) setTimeout(() => { if(!modalOpen && G.state === 'menu') chooseGender(); }, 600);
window.__dd = { drawRunner, update, G, SV: () => SV, swipe, startRun, showShop, chooseGender, setLang: (l) => { lang = l; applyLang(); } };
})();
