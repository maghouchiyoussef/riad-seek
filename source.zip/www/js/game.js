// Bubble Bloom — original bubble-shooter. Pop. Match. Bloom.
(function(){
'use strict';
const $ = (s) => document.querySelector(s);
const N = window.Native;

// ---------- i18n ----------
const L = {
 en:{sub:'Pop. Match. Bloom.',play:'Play',levels:'Levels',settings:'Settings',level:'LEVEL',score:'SCORE',ceil:'CEILING',best:'Best',win:'Level Clear!',lose:'Bubbles reached the line',next:'Next',retry:'Retry',home:'Home',cont:'Clear 3 rows (ad)',resume:'Resume',sound:'Sound',vib:'Vibration',privacy:'Privacy options',close:'Close',bombAd:'Out of boosters! Watch an ad for +2?',yes:'Watch ad',no:'No thanks',adNo:'Ad not ready, try later',hint:'Drag to aim, release to shoot',pause:'Paused',g1:'Nice!',g2:'Great!',g3:'Awesome!',g4:'BLOOM!',lv:'Level'},
 ar:{sub:'فرقع. طابق. أزهر.',play:'العب',levels:'المراحل',settings:'الإعدادات',level:'المرحلة',score:'النقاط',ceil:'السقف',best:'الأفضل',win:'أحسنت! أنهيت المرحلة',lose:'وصلت الفقاعات إلى الخط',next:'التالي',retry:'أعد المحاولة',home:'الرئيسية',cont:'امسح 3 صفوف (إعلان)',resume:'متابعة',sound:'الصوت',vib:'الاهتزاز',privacy:'خيارات الخصوصية',close:'إغلاق',bombAd:'انتهت المعززات! شاهد إعلانًا لتحصل على 2 إضافية؟',yes:'شاهد الإعلان',no:'لا، شكرًا',adNo:'الإعلان غير جاهز، حاول لاحقًا',hint:'اسحب للتصويب وأفلت للإطلاق',pause:'متوقف مؤقتًا',g1:'جميل!',g2:'رائع!',g3:'مذهل!',g4:'إزهار!',lv:'المرحلة'},
 fr:{sub:'Éclate. Associe. Fleuris.',play:'Jouer',levels:'Niveaux',settings:'Réglages',level:'NIVEAU',score:'SCORE',ceil:'PLAFOND',best:'Record',win:'Niveau réussi !',lose:'Les bulles ont atteint la ligne',next:'Suivant',retry:'Réessayer',home:'Accueil',cont:'Effacer 3 rangées (pub)',resume:'Reprendre',sound:'Son',vib:'Vibration',privacy:'Options de confidentialité',close:'Fermer',bombAd:'Plus de bonus ! Regarder une pub pour +2 ?',yes:'Regarder',no:'Non merci',adNo:'Pub indisponible, réessayez',hint:'Glisse pour viser, relâche pour tirer',pause:'Pause',g1:'Bien !',g2:'Super !',g3:'Génial !',g4:'BLOOM !',lv:'Niveau'},
 es:{sub:'Revienta. Combina. Florece.',play:'Jugar',levels:'Niveles',settings:'Ajustes',level:'NIVEL',score:'PUNTOS',ceil:'TECHO',best:'Mejor',win:'¡Nivel superado!',lose:'Las burbujas llegaron a la línea',next:'Siguiente',retry:'Reintentar',home:'Inicio',cont:'Borrar 3 filas (anuncio)',resume:'Continuar',sound:'Sonido',vib:'Vibración',privacy:'Opciones de privacidad',close:'Cerrar',bombAd:'¡Sin potenciadores! ¿Ver un anuncio para +2?',yes:'Ver anuncio',no:'No, gracias',adNo:'Anuncio no disponible',hint:'Arrastra para apuntar, suelta para disparar',pause:'Pausa',g1:'¡Bien!',g2:'¡Genial!',g3:'¡Increíble!',g4:'¡BLOOM!',lv:'Nivel'},
 pt:{sub:'Estoure. Combine. Floresça.',play:'Jogar',levels:'Níveis',settings:'Ajustes',level:'NÍVEL',score:'PONTOS',ceil:'TETO',best:'Melhor',win:'Nível concluído!',lose:'As bolhas chegaram à linha',next:'Próximo',retry:'Tentar de novo',home:'Início',cont:'Limpar 3 linhas (anúncio)',resume:'Continuar',sound:'Som',vib:'Vibração',privacy:'Opções de privacidade',close:'Fechar',bombAd:'Sem reforços! Ver anúncio para +2?',yes:'Ver anúncio',no:'Não, obrigado',adNo:'Anúncio indisponível',hint:'Arraste para mirar, solte para atirar',pause:'Pausado',g1:'Boa!',g2:'Ótimo!',g3:'Incrível!',g4:'BLOOM!',lv:'Nível'},
};
const lang = (() => { const l = (navigator.language || 'en').slice(0,2).toLowerCase(); return L[l] ? l : 'en'; })();
const T = L[lang];
const t = (k) => T[k] || L.en[k] || k;
if(lang === 'ar'){ document.documentElement.lang = 'ar'; document.documentElement.dir = 'rtl'; }

// ---------- save ----------
let SV = { lvl:1, best:0, bomb:2, rain:2, snd:1, vib:1 };
try{ Object.assign(SV, JSON.parse(localStorage.getItem('bb_save') || '{}')); }catch(e){}
const save = () => { try{ localStorage.setItem('bb_save', JSON.stringify(SV)); }catch(e){} };

// ---------- audio / haptics ----------
let AC = null;
function tone(f, d, type, vol, slide){
  if(!SV.snd) return;
  try{
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    const o = AC.createOscillator(), g = AC.createGain();
    o.type = type || 'sine'; o.frequency.value = f;
    if(slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, f*slide), AC.currentTime + d);
    g.gain.value = vol || .08; g.gain.exponentialRampToValueAtTime(.0001, AC.currentTime + d);
    o.connect(g); g.connect(AC.destination); o.start(); o.stop(AC.currentTime + d);
  }catch(e){}
}
const sndShoot = () => tone(420, .12, 'triangle', .07, 1.8);
const sndPop = (n) => tone(500 + Math.min(n,10)*60, .14, 'sine', .09, 1.5);
const sndWin = () => [523,659,784,1047].forEach((f,i) => setTimeout(() => tone(f,.25,'triangle',.09), i*120));
const sndLose = () => tone(220, .5, 'sawtooth', .06, .4);
function buzz(ms){ if(!SV.vib) return; try{ N && N.isNative ? N.Haptics.vibrate({duration: ms||20}) : navigator.vibrate && navigator.vibrate(ms||20); }catch(e){} }

// ---------- constants ----------
const W = 360, H = 550, R = 20, RH = R * 1.7320508, COLS = 9;
const SX = W/2, SY = 498;           // shooter
const DEAD = 12;                    // row index that ends the game
const PAL = [['#ff8a80','#e53935'],['#82b1ff','#1e63e0'],['#b9f6ca','#2eaa4f'],['#fff59d','#f4c20d'],['#ea80fc','#9c27b0'],['#ffcc80','#fb8c00']];

const cv = $('#cv'), ctx = cv.getContext('2d');
let scale = 0, dpr = 1;
function fit(){
  const wrap = $('#boardWrap'); if(!wrap.clientWidth) return;
  dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  const ns = Math.min(wrap.clientWidth / W, wrap.clientHeight / H);
  if(!(ns > 0)) return;
  if(Math.abs(ns - scale) < 0.001) return;
  scale = ns;
  cv.style.width = W*scale + 'px'; cv.style.height = H*scale + 'px';
  cv.width = Math.round(W*scale*dpr); cv.height = Math.round(H*scale*dpr);
  makeSprites();
}
addEventListener('resize', fit);
if(window.ResizeObserver) new ResizeObserver(() => requestAnimationFrame(fit)).observe($('#boardWrap'));
// status bar fallback (Android edge-to-edge, old WebView reports 0 insets)
(function(){
  const d = document.createElement('div'); d.style.cssText = 'position:fixed;top:0;height:var(--sat);visibility:hidden';
  document.body.appendChild(d); const h = d.getBoundingClientRect().height; d.remove();
  if(h < 1 && window.Native && Native.isNative) document.documentElement.style.setProperty('--sat', '28px');
})();

// ---------- sprites ----------
const spr = {};
function makeSprite(draw){
  const s = Math.ceil(R*2*scale*dpr) + 4, c = document.createElement('canvas'); c.width = c.height = s;
  const x = c.getContext('2d'); x.translate(s/2, s/2); x.scale(scale*dpr, scale*dpr); draw(x); return c;
}
function ball(x, c0, c1){
  const g = x.createRadialGradient(-6,-7,2,0,0,R); g.addColorStop(0,'#fff'); g.addColorStop(.25,c0); g.addColorStop(1,c1);
  x.beginPath(); x.arc(0,0,R-.8,0,7); x.fillStyle = g; x.fill();
  x.lineWidth = 1.5; x.strokeStyle = 'rgba(255,255,255,.55)'; x.stroke();
  x.beginPath(); x.ellipse(-6,-8,5.5,3,-.7,0,7); x.fillStyle = 'rgba(255,255,255,.75)'; x.fill();
}
function makeSprites(){
  PAL.forEach((p,i) => { spr[i] = makeSprite(x => ball(x,p[0],p[1])); });
  spr.rain = makeSprite(x => {
    for(let i=0;i<6;i++){ x.beginPath(); x.moveTo(0,0); x.arc(0,0,R-.8,i*Math.PI/3,(i+1)*Math.PI/3); x.fillStyle = PAL[i][1]; x.fill(); }
    x.beginPath(); x.arc(0,0,R-.8,0,7); x.lineWidth = 2; x.strokeStyle = '#fff'; x.stroke();
    x.beginPath(); x.arc(0,0,6,0,7); x.fillStyle = '#fff'; x.fill();
    x.beginPath(); x.ellipse(-6,-8,5,2.8,-.7,0,7); x.fillStyle = 'rgba(255,255,255,.6)'; x.fill();
  });
  spr.bomb = makeSprite(x => {
    const g = x.createRadialGradient(-6,-7,2,0,0,R); g.addColorStop(0,'#78909c'); g.addColorStop(1,'#101820');
    x.beginPath(); x.arc(0,2,R-2,0,7); x.fillStyle = g; x.fill();
    x.strokeStyle = '#ffcc80'; x.lineWidth = 3; x.beginPath(); x.moveTo(4,-14); x.quadraticCurveTo(10,-22,15,-20); x.stroke();
    x.fillStyle = '#ffeb3b'; x.beginPath(); x.arc(16,-21,4,0,7); x.fill();
    x.beginPath(); x.ellipse(-6,-6,4.5,2.6,-.7,0,7); x.fillStyle = 'rgba(255,255,255,.55)'; x.fill();
  });
}

// ---------- state ----------
let level = 1, grid = [], par = 0, colorsN = 3, dropEvery = 6, missLeft = 6, dropsAdded = 0, score = 0;
let cur = null, nxt = null, flying = null, armed = null;   // armed: null|'bomb'|'rain'
let fx = [], falling = [], aim = null, state = 'idle', rngS = 1;
let shotsFired = 0;

function rng(){ rngS |= 0; rngS = rngS + 0x6D2B79F5 | 0; let t = Math.imul(rngS ^ rngS >>> 15, 1 | rngS); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }
const offs = (i) => ((i + par) & 1) === 1;
const ncols = (i) => offs(i) ? COLS - 1 : COLS;
const cx = (i,c) => (offs(i) ? 2*R : R) + c*2*R;
const cy = (i) => R + i*RH;
const inb = (i,c) => i >= 0 && i < grid.length && c >= 0 && c < ncols(i);
const get = (i,c) => inb(i,c) ? grid[i][c] : undefined;

function neighbors(i,c){
  const o = [], x = cx(i,c), y = cy(i);
  for(const di of [-1,0,1]) for(let dc=-2; dc<=2; dc++){
    const j = i+di; if(!inb(j,c+dc) || (di===0 && dc===0)) continue;
    const dx = cx(j,c+dc)-x, dy = cy(j)-y;
    if(dx*dx+dy*dy < (2*R*1.08)**2) o.push([j,c+dc]);
  }
  return o;
}

function colorsPresent(){
  const s = new Set();
  for(const r of grid) for(const v of r) if(v !== null && v !== undefined) s.add(v);
  return [...s];
}
function randColor(){ const p = colorsPresent(); return p.length ? p[Math.floor(Math.random()*p.length)] : 0; }

function genLevel(n){
  rngS = n * 7919 + 13;
  colorsN = Math.min(3 + Math.floor((n-1)/5), 6);
  const rows = Math.min(4 + Math.floor((n-1)/3), 8);
  dropEvery = Math.max(4, 7 - Math.floor(n/10));
  par = 0; grid = [];
  for(let i=0;i<16;i++) grid.push(new Array(COLS).fill(null));
  for(let i=0;i<rows;i++) for(let c=0;c<ncols(i);c++){
    let col = Math.floor(rng()*colorsN);
    if(c>0 && rng()<.38) col = grid[i][c-1];
    else if(i>0 && rng()<.28){ const up = grid[i-1][Math.min(c, ncols(i-1)-1)]; if(up!==null) col = up; }
    grid[i][c] = col;
  }
}

function newBall(type){ return { col: randColor(), type: type || null }; }

function startLevel(n){
  level = n; score = 0; dropsAdded = 0; shotsFired = 0; fx = []; falling = []; flying = null; armed = null; aim = null;
  genLevel(n); missLeft = dropEvery;
  cur = newBall(); nxt = newBall();
  state = 'play';
  updHud(); updBoosters();
  show('game');
  setTimeout(fit, 0);
  if(n <= 2) toast(t('hint'));
}

function updHud(){
  $('#gLevel').textContent = level; $('#gScore').textContent = score; $('#gDrop').textContent = missLeft;
  $('#gDrop').style.color = missLeft <= 1 ? '#ff8a80' : '';
}
function updBoosters(){
  $('#cBomb').textContent = SV.bomb; $('#cRain').textContent = SV.rain;
  $('#bBomb').classList.toggle('on', armed === 'bomb'); $('#bRain').classList.toggle('on', armed === 'rain');
}

// ---------- input ----------
function pt(e){
  const r = cv.getBoundingClientRect();
  return [(e.clientX - r.left) / r.width * W, (e.clientY - r.top) / r.height * H];
}
let down = false;
cv.addEventListener('pointerdown', (e) => {
  if(state !== 'play' || flying) return;
  e.preventDefault(); cv.setPointerCapture(e.pointerId);
  const [x,y] = pt(e);
  if(Math.hypot(x-SX, y-SY) < 28 || Math.hypot(x-(SX-75), y-(SY+12)) < 24){ swap(); return; }
  down = true; setAim(x,y);
});
cv.addEventListener('pointermove', (e) => { if(down){ const [x,y] = pt(e); setAim(x,y); } });
const endDrag = (e) => {
  if(!down) return; down = false;
  if(aim && state === 'play' && !flying) shoot(aim);
  aim = null;
};
cv.addEventListener('pointerup', endDrag);
cv.addEventListener('pointercancel', () => { down = false; aim = null; });

function setAim(x,y){
  let dx = x - SX, dy = y - SY;
  if(dy > -12) dy = -12;
  let a = Math.atan2(dy, dx);                       // radians, up = -PI/2
  const lim = 9 * Math.PI/180;
  if(a > -lim) a = -lim; if(a < -Math.PI + lim) a = -Math.PI + lim;
  aim = a;
}

function swap(){
  if(!cur || !nxt || flying || state !== 'play') return;
  [cur, nxt] = [nxt, cur]; buzz(8); tone(300,.07,'sine',.05);
}

// ---------- shooting ----------
function shoot(a){
  const b = { x:SX, y:SY, vx:Math.cos(a)*640, vy:Math.sin(a)*640, col:cur.col, type:null };
  if(armed === 'bomb' && SV.bomb > 0){ b.type = 'bomb'; SV.bomb--; save(); }
  else if(armed === 'rain' && SV.rain > 0){ b.type = 'rain'; SV.rain--; save(); }
  armed = null; flying = b; shotsFired++;
  cur = nxt; nxt = newBall();
  updBoosters(); sndShoot(); buzz(10);
}

function stepFlying(dt){
  const b = flying; if(!b) return;
  let dist = Math.hypot(b.vx, b.vy) * dt, steps = Math.max(1, Math.ceil(dist / 5));
  for(let s=0; s<steps; s++){
    b.x += b.vx*dt/steps; b.y += b.vy*dt/steps;
    if(b.x < R){ b.x = R; b.vx = Math.abs(b.vx); }
    if(b.x > W-R){ b.x = W-R; b.vx = -Math.abs(b.vx); }
    let hit = b.y <= R;
    if(!hit){
      for(let i=0;i<grid.length && !hit;i++){
        if(cy(i) < b.y - 2*R - 2) continue; if(cy(i) > b.y + 2*R + 2) break;
        for(let c=0;c<ncols(i);c++) if(grid[i][c] !== null){
          const dx = cx(i,c)-b.x, dy = cy(i)-b.y;
          if(dx*dx+dy*dy < (R*1.78)**2){ hit = true; break; }
        }
      }
    }
    if(hit){ flying = null; land(b); return; }
  }
}

function nearestEmpty(x,y){
  let best = null, bd = 1e9;
  for(let i=0;i<15;i++) for(let c=0;c<ncols(i);c++){
    if(grid[i][c] !== null) continue;
    const dx = cx(i,c)-x, dy = cy(i)-y, d = dx*dx+dy*dy;
    if(d < bd){ bd = d; best = [i,c]; }
  }
  return best;
}

function land(b){
  let popped = 0;
  if(b.type === 'bomb'){
    popped = explode(b.x, b.y);
    sndPop(8); buzz(40);
  } else {
    const cell = nearestEmpty(b.x, b.y); if(!cell){ endTurn(0); return; }
    const [i,c] = cell;
    let col = b.col;
    if(b.type === 'rain'){
      const cnt = {}; neighbors(i,c).forEach(([j,k]) => { const v = grid[j][k]; if(v!==null) cnt[v] = (cnt[v]||0)+1; });
      const ks = Object.keys(cnt); col = ks.length ? +ks.sort((p,q) => cnt[q]-cnt[p])[0] : randColor();
    }
    grid[i][c] = col;
    const grp = flood(i,c);
    if(grp.length >= 3){
      popped = grp.length;
      grp.forEach(([j,k]) => popCell(j,k));
      score += grp.length * 10 + (grp.length - 3) * 8;
      sndPop(grp.length); buzz(18 + grp.length*3);
      if(grp.length >= 6) say(t('g3')); else if(grp.length >= 4) say(t('g2'));
    } else { tone(200,.06,'sine',.05); }
  }
  endTurn(popped);
}

function flood(i,c){
  const col = grid[i][c], seen = new Set([i*20+c]), q = [[i,c]], out = [];
  while(q.length){
    const [a,b] = q.pop(); out.push([a,b]);
    neighbors(a,b).forEach(([j,k]) => { const key = j*20+k; if(!seen.has(key) && grid[j][k] === col){ seen.add(key); q.push([j,k]); } });
  }
  return out;
}

function popCell(i,c, fall){
  const col = grid[i][c]; if(col === null) return;
  grid[i][c] = null;
  const x = cx(i,c), y = cy(i);
  if(fall){ falling.push({x,y,vx:(Math.random()-.5)*80,vy:-60-Math.random()*60,col,a:1}); }
  else {
    fx.push({x,y,col,t:0,k:'ring'});
    for(let n=0;n<5;n++) fx.push({x,y,col,t:0,k:'dot',vx:(Math.random()-.5)*220,vy:(Math.random()-.8)*200});
  }
}

function explode(x,y){
  let n = 0;
  for(let i=0;i<grid.length;i++) for(let c=0;c<ncols(i);c++){
    if(grid[i][c] === null) continue;
    if(Math.hypot(cx(i,c)-x, cy(i)-y) < 3.1*R){ popCell(i,c); n++; }
  }
  score += n * 12;
  fx.push({x,y,col:3,t:0,k:'boom'});
  say(t('g4'));
  return n;
}

function removeFloating(){
  const seen = new Set(), q = [];
  for(let c=0;c<ncols(0);c++) if(grid[0][c] !== null){ seen.add(c); q.push([0,c]); }
  while(q.length){
    const [a,b] = q.pop();
    neighbors(a,b).forEach(([j,k]) => { const key = j*20+k; if(!seen.has(key) && grid[j][k] !== null){ seen.add(key); q.push([j,k]); } });
  }
  let n = 0;
  for(let i=0;i<grid.length;i++) for(let c=0;c<ncols(i);c++)
    if(grid[i][c] !== null && !seen.has(i*20+c)){ popCell(i,c,true); n++; }
  if(n){ score += n * 20; sndPop(n+4); if(n >= 5) say(t('g3')); else say(t('g1')); }
  return n;
}

function anyBubbles(){ return grid.some(r => r.some(v => v !== null)); }
function lowest(){ let m = -1; grid.forEach((r,i) => { if(r.some(v => v !== null)) m = i; }); return m; }

function addRow(){
  const row = new Array(COLS).fill(null);
  par ^= 1; // flipping parity keeps stagger alternating after unshift
  const pc = colorsPresent();
  const pick = () => pc.length ? pc[Math.floor(Math.random()*pc.length)] : 0;
  grid.unshift(row); grid.length = Math.max(grid.length - 1, 16);
  for(let c=0;c<ncols(0);c++) row[c] = (c>0 && Math.random()<.35) ? row[c-1] : pick();
  dropsAdded++; tone(150,.18,'square',.05,.6); buzz(25);
}

function endTurn(popped){
  removeFloating();
  if(!anyBubbles()){ return win(); }
  if(!popped){
    missLeft--;
    if(missLeft <= 0){ addRow(); missLeft = dropEvery; }
  }
  updHud();
  if(lowest() >= DEAD){ return lose(); }
  // keep upcoming balls solvable
  const p = colorsPresent();
  if(!p.includes(cur.col) && !cur.type) cur.col = p[Math.floor(Math.random()*p.length)];
  if(!p.includes(nxt.col)) nxt.col = p[Math.floor(Math.random()*p.length)];
}

// ---------- end of level ----------
async function win(){
  state = 'over'; sndWin(); buzz(60);
  const stars = dropsAdded === 0 ? 3 : dropsAdded <= 2 ? 2 : 1;
  SV.lvl = Math.max(SV.lvl, level + 1); SV.best = Math.max(SV.best, score);
  SV.bomb += (level % 5 === 0) ? 1 : 0; save();
  setTimeout(() => {
    modal(`<h2>${t('win')}</h2><div class="stars" id="st"><span>⭐</span><span>⭐</span><span>⭐</span></div>
      <p>${t('score')}: <b>${score}</b></p>
      <button class="btn grn big" id="mNext" style="padding:14px 40px">${t('next')} ▶</button>
      <button class="btn alt sm" id="mHome">${t('home')}</button>`);
    [...document.querySelectorAll('#st span')].forEach((s,i) => { if(i < stars) setTimeout(() => { s.classList.add('on'); tone(600+i*150,.15,'triangle',.08); }, 250 + i*300); });
    $('#mNext').onclick = async () => { await afterRound(); closeModal(); startLevel(level + 1); };
    $('#mHome').onclick = async () => { closeModal(); goHome(); };
  }, 700);
}
async function afterRound(){ if(level >= 3){ try{ await Ads.maybeInterstitial(); }catch(e){} } }

function lose(){
  state = 'over'; sndLose(); buzz(80);
  setTimeout(() => {
    modal(`<h2>${t('lv')} ${level}</h2><p>${t('lose')}</p>
      <button class="btn grn" id="mCont">▶ ${t('cont')}</button>
      <button class="btn big" id="mRetry" style="padding:14px 40px">${t('retry')}</button>
      <button class="btn alt sm" id="mHome">${t('home')}</button>`);
    $('#mCont').onclick = async () => {
      if(!(await rewarded())) return;
      closeModal();
      const lo = lowest(); for(let i=Math.max(0,lo-2); i<=lo; i++) for(let c=0;c<ncols(i);c++) popCell(i,c);
      removeFloating(); missLeft = dropEvery; updHud(); state = 'play';
    };
    $('#mRetry').onclick = async () => { await afterRound(); closeModal(); startLevel(level); };
    $('#mHome').onclick = () => { closeModal(); goHome(); };
  }, 600);
}

// ---------- boosters ----------
function toggleBoost(kind, key){
  if(state !== 'play' || flying) return;
  if(SV[key] <= 0){ offerAd(); return; }
  armed = armed === kind ? null : kind; updBoosters(); buzz(8);
}
$('#bBomb').onclick = () => toggleBoost('bomb','bomb');
$('#bRain').onclick = () => toggleBoost('rain','rain');
$('#bSwap').onclick = swap;
function offerAd(){
  const was = state; state = 'modal';
  modal(`<p style="font-size:18px">${t('bombAd')}</p>
    <button class="btn grn" id="aYes">▶ ${t('yes')}</button>
    <button class="btn alt sm" id="aNo">${t('no')}</button>`);
  $('#aNo').onclick = () => { closeModal(); state = was; };
  $('#aYes').onclick = async () => {
    if(await rewarded()){ SV.bomb += 2; SV.rain += 2; save(); updBoosters(); closeModal(); state = was; toast('+2 💣 +2 🌈'); }
  };
}
async function rewarded(){
  if(!Ads.isNative) return true; // web preview only
  if(!Ads.rewardedAvailable()){ toast(t('adNo')); return false; }
  return !!(await Ads.showRewarded());
}

// ---------- ui ----------
function modal(html){ const m = $('#modal'); m.innerHTML = '<div class="box">' + html + '</div>'; m.classList.add('show'); }
function closeModal(){ $('#modal').classList.remove('show'); $('#modal').innerHTML = ''; }
let toastT = 0;
function toast(s){ const e = $('#toast'); e.textContent = s; e.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => e.classList.remove('show'), 2200); }
function say(s){ const m = $('#msg'); m.textContent = s; m.classList.remove('show'); void m.offsetWidth; m.classList.add('show'); }

function show(id){
  document.querySelectorAll('.scr').forEach(s => s.classList.toggle('show', s.id === id));
  if(id === 'game') Ads.hideBanner(); else Ads.showBanner();
}
function goHome(){
  state = 'idle'; $('#hLevel').textContent = t('lv') + ' ' + SV.lvl; $('#hBest').textContent = '🏆 ' + SV.best; show('home');
}
function buildMap(){
  const g = $('#lvgrid'); g.innerHTML = '';
  const total = Math.max(40, SV.lvl + 9);
  for(let i=1;i<=total;i++){
    const b = document.createElement('button'); b.className = 'lv' + (i === SV.lvl ? ' cur' : i > SV.lvl ? ' lock' : '');
    b.innerHTML = i > SV.lvl ? '🔒' : i;
    if(i <= SV.lvl) b.onclick = () => startLevel(i);
    g.appendChild(b);
  }
  $('#mTitle').textContent = t('levels'); $('#mBest').textContent = '🏆 ' + SV.best;
  show('map');
  const cur = g.querySelector('.cur'); if(cur) setTimeout(() => cur.scrollIntoView({block:'center'}), 0);
}
function settings(){
  const row = (id, label, on) => `<div class="setrow"><span>${label}</span><button class="btn sm ${on?'grn':'alt'}" id="${id}">${on?'ON':'OFF'}</button></div>`;
  modal(`<h2>${t('settings')}</h2>${row('sSnd',t('sound'),SV.snd)}${row('sVib',t('vib'),SV.vib)}
    ${Ads.privacyRequired ? `<button class="btn alt sm" id="sPriv">🔒 ${t('privacy')}</button>` : ''}
    <button class="btn" id="sClose">${t('close')}</button>`);
  $('#sSnd').onclick = () => { SV.snd = SV.snd ? 0 : 1; save(); settings(); };
  $('#sVib').onclick = () => { SV.vib = SV.vib ? 0 : 1; save(); settings(); };
  const p = $('#sPriv'); if(p) p.onclick = () => Ads.showPrivacyOptions();
  $('#sClose').onclick = closeModal;
}
function pause(){
  if(state !== 'play') return; const was = state; state = 'modal';
  modal(`<h2>${t('pause')}</h2><button class="btn grn" id="pR">▶ ${t('resume')}</button>
    <button class="btn alt sm" id="pRe">${t('retry')}</button><button class="btn alt sm" id="pH">${t('home')}</button>`);
  $('#pR').onclick = () => { closeModal(); state = was; };
  $('#pRe').onclick = () => { closeModal(); startLevel(level); };
  $('#pH').onclick = () => { closeModal(); goHome(); };
}

$('#bPlay').onclick = () => startLevel(SV.lvl);
$('#bMap').onclick = buildMap;
$('#bSet').onclick = settings;
$('#mBack').onclick = goHome;
$('#bPause').onclick = pause;
try{ N && N.App && N.App.addListener('backButton', () => {
  if($('#modal').classList.contains('show')){ if(state === 'modal' && $('#pR')) $('#pR').click(); else closeModal(); return; }
  if($('#game').classList.contains('show')) pause();
  else if($('#map').classList.contains('show')) goHome();
  else N.App.exitApp();
}); N && N.App && N.App.addListener('pause', () => { if($('#game').classList.contains('show')) pause(); }); }catch(e){}

// ---------- render ----------
function drawBall(col, type, x, y, s){
  const img = type ? spr[type] : spr[col]; if(!img) return;
  const w = img.width / (scale*dpr) * (s||1);
  ctx.drawImage(img, x - w/2, y - w/2, w, w);
}
function guide(){
  if(aim === null || flying) return;
  let x = SX, y = SY, vx = Math.cos(aim), vy = Math.sin(aim), d = 0;
  ctx.fillStyle = 'rgba(255,255,255,.8)';
  for(let n=0; n<260; n++){
    x += vx*6; y += vy*6; d += 6;
    if(x < R){ x = R; vx = Math.abs(vx); } if(x > W-R){ x = W-R; vx = -Math.abs(vx); }
    if(y <= R) break;
    let hit = false;
    for(let i=0;i<grid.length && !hit;i++){ if(cy(i) < y-2*R-2) continue; if(cy(i) > y+2*R+2) break;
      for(let c=0;c<ncols(i);c++) if(grid[i][c] !== null && (cx(i,c)-x)**2+(cy(i)-y)**2 < (R*1.78)**2){ hit = true; break; } }
    if(hit) break;
    if(n % 2 === 0){ ctx.beginPath(); ctx.arc(x,y,2.6,0,7); ctx.fill(); }
  }
}
function render(dt){
  ctx.setTransform(scale*dpr,0,0,scale*dpr,0,0);
  ctx.clearRect(0,0,W,H);
  // board backdrop
  ctx.fillStyle = 'rgba(0,20,70,.28)'; ctx.fillRect(0,0,W,H);
  // danger line
  ctx.strokeStyle = 'rgba(255,120,120,.75)'; ctx.setLineDash([8,8]); ctx.lineWidth = 2;
  const dy = DEAD * RH; ctx.beginPath(); ctx.moveTo(0,dy); ctx.lineTo(W,dy); ctx.stroke(); ctx.setLineDash([]);
  // bubbles
  for(let i=0;i<grid.length;i++) for(let c=0;c<ncols(i);c++){ const v = grid[i][c]; if(v !== null) drawBall(v, null, cx(i,c), cy(i)); }
  guide();
  // falling
  for(let k=falling.length-1;k>=0;k--){ const f = falling[k]; f.vy += 900*dt; f.x += f.vx*dt; f.y += f.vy*dt; f.a -= dt*.6;
    if(f.y > H+40 || f.a <= 0){ falling.splice(k,1); continue; } ctx.globalAlpha = Math.max(0,f.a); drawBall(f.col, null, f.x, f.y); ctx.globalAlpha = 1; }
  // fx
  for(let k=fx.length-1;k>=0;k--){ const f = fx[k]; f.t += dt;
    if(f.k === 'ring'){ const p = f.t/.28; if(p>=1){ fx.splice(k,1); continue; } ctx.globalAlpha = 1-p; ctx.strokeStyle = PAL[f.col][0]; ctx.lineWidth = 4*(1-p)+1; ctx.beginPath(); ctx.arc(f.x,f.y,R*(.8+p*1.1),0,7); ctx.stroke(); ctx.globalAlpha = 1; }
    else if(f.k === 'dot'){ if(f.t>.45){ fx.splice(k,1); continue; } f.vy += 500*dt; f.x += f.vx*dt; f.y += f.vy*dt; ctx.globalAlpha = 1-f.t/.45; ctx.fillStyle = PAL[f.col][0]; ctx.beginPath(); ctx.arc(f.x,f.y,4,0,7); ctx.fill(); ctx.globalAlpha = 1; }
    else { const p = f.t/.4; if(p>=1){ fx.splice(k,1); continue; } ctx.globalAlpha = (1-p)*.8; ctx.fillStyle = '#ffd54f'; ctx.beginPath(); ctx.arc(f.x,f.y,R*(1+p*3),0,7); ctx.fill(); ctx.globalAlpha = 1; } }
  // shooter
  ctx.fillStyle = 'rgba(255,255,255,.18)'; ctx.beginPath(); ctx.arc(SX,SY,R+9,0,7); ctx.fill();
  if(aim !== null && !flying){ ctx.save(); ctx.translate(SX,SY); ctx.rotate(aim + Math.PI/2); ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.beginPath(); ctx.moveTo(0,-R-18); ctx.lineTo(8,-R-4); ctx.lineTo(-8,-R-4); ctx.fill(); ctx.restore(); }
  if(cur && !flying) drawBall(cur.col, armed, SX, SY);
  if(cur && flying) drawBall(cur.col, null, SX, SY, .8);
  if(nxt){ drawBall(nxt.col, null, SX-75, SY+12, .72); ctx.fillStyle = 'rgba(255,255,255,.7)'; ctx.font = 'bold 22px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('↻', SX-40, SY+20); }
  if(flying) drawBall(flying.col, flying.type, flying.x, flying.y);
}
let last = performance.now();
function loop(now){
  const dt = Math.min(.05, (now-last)/1000); last = now;
  if($('#game').classList.contains('show')){
    if(state === 'play' || state === 'over') stepFlying(dt);
    render(dt);
  }
  requestAnimationFrame(loop);
}

// ---------- logo ----------
function drawLogo(){
  const c = $('#logoCv'), x = c.getContext('2d'); x.clearRect(0,0,c.width,c.height);
  const pos = [[90,160,0,1.1],[190,110,1,1.4],[290,150,2,1.7],[390,105,3,1.35],[470,165,4,1.0],[240,215,5,1.0],[340,220,0,1.15]];
  pos.forEach(([px,py,i,s]) => {
    const r = R*s*1.5, g = x.createRadialGradient(px-r*.3,py-r*.35,3,px,py,r);
    g.addColorStop(0,'#fff'); g.addColorStop(.25,PAL[i%6][0]); g.addColorStop(1,PAL[i%6][1]);
    x.beginPath(); x.arc(px,py,r,0,7); x.fillStyle = g; x.fill(); x.lineWidth = 3; x.strokeStyle = 'rgba(255,255,255,.55)'; x.stroke();
    x.beginPath(); x.ellipse(px-r*.3,py-r*.4,r*.26,r*.15,-.7,0,7); x.fillStyle = 'rgba(255,255,255,.75)'; x.fill();
  });
}

// ---------- init ----------
function applyText(){
  $('#tSub').textContent = t('sub'); $('#bPlay').textContent = '▶ ' + t('play');
  $('#bMap').textContent = t('levels'); $('#bSet').textContent = t('settings');
  $('#lLevel').textContent = t('level'); $('#lScore').textContent = t('score'); $('#lDrop').textContent = t('ceil');
}
applyText(); drawLogo(); goHome(); requestAnimationFrame(loop);
window.__bb = { startLevel, get grid(){ return grid; }, get state(){ return state; }, shoot, setAim, get score(){ return score; } };
Ads.init().finally(() => { if(!$('#game').classList.contains('show')) Ads.showBanner(); try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} });
})();
