(function(){
'use strict';
const $ = (s) => document.querySelector(s);
const N = window.Native;
const KEY = 'ps_save_v1';

// ---------- save ----------
let S = { stars:{}, hints:3, lang:null };
try{ const r = localStorage.getItem(KEY); if(r) S = Object.assign(S, JSON.parse(r)); }catch(e){}
function save(){ try{ localStorage.setItem(KEY, JSON.stringify(S)); }catch(e){} }
if(!S.lang){ S.lang = ((navigator.language||'en').toLowerCase().startsWith('ar')) ? 'ar' : 'en'; }

// ---------- text ----------
const T = {
  title:['Prophet Stories Quiz','قصص الأنبياء: اختبار'],
  sub:['Read the story, then test yourself','اقرأ القصة ثم اختبر نفسك'],
  play:['Play','العب'], chapters:['Stories','القصص'],
  next:['Next','التالي'], start:['Start Quiz','ابدأ الاختبار'],
  hint:['50/50','50/50'], hintAd:['+2 hints (ad)','+2 تلميح (إعلان)'],
  win:['Well done!','أحسنت!'], lose:['Try again','حاول مجددًا'],
  loseTxt:['You ran out of hearts. Read the story again and retry.','نفدت قلوبك. أعد قراءة القصة وحاول مرة أخرى.'],
  cont:['Continue with 1 heart (ad)','تابع بقلب واحد (إعلان)'],
  again:['Retry','أعد المحاولة'], readAgain:['Read story','اقرأ القصة'], nextCh:['Next story','القصة التالية'], map:['Stories','القصص'],
  score:['Correct answers','الإجابات الصحيحة'],
  settings:['Settings','الإعدادات'], privacy:['Privacy options','خيارات الخصوصية'], close:['Close','إغلاق'],
  noAd:['No ad available now','لا يوجد إعلان الآن'], noHint:['No hints left','لا توجد تلميحات'],
  locked:['Finish the previous story first','أكمل القصة السابقة أولًا'],
  quit:['Leave this quiz?','هل تريد الخروج من الاختبار؟'], yes:['Leave','خروج'], no:['Stay','البقاء'],
  q:['Question','السؤال'], of:['of','من'], lang:['العربية','English'],
  pbuh:[' – peace be upon him',' عليه السلام'], pbuhM:[' ﷺ',' ﷺ'],
  allDone:['You finished all the stories!','أنهيت كل القصص!'], hintsLeft:['hints','تلميحات'],
};
const L = () => S.lang === 'ar' ? 1 : 0;
const t = (k) => (T[k] || [k,k])[L()];
function applyLang(){
  document.documentElement.lang = S.lang;
  document.documentElement.dir = S.lang === 'ar' ? 'rtl' : 'ltr';
  document.title = t('title');
}

// ---------- utils ----------
const shuffle = (a) => { a = a.slice(); for(let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; } return a; };
function toast(msg){ const el = $('#toast'); el.textContent = msg; el.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('show'), 1800); }
function buzz(kind){ try{ if(!N || !N.isNative) return; if(kind==='ok') N.Haptics.impact({style:N.ImpactStyle.Light}); else if(kind==='bad') N.Haptics.notification({type:N.NotificationType.Error}); }catch(e){} }
function show(id){
  document.querySelectorAll('.scr').forEach(s => s.classList.remove('show'));
  $('#'+id).classList.add('show');
  cur = id;
  try{ if(id === 'game') Ads.hideBanner(); else Ads.showBanner(); }catch(e){}
}
let cur = 'home';
function totalStars(){ return Object.values(S.stars).reduce((a,b)=>a+b,0); }
function chName(c){ return c.name[L()] + (c.id === 'muhammad' ? T.pbuhM[L()] : T.pbuh[L()]); }
function unlocked(i){ return i === 0 || (S.stars[CH[i-1].id] || 0) >= 1; }
function starsHTML(n){ return '★'.repeat(n) + '<i>' + '★'.repeat(3-n) + '</i>'; }
function setColors(c){ document.documentElement.style.setProperty('--c1', c.c1); document.documentElement.style.setProperty('--c2', c.c2); }

// ---------- home ----------
function renderHome(){
  applyLang();
  $('#hTitle').textContent = t('title');
  $('#hSub').textContent = t('sub');
  $('#hPlay').textContent = t('play');
  $('#hStars').textContent = '⭐ ' + totalStars() + ' / ' + (CH.length*3);
  $('#hLang').textContent = t('lang');
}
$('#hPlay').onclick = () => { renderMap(); show('map'); };
$('#hLang').onclick = () => { S.lang = S.lang === 'ar' ? 'en' : 'ar'; save(); renderHome(); };
$('#hSet').onclick = openSettings;

function openSettings(){
  modal(`<h2>${t('settings')}</h2>
    <button class="btn alt" id="mLang">${t('lang')}</button>
    ${Ads.privacyRequired ? `<button class="btn alt sm" id="mPriv">🔒 ${t('privacy')}</button>` : ''}
    <button class="btn" id="mClose">${t('close')}</button>`);
  $('#mLang').onclick = () => { S.lang = S.lang === 'ar' ? 'en' : 'ar'; save(); renderHome(); closeModal(); openSettings(); };
  const p = $('#mPriv'); if(p) p.onclick = () => Ads.showPrivacyOptions();
  $('#mClose').onclick = closeModal;
}
function modal(html){ const m = $('#modal'); m.innerHTML = '<div class="mb">'+html+'</div>'; m.classList.add('show'); }
function closeModal(){ const m = $('#modal'); m.classList.remove('show'); m.innerHTML = ''; }

// ---------- map ----------
function renderMap(){
  $('#mTitle').textContent = t('chapters');
  $('#mStars').textContent = '⭐ ' + totalStars() + '/' + (CH.length*3);
  const p = $('#path'); p.innerHTML = '';
  let nextFound = false;
  CH.forEach((c, i) => {
    const ok = unlocked(i), st = S.stars[c.id] || 0;
    const b = document.createElement('button');
    b.className = 'node' + (ok ? '' : ' lock');
    if(ok && !st && !nextFound){ b.classList.add('next'); nextFound = true; }
    b.style.setProperty('--c1', c.c1); b.style.setProperty('--c2', c.c2);
    b.innerHTML = `<div class="ic">${ok ? c.icon : '🔒'}</div><div><div class="nm">${i+1}. ${c.name[L()]}</div><div class="st">${starsHTML(st)}</div></div>`;
    b.onclick = () => { if(!ok){ toast(t('locked')); return; } openChapter(i); };
    p.appendChild(b);
  });
  const nx = p.querySelector('.next'); if(nx) setTimeout(() => nx.scrollIntoView({block:'center'}), 50);
}
$('#mBack').onclick = () => { renderHome(); show('home'); };

// ---------- story ----------
let ci = 0, page = 0;
function openChapter(i){ ci = i; page = 0; setColors(CH[i]); renderStory(); show('story'); }
function renderStory(){
  const c = CH[ci];
  $('#sIcon').textContent = c.icon;
  $('#sName').textContent = chName(c);
  $('#sTxt').textContent = c.story[page][L()];
  $('#sCnt').textContent = (page+1) + '/' + c.story.length;
  $('#sDots').innerHTML = c.story.map((_, k) => '<b class="' + (k <= page ? 'on' : '') + '"></b>').join('');
  $('#sNext').textContent = page === c.story.length-1 ? t('start') : t('next');
}
$('#sNext').onclick = () => {
  if(page < CH[ci].story.length-1){ page++; renderStory(); } else startQuiz();
};
$('#sBack').onclick = () => { renderMap(); show('map'); };

// ---------- quiz ----------
let qs = [], qi = 0, hearts = 3, wrong = 0, correct = 0, locked = false, usedHint = false;
function startQuiz(){
  qs = shuffle(CH[ci].qs).map(q => {
    const idx = shuffle([0,1,2,3]);
    return { q:q.q, o: idx.map(k => q.o[k]), c: idx.indexOf(q.c) };
  });
  qi = 0; hearts = 3; wrong = 0; correct = 0;
  setColors(CH[ci]);
  renderQ(); show('game');
}
function heartsStr(){ return '❤️'.repeat(hearts) + '🖤'.repeat(Math.max(0, 3-hearts)); }
function renderQ(){
  locked = false; usedHint = false;
  const q = qs[qi];
  $('#gBar').style.width = (qi / qs.length * 100) + '%';
  $('#gHearts').textContent = heartsStr();
  $('#gQ').textContent = q.q[L()];
  const box = $('#gOpts'); box.innerHTML = '';
  q.o.forEach((o, k) => {
    const b = document.createElement('button');
    b.className = 'opt'; b.textContent = o[L()];
    b.onclick = () => answer(k, b);
    box.appendChild(b);
  });
  updateHintBtn();
}
function updateHintBtn(){
  const b = $('#gHint');
  b.textContent = S.hints > 0 ? ('💡 ' + t('hint') + ' (' + S.hints + ')') : ('🎬 ' + t('hintAd'));
}
$('#gHint').onclick = async () => {
  if(locked) return;
  if(S.hints <= 0){
    if(Ads.isNative && !Ads.rewardedAvailable()){ toast(t('noAd')); return; }
    const ok = Ads.isNative ? await Ads.showRewarded() : true;
    if(ok){ S.hints += 2; save(); updateHintBtn(); }
    return;
  }
  if(usedHint) return;
  usedHint = true; S.hints--; save(); updateHintBtn();
  const q = qs[qi];
  const wrongs = shuffle([0,1,2,3].filter(k => k !== q.c)).slice(0, 2);
  const btns = $('#gOpts').children;
  wrongs.forEach(k => btns[k].classList.add('off'));
};
function answer(k, btn){
  if(locked) return; locked = true;
  const q = qs[qi]; const btns = $('#gOpts').children;
  if(k === q.c){ btn.classList.add('ok'); correct++; buzz('ok'); }
  else { btn.classList.add('bad'); btns[q.c].classList.add('ok'); wrong++; hearts--; buzz('bad'); $('#gHearts').textContent = heartsStr(); }
  setTimeout(() => {
    if(hearts <= 0){ return failed(); }
    qi++;
    if(qi >= qs.length) return finished();
    renderQ();
  }, 1100);
}
$('#gBack').onclick = () => {
  modal(`<h2>${t('quit')}</h2><div class="row"><button class="btn grn" id="mNo">${t('no')}</button><button class="btn alt" id="mYes">${t('yes')}</button></div>`);
  $('#mNo').onclick = closeModal;
  $('#mYes').onclick = () => { closeModal(); renderMap(); show('map'); };
};

async function failed(){
  const canAd = Ads.isNative && Ads.rewardedAvailable();
  show('story'); // leaves quiz screen (banner returns)
  renderStory();
  modal(`<h2>💔 ${t('lose')}</h2><p>${t('loseTxt')}</p>
    ${canAd ? `<button class="btn grn" id="mCont">🎬 ${t('cont')}</button>` : ''}
    <button class="btn" id="mRetry">${t('again')}</button>
    <button class="btn alt sm" id="mRead">${t('readAgain')}</button>`);
  const c = $('#mCont');
  if(c) c.onclick = async () => {
    const ok = await Ads.showRewarded();
    if(ok){ closeModal(); hearts = 1; qi++; if(qi >= qs.length){ finished(); } else { show('game'); renderQ(); } }
    else toast(t('noAd'));
  };
  $('#mRetry').onclick = () => { closeModal(); startQuiz(); };
  $('#mRead').onclick = () => { closeModal(); page = 0; renderStory(); };
  afterRound();
}

function finished(){
  const stars = wrong === 0 ? 3 : wrong === 1 ? 2 : 1;
  const id = CH[ci].id;
  if(stars > (S.stars[id] || 0)){ S.stars[id] = stars; save(); }
  show('story'); renderStory();
  const last = ci >= CH.length - 1;
  modal(`<h2>🎉 ${t('win')}</h2>
    <div class="stars">${starsHTML(stars)}</div>
    <p>${t('score')}: ${correct}/${qs.length}</p>
    ${last ? `<p>${t('allDone')}</p>` : ''}
    ${!last ? `<button class="btn grn" id="mNext">${t('nextCh')}</button>` : ''}
    <button class="btn alt sm" id="mMap">${t('map')}</button>
    <button class="btn alt sm" id="mRe">${t('again')}</button>`);
  if(!last) $('#mNext').onclick = () => { closeModal(); openChapter(ci + 1); };
  $('#mMap').onclick = () => { closeModal(); renderMap(); show('map'); };
  $('#mRe').onclick = () => { closeModal(); startQuiz(); };
  afterRound();
}
// Interstitial only at natural breaks (after a quiz round), from story 3 on.
async function afterRound(){ if(ci >= 2){ try{ await Ads.maybeInterstitial(); }catch(e){} } }

// ---------- back button ----------
try{
  if(N && N.isNative){
    N.App.addListener('backButton', () => {
      if($('#modal').classList.contains('show')){ closeModal(); return; }
      if(cur === 'game') $('#gBack').click();
      else if(cur === 'story') $('#sBack').click();
      else if(cur === 'map') $('#mBack').click();
      else N.App.exitApp();
    });
  }
}catch(e){}

// ---------- boot ----------
renderHome(); show('home');
Ads.init().finally(() => { if(cur !== 'game') Ads.showBanner(); try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} });
})();
