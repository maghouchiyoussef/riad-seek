// Idle Chef — restaurant idle tycoon
(function(){
'use strict';
const N = window.Native;
const $ = (s) => document.querySelector(s);

/* ---------- i18n ---------- */
const T = {
  en: {
    tapHint:'Tap to cook!', mile:'x2 @', perSec:'/s', chef:'Chef Skills', chefD:'per tap', lvl:'Lv', buy:'Buy',
    boost:'Boost x2', boostOn:'Boost active', boostMsg:'Income x2 for 2 minutes!',
    branch:'Branch', branchT:'Open a new branch', branchP:'Restart with a fresh restaurant and get a permanent bonus: every star gives +15% income.',
    branchGain:'Stars you will earn', branchNeed:'Earn more coins to unlock your first star.', branchGo:'Open branch', cancel:'Cancel',
    welcome:'Welcome back!', away:'Your restaurant earned while you were away:', collect:'Collect', collectX2:'Collect x2',
    vipMsg:'VIP customer tipped', settings:'Settings', lang:'Language', sound:'Sound', on:'On', off:'Off', privacy:'Ad choices', close:'Close',
    adNo:'Ad not ready, try again soon', next:'Next bonus', every:'x2 income at Lv', locked:'Unlock by upgrading the previous one', max:'MAX',
    done:'Done!', stars:'Stars', total:'Total bonus',
    names:['Sandwich Stand','Pizza Oven','Burger Grill','Sushi Bar','Steakhouse','Pastry Shop','Fine Dining','Restaurant Chain','Global Empire']
  },
  fr: {
    tapHint:'Touche pour cuisiner !', mile:'x2 @', perSec:'/s', chef:'Talent du chef', chefD:'par clic', lvl:'Niv', buy:'Acheter',
    boost:'Boost x2', boostOn:'Boost actif', boostMsg:'Revenus x2 pendant 2 minutes !',
    branch:'Succursale', branchT:'Ouvrir une succursale', branchP:'Recommence avec un nouveau restaurant et gagne un bonus permanent : chaque étoile donne +15 % de revenus.',
    branchGain:'Étoiles à gagner', branchNeed:'Gagne plus de pièces pour obtenir ta première étoile.', branchGo:'Ouvrir', cancel:'Annuler',
    welcome:'Bon retour !', away:'Ton restaurant a gagné pendant ton absence :', collect:'Récupérer', collectX2:'Récupérer x2',
    vipMsg:'Un client VIP a laissé', settings:'Réglages', lang:'Langue', sound:'Son', on:'Oui', off:'Non', privacy:'Choix pub', close:'Fermer',
    adNo:'Pub indisponible, réessaie bientôt', next:'Prochain bonus', every:'Revenus x2 au niv', locked:'Améliore le précédent pour débloquer', max:'MAX',
    done:'Fait !', stars:'Étoiles', total:'Bonus total',
    names:['Stand de sandwichs','Four à pizza','Grill à burgers','Bar à sushis','Steakhouse','Pâtisserie','Restaurant gastro','Chaîne de restaurants','Empire mondial']
  },
  ar: {
    tapHint:'المس لتطبخ!', mile:'x2 @', perSec:'/s', chef:'مهارة الشيف', chefD:'لكل لمسة', lvl:'مستوى', buy:'شراء',
    boost:'تسريع x2', boostOn:'التسريع يعمل', boostMsg:'الأرباح ×2 لمدة دقيقتين!',
    branch:'فرع جديد', branchT:'افتح فرعًا جديدًا', branchP:'ابدأ بمطعم جديد واحصل على مكافأة دائمة: كل نجمة تعطيك +15% أرباح.',
    branchGain:'النجوم التي ستحصل عليها', branchNeed:'اجمع نقودًا أكثر لتحصل على أول نجمة.', branchGo:'افتح الفرع', cancel:'إلغاء',
    welcome:'أهلاً بعودتك!', away:'مطعمك ربح أثناء غيابك:', collect:'استلام', collectX2:'استلام ×2',
    vipMsg:'زبون VIP ترك بقشيشًا', settings:'الإعدادات', lang:'اللغة', sound:'الصوت', on:'تشغيل', off:'إيقاف', privacy:'خيارات الإعلانات', close:'إغلاق',
    adNo:'الإعلان غير جاهز، جرّب بعد قليل', next:'المكافأة القادمة', every:'أرباح ×2 عند المستوى', locked:'طوّر السابق لفتح هذا', max:'الأقصى',
    done:'تم!', stars:'النجوم', total:'المكافأة الكلية',
    names:['كشك سندويشات','فرن البيتزا','شواية البرغر','بار السوشي','مطعم ستيك','محل حلويات','مطعم فاخر','سلسلة مطاعم','إمبراطورية عالمية']
  }
};
const LANGS = ['en','fr','ar'];
const LANG_NAME = { en:'English', fr:'Français', ar:'العربية' };

/* ---------- data ---------- */
const ST = [
  { icon:'🥪', cost:15,    inc:0.6,    r:1.15 },
  { icon:'🍕', cost:120,   inc:5,      r:1.15 },
  { icon:'🍔', cost:1300,  inc:32,     r:1.15 },
  { icon:'🍣', cost:14000, inc:190,    r:1.15 },
  { icon:'🥩', cost:160000,inc:1200,   r:1.15 },
  { icon:'🍰', cost:1.8e6, inc:8000,   r:1.15 },
  { icon:'🍽️', cost:2.4e7, inc:55000,  r:1.15 },
  { icon:'🏙️', cost:3.5e8, inc:4e5,    r:1.15 },
  { icon:'🌍', cost:5e9,   inc:3e6,    r:1.15 },
];
const MILES = [10,25,50,100,150,200,300,400,500];
const CHEF = { cost:25, r:1.27 };
const STAR_BONUS = 0.15;
const BOOST_SEC = 120;
const OFFLINE_CAP = 3 * 3600;

/* ---------- state ---------- */
let S = fresh();
function fresh(){ return { coins:0, run:0, lvl:ST.map(()=>0), chef:0, stars:0, boostEnd:0, last:Date.now(), sound:true, lang:null, buy:1 }; }
function load(){
  try{
    const raw = localStorage.getItem('chef_save');
    if(raw){
      const d = JSON.parse(raw);
      const f = fresh();
      S = Object.assign(f, d);
      if(!Array.isArray(S.lvl) || S.lvl.length !== ST.length){ const l = ST.map((_, i) => (d.lvl && +d.lvl[i]) || 0); S.lvl = l; }
      for(const k of ['coins','run','chef','stars','boostEnd','last']) if(!isFinite(S[k]) || S[k] < 0) S[k] = f[k];
    }
  }catch(e){ S = fresh(); }
}
function save(){ S.last = Date.now(); try{ localStorage.setItem('chef_save', JSON.stringify(S)); }catch(e){} }

let lang = 'en';
function detectLang(){
  if(S.lang && T[S.lang]) return S.lang;
  const n = (navigator.language || 'en').toLowerCase();
  if(n.startsWith('ar')) return 'ar';
  if(n.startsWith('fr')) return 'fr';
  return 'en';
}
const t = (k) => T[lang][k];

/* ---------- math ---------- */
const SUF = ['','K','M','B','T','Qa','Qi','Sx','Sp','Oc','No','Dc'];
function fmt(n){
  if(!isFinite(n)) return '∞';
  if(n < 1000) return n < 10 && n % 1 ? n.toFixed(1).replace(/\.0$/,'') : Math.floor(n).toString();
  const e = Math.min(Math.floor(Math.log10(n) / 3), SUF.length - 1);
  const v = n / Math.pow(10, e * 3);
  return (v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2)).replace(/\.?0+$/,'') + SUF[e];
}
const gm = () => 1 + STAR_BONUS * S.stars;
const boosted = () => S.boostEnd > Date.now();
function mileMult(i){ let m = 1; for(const L of MILES) if(S.lvl[i] >= L) m *= 2; return m; }
function stIps(i){ return ST[i].inc * S.lvl[i] * mileMult(i); }
function ips(){ let s = 0; for(let i = 0; i < ST.length; i++) s += stIps(i); return s * gm() * (boosted() ? 2 : 1); }
function tapVal(){ return ((1 + S.chef) * gm() + ips() * 0.03) * (boosted() ? 2 : 1); }
function costN(base, r, lvl, n){ return base * Math.pow(r, lvl) * (Math.pow(r, n) - 1) / (r - 1); }
function maxN(base, r, lvl, coins){
  let n = Math.floor(Math.log(coins * (r - 1) / (base * Math.pow(r, lvl)) + 1) / Math.log(r));
  if(!isFinite(n) || n < 0) n = 0;
  n = Math.min(n, 1000);
  while(n > 0 && costN(base, r, lvl, n) > coins) n--;
  return n;
}
function plan(base, r, lvl){
  let n = S.buy === 0 ? maxN(base, r, lvl, S.coins) : S.buy;
  if(S.buy === 0 && n < 1) n = 1;
  return { n, cost: costN(base, r, lvl, n) };
}
function starsAvail(){ return Math.floor(Math.sqrt(S.run / 1e6)); }

/* ---------- audio / haptics ---------- */
let actx = null;
function beep(f, d, type, vol){
  if(!S.sound) return;
  try{
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    if(actx.state === 'suspended') actx.resume();
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'sine'; o.frequency.value = f;
    g.gain.setValueAtTime(vol || 0.08, actx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + d);
    o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + d);
  }catch(e){}
}
function hap(kind){
  try{
    if(!N || !N.isNative) return;
    if(kind === 'ok') N.Haptics.notification({ type: N.NotificationType.Success });
    else N.Haptics.impact({ style: kind === 'big' ? N.ImpactStyle.Medium : N.ImpactStyle.Light });
  }catch(e){}
}
function toast(msg){
  const el = $('#toast'); el.textContent = msg; el.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('show'), 2200);
}

/* ---------- UI build ---------- */
const cards = [];
function buildList(){
  const list = $('#list'); list.innerHTML = '';
  cards.length = 0;
  const mk = (icon) => {
    const c = document.createElement('div'); c.className = 'card';
    c.innerHTML = '<div class="ic"></div><div class="inf"><div class="nm"></div><div class="ds"></div><div class="bar"><i></i></div></div><button class="buy"><span></span><small></small></button>';
    c.querySelector('.ic').textContent = icon;
    list.appendChild(c);
    return { el:c, nm:c.querySelector('.nm'), ds:c.querySelector('.ds'), bar:c.querySelector('.bar i'), btn:c.querySelector('.buy'), b1:c.querySelector('.buy span'), b2:c.querySelector('.buy small') };
  };
  const chef = mk('👨‍🍳'); chef.kind = 'chef'; chef.btn.onclick = () => buyChef(); cards.push(chef);
  ST.forEach((s, i) => { const c = mk(s.icon); c.kind = 'st'; c.i = i; c.btn.onclick = () => buySt(i); cards.push(c); });
}
function applyLang(){
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  $('#bboostl').textContent = t('boost');
  $('#bstarl').textContent = t('branch');
  $('#bsetl').textContent = t('settings');
  $('#viplbl').textContent = 'VIP';
  document.title = 'Idle Chef';
  refresh(true);
}

function refresh(force){
  $('#coins').textContent = fmt(S.coins);
  const I = ips();
  $('#ips').textContent = fmt(I) + ' ' + t('perSec');
  $('#stars').textContent = '⭐ ' + S.stars;
  $('#gm').textContent = 'x' + (Math.round(gm() * 100) / 100);
  const bc = $('#boostchip');
  if(boosted()){
    const s = Math.ceil((S.boostEnd - Date.now()) / 1000);
    bc.style.display = ''; bc.textContent = '⚡ x2 ' + Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  } else bc.style.display = 'none';
  $('#bbuyl').textContent = S.buy === 0 ? 'MAX' : 'x' + S.buy;
  $('#bstar').classList.toggle('dis', starsAvail() < 1);

  // chef card
  const ch = cards[0];
  const pc = plan(CHEF.cost, CHEF.r, S.chef);
  ch.nm.textContent = t('chef');
  ch.ds.textContent = t('lvl') + ' ' + S.chef + ' · ' + t('chefD') + ': +' + fmt(tapVal());
  ch.bar.style.width = '0%'; ch.bar.parentElement.style.display = 'none';
  ch.b1.textContent = '💰 ' + fmt(pc.cost); ch.b2.textContent = t('buy') + (pc.n > 1 ? ' x' + pc.n : '');
  ch.btn.classList.toggle('ok', S.coins >= pc.cost);

  // stations
  let unlockedNext = false;
  for(let i = 0; i < ST.length; i++){
    const c = cards[i + 1];
    const owned = S.lvl[i] > 0;
    const prevOk = i === 0 || S.lvl[i - 1] > 0;
    const visible = owned || prevOk;
    c.el.style.display = visible ? '' : 'none';
    if(!visible) continue;
    const p = plan(ST[i].cost, ST[i].r, S.lvl[i]);
    c.el.classList.toggle('lock', !owned && S.coins < ST[i].cost);
    c.nm.textContent = t('names')[i];
    let nextM = MILES.find(L => L > S.lvl[i]);
    const per = ST[i].inc * mileMult(i) * gm() * (boosted() ? 2 : 1);
    c.ds.textContent = owned ? (t('lvl') + ' ' + S.lvl[i] + ' · +' + fmt(stIps(i) * gm() * (boosted() ? 2 : 1)) + ' ' + t('perSec') + (nextM ? '  ·  ' + t('mile') + ' ' + nextM : '')) : ('+' + fmt(per) + ' ' + t('perSec'));
    if(nextM){
      const prev = [0].concat(MILES).filter(L => L <= S.lvl[i]).pop();
      c.bar.style.width = Math.min(100, (S.lvl[i] - prev) / (nextM - prev) * 100) + '%';
      c.bar.parentElement.style.display = '';
    } else { c.bar.style.width = '100%'; }
    c.b1.textContent = '💰 ' + fmt(p.cost); c.b2.textContent = (owned ? t('buy') : t('buy')) + (p.n > 1 ? ' x' + p.n : '');
    c.btn.classList.toggle('ok', S.coins >= p.cost);
  }
}

/* ---------- actions ---------- */
function earn(n){ S.coins += n; S.run += n; }
function buySt(i){
  const p = plan(ST[i].cost, ST[i].r, S.lvl[i]);
  if(S.coins < p.cost){ beep(150, .12, 'square', .05); return; }
  S.coins -= p.cost; S.lvl[i] += p.n;
  beep(660, .12, 'triangle'); beep(880, .15, 'triangle', .06); hap('light'); refresh(); save();
}
function buyChef(){
  const p = plan(CHEF.cost, CHEF.r, S.chef);
  if(S.coins < p.cost){ beep(150, .12, 'square', .05); return; }
  S.coins -= p.cost; S.chef += p.n;
  beep(520, .1, 'triangle'); hap('light'); refresh(); save();
}
function doTap(x, y){
  const v = tapVal(); earn(v);
  beep(380 + Math.random() * 120, .06, 'triangle', .05); hap('light');
  const w = $('#tapwrap'); const f = document.createElement('div'); f.className = 'fl';
  f.textContent = '+' + fmt(v);
  const r = w.getBoundingClientRect();
  f.style.left = Math.max(10, Math.min(r.width - 60, x - r.left - 20 + (Math.random() * 40 - 20))) + 'px';
  f.style.top = Math.max(0, y - r.top - 30) + 'px';
  w.appendChild(f); setTimeout(() => f.remove(), 900);
  refresh();
}

/* rewarded */
async function reward(){
  if(!Ads.isNative) return true; // web preview only
  if(!Ads.rewardedAvailable()){ toast(t('adNo')); return false; }
  const ok = await Ads.showRewarded();
  return !!ok;
}
async function doBoost(){
  const ok = await reward();
  if(!ok) return;
  S.boostEnd = Math.max(Date.now(), S.boostEnd) + BOOST_SEC * 1000;
  beep(880, .2, 'sine', .1); hap('ok'); toast(t('boostMsg')); refresh(); save();
}

/* modal */
const modal = $('#modal');
let modalOpen = false;
function showModal(html, bind){
  modal.innerHTML = '<div class="box">' + html + '</div>';
  modal.classList.add('show'); modalOpen = true;
  if(bind) bind(modal);
}
function closeModal(){ modal.classList.remove('show'); modal.innerHTML = ''; modalOpen = false; }

let sessionStart = Date.now();
function interstitialOk(){ return Date.now() - sessionStart > 150000; }
function maybeAd(){ if(interstitialOk()) Ads.maybeInterstitial(); }

function showSettings(){
  showModal(
    '<h2>' + t('settings') + '</h2>' +
    '<p>' + t('lang') + '</p><div class="row" id="lr"></div>' +
    '<p>' + t('sound') + '</p><div class="row"><button class="mb alt" id="snd">' + (S.sound ? '🔊 ' + t('on') : '🔇 ' + t('off')) + '</button></div>' +
    (Ads.privacyRequired ? '<button class="mb alt" id="prv">🔒 ' + t('privacy') + '</button>' : '') +
    '<button class="mb" id="cl">' + t('close') + '</button>',
    (m) => {
      const lr = m.querySelector('#lr');
      LANGS.forEach(L => {
        const b = document.createElement('button'); b.className = 'mb alt' + (L === lang ? ' sel' : ''); b.textContent = LANG_NAME[L];
        b.onclick = () => { lang = L; S.lang = L; save(); applyLang(); showSettings(); };
        lr.appendChild(b);
      });
      m.querySelector('#snd').onclick = () => { S.sound = !S.sound; save(); showSettings(); };
      const p = m.querySelector('#prv'); if(p) p.onclick = () => Ads.showPrivacyOptions();
      m.querySelector('#cl').onclick = closeModal;
    });
}
function showBranch(){
  const n = starsAvail();
  if(n < 1){
    showModal('<h2>⭐ ' + t('branchT') + '</h2><p>' + t('branchP') + '</p><p>' + t('branchNeed') + '</p><button class="mb" id="cl">' + t('close') + '</button>',
      (m) => { m.querySelector('#cl').onclick = closeModal; });
    return;
  }
  showModal('<h2>⭐ ' + t('branchT') + '</h2><p>' + t('branchP') + '</p><p>' + t('branchGain') + '</p><div class="big">+' + n + ' ⭐</div><p>' + t('total') + ': x' + (Math.round((1 + STAR_BONUS * (S.stars + n)) * 100) / 100) + '</p>' +
    '<button class="mb ad" id="go">' + t('branchGo') + '</button><button class="mb alt" id="cl">' + t('cancel') + '</button>',
    (m) => {
      m.querySelector('#cl').onclick = closeModal;
      m.querySelector('#go').onclick = () => {
        const g = starsAvail(); if(g < 1) return closeModal();
        S.stars += g; S.coins = 0; S.run = 0; S.lvl = ST.map(() => 0); S.chef = 0;
        beep(520, .15, 'triangle'); beep(780, .2, 'triangle'); beep(1040, .3, 'triangle'); hap('ok');
        closeModal(); refresh(); save(); maybeAd();
      };
    });
}
function showOffline(gain){
  showModal('<h2>' + t('welcome') + '</h2><p>' + t('away') + '</p><div class="big">💰 ' + fmt(gain) + '</div>' +
    '<button class="mb ad" id="x2">🎬 ' + t('collectX2') + '</button><button class="mb" id="c1">' + t('collect') + '</button>',
    (m) => {
      m.querySelector('#c1').onclick = () => { earn(gain); closeModal(); refresh(); save(); maybeAd(); };
      m.querySelector('#x2').onclick = async () => {
        const ok = await reward(); if(!ok) return;
        earn(gain * 2); beep(880, .2); hap('ok'); closeModal(); refresh(); save();
      };
    });
}

/* VIP customer */
let vipTimer = 0;
function scheduleVip(){ clearTimeout(vipTimer); vipTimer = setTimeout(spawnVip, 35000 + Math.random() * 45000); }
function spawnVip(){
  const v = $('#vip'), w = $('#tapwrap');
  if(modalOpen || ips() <= 0){ scheduleVip(); return; }
  const side = Math.random() < 0.5;
  v.style.left = side ? '8%' : 'auto'; v.style.right = side ? 'auto' : '8%';
  v.style.top = (10 + Math.random() * 40) + '%';
  v.style.display = 'block';
  clearTimeout(spawnVip.hide);
  spawnVip.hide = setTimeout(() => { v.style.display = 'none'; scheduleVip(); }, 9000);
}
$('#vip').onclick = () => {
  $('#vip').style.display = 'none';
  const g = Math.max(ips() * 45, tapVal() * 20); earn(g);
  beep(990, .25, 'sine', .1); hap('ok'); toast('🤵 ' + t('vipMsg') + ' 💰 ' + fmt(g)); refresh(); save();
  clearTimeout(spawnVip.hide); scheduleVip();
};

/* ---------- wiring ---------- */
const tap = $('#tap');
tap.addEventListener('pointerdown', (e) => { e.preventDefault(); tap.classList.add('p'); doTap(e.clientX, e.clientY); });
['pointerup','pointercancel','pointerleave'].forEach(ev => tap.addEventListener(ev, () => tap.classList.remove('p')));
tap.addEventListener('contextmenu', e => e.preventDefault());
$('#bbuy').onclick = () => { S.buy = S.buy === 1 ? 10 : S.buy === 10 ? 100 : S.buy === 100 ? 0 : 1; hap('light'); refresh(); save(); };
$('#bboost').onclick = doBoost;
$('#bstar').onclick = showBranch;
$('#bset').onclick = showSettings;

/* loop */
let lastTick = Date.now();
setInterval(() => {
  const now = Date.now(); let dt = (now - lastTick) / 1000; lastTick = now;
  if(dt > 5) dt = 0.1;
  earn(ips() * dt);
  refresh();
}, 100);
setInterval(save, 5000);
document.addEventListener('visibilitychange', () => { if(document.hidden) save(); else lastTick = Date.now(); });

/* android back */
try{ N.App.addListener('backButton', () => {
  if(modalOpen){ closeModal(); return; }
  save(); N.App.exitApp();
}); }catch(e){}
try{
  N.App.addListener('pause', () => { save(); if(actx) actx.suspend(); });
  N.App.addListener('resume', () => {
    if(actx) actx.resume();
    const away = Math.min((Date.now() - S.last) / 1000, OFFLINE_CAP);
    lastTick = Date.now();
    if(away > 90 && ips() > 0 && !modalOpen) showOffline(ips() * away);
  });
}catch(e){}

/* start */
load();
lang = detectLang();
buildList(); applyLang();
{
  const away = Math.min((Date.now() - (S.last || Date.now())) / 1000, OFFLINE_CAP);
  if(away > 90 && ips() > 0) showOffline(ips() * away);
}
S.last = Date.now(); lastTick = Date.now();
scheduleVip();
try{ N && N.isNative && N.StatusBar.setStyle({ style: N.Style.Dark }); }catch(e){}
try{ N && N.isNative && N.StatusBar.setBackgroundColor({ color: '#3a1d12' }); }catch(e){}
Ads.init().finally(() => { Ads.showBanner(); try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} });
setTimeout(() => { try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){} }, 2500);
window.__chef = { S: () => S, ips, fmt, buySt, doTap, showBranch, showSettings, setLang: (l) => { lang = l; applyLang(); }, earn };
})();
