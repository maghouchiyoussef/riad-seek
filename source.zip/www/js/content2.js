window.CH = window.CH || [];
CH.push(
{ id:'lut', icon:'🌙', c1:'#5b4b9a', c2:'#2f2566', name:['Lut (Lot)','لوط'],
  story:[
   ['Lut was sent to a town whose people did shameful things that no one before them had done. He warned them to stop.','أُرسل لوط إلى قوم يفعلون فاحشة لم يسبقهم بها أحد، فنهاهم ونصحهم.'],
   ['They refused to listen and even threatened to drive him out of the town.','لم يسمعوا له وهددوه بإخراجه من القرية.'],
   ['Angels came to Lut as guests and told him to leave at night with his family. They told him not to look back.','جاءت الملائكة إلى لوط وأمرته أن يخرج بأهله ليلًا ولا يلتفت أحد منهم.'],
   ['The town was destroyed. Lut and his believing family were saved, but his wife was not, because she stayed with the wrongdoers.','دُمّرت القرية، ونجا لوط وأهله المؤمنون إلا امرأته لأنها كانت مع الظالمين.']],
  qs:[
   {q:['Who came to Lut as guests?','من جاء ضيوفًا إلى لوط؟'],o:[['Angels','الملائكة'],['Kings','ملوك'],['Merchants','تجار'],['Soldiers','جنود']],c:0},
   {q:['When did Lut leave the town?','متى خرج لوط من القرية؟'],o:[['At night','ليلًا'],['At noon','ظهرًا'],['At dawn after a week','بعد أسبوع'],['He stayed','بقي']],c:0},
   {q:['What was Lut told not to do while leaving?','عن ماذا نُهوا أثناء الخروج؟'],o:[['Look back','الالتفات'],['Run','الركض'],['Talk','الكلام'],['Eat','الأكل']],c:0},
   {q:['Who was not saved from his family?','من لم ينجُ من أهله؟'],o:[['His wife','امرأته'],['His daughters','بناته'],['His son','ابنه'],['His brother','أخوه']],c:0},
   {q:['What did Lut do for his people?','ماذا فعل لوط لقومه؟'],o:[['Warned and advised them','حذّرهم ونصحهم'],['Ignored them','تجاهلهم'],['Joined them','انضم إليهم'],['Mocked them','سخر منهم']],c:0}]},

{ id:'ismail', icon:'💧', c1:'#0f8b8d', c2:'#075457', name:['Ismail (Ishmael)','إسماعيل'],
  story:[
   ['By Allah\'s command, Ibrahim left his wife Hajar and baby Ismail in the empty valley of Makkah. Hajar trusted that Allah would not let them down.','بأمر الله ترك إبراهيم زوجه هاجر وطفلهما إسماعيل في وادي مكة الخالي، وكانت هاجر واثقة أن الله لن يضيعهم.'],
   ['Hajar ran seven times between the hills of Safa and Marwa, looking for water.','سعت هاجر سبع مرات بين الصفا والمروة تبحث عن الماء.'],
   ['Then water gushed out near the baby. This is the well of Zamzam, which still flows today.','فانبثق الماء قرب الطفل، وهو بئر زمزم الذي ما زال يجري إلى اليوم.'],
   ['When Ismail grew up, he was patient and truthful to his promises. He helped his father build the Kaaba.','ولما كبر كان صابرًا صادق الوعد، وساعد أباه في بناء الكعبة.']],
  qs:[
   {q:['Who was Ismail\'s mother?','من هي أم إسماعيل؟'],o:[['Hajar','هاجر'],['Maryam','مريم'],['Asiya','آسية'],['Khadija','خديجة']],c:0},
   {q:['Which two hills did Hajar run between?','بين أي جبلين سعت هاجر؟'],o:[['Safa and Marwa','الصفا والمروة'],['Uhud and Hira','أحد وحراء'],['Judi and Tur','الجودي والطور'],['Arafat and Mina','عرفات ومنى']],c:0},
   {q:['How many times did she run?','كم مرة سعت؟'],o:[['Seven','سبع'],['Three','ثلاث'],['Ten','عشر'],['Five','خمس']],c:0},
   {q:['Which well appeared for them?','أي بئر ظهرت لهما؟'],o:[['Zamzam','زمزم'],['Badr','بدر'],['Rumah','رومة'],['Yusuf\'s well','بئر يوسف']],c:0},
   {q:['What did Ismail help build?','ماذا ساعد إسماعيل في بنائه؟'],o:[['The Kaaba','الكعبة'],['A palace','قصرًا'],['The ark','السفينة'],['A city wall','سور مدينة']],c:0}]},

{ id:'yaqub', icon:'🌟', c1:'#b8860b', c2:'#6e4f00', name:['Yaqub (Jacob)','يعقوب'],
  story:[
   ['Yaqub was the son of Ishaq and the grandson of Ibrahim. He had twelve sons and loved them dearly.','يعقوب ابن إسحاق وحفيد إبراهيم، وكان له اثنا عشر ولدًا يحبهم كثيرًا.'],
   ['When his son Yusuf was lost, he was very sad. But he said, "Beautiful patience is best."','لما فُقد ابنه يوسف حزن حزنًا شديدًا، لكنه قال: فصبر جميل.'],
   ['He never lost hope in Allah. He told his sons to go and search for Yusuf and his brother.','لم ييأس من رحمة الله، وأمر أبناءه أن يذهبوا ويبحثوا عن يوسف وأخيه.'],
   ['Years later, Yusuf\'s shirt was placed on his face, and his sight returned. The family was finally reunited.','وبعد سنين وُضع قميص يوسف على وجهه فعاد إليه بصره، واجتمع شمل الأسرة.']],
  qs:[
   {q:['How many sons did Yaqub have?','كم ولدًا كان ليعقوب؟'],o:[['Twelve','اثنا عشر'],['Three','ثلاثة'],['Seven','سبعة'],['Twenty','عشرون']],c:0},
   {q:['Which son did he lose?','أي أبنائه فقد؟'],o:[['Yusuf','يوسف'],['Ismail','إسماعيل'],['Harun','هارون'],['Dawud','داود']],c:0},
   {q:['What did Yaqub say about his sadness?','ماذا قال يعقوب في حزنه؟'],o:[['Beautiful patience is best','فصبر جميل'],['I give up','يئست'],['Nothing helps','لا فائدة'],['Blame them','ألومهم']],c:0},
   {q:['What brought back his sight?','ما الذي أعاد إليه بصره؟'],o:[['Yusuf\'s shirt','قميص يوسف'],['A medicine','دواء'],['Zamzam water','ماء زمزم'],['A staff','عصا']],c:0},
   {q:['Who was Yaqub\'s grandfather?','من جد يعقوب؟'],o:[['Ibrahim','إبراهيم'],['Nuh','نوح'],['Adam','آدم'],['Musa','موسى']],c:0}]},

{ id:'yusuf', icon:'👑', c1:'#c2410c', c2:'#7c2d12', name:['Yusuf (Joseph)','يوسف'],
  story:[
   ['Yusuf dreamed of eleven stars, the sun and the moon bowing to him. His father told him to keep it secret from his brothers.','رأى يوسف في منامه أحد عشر كوكبًا والشمس والقمر ساجدين له، فنصحه أبوه ألا يخبر إخوته.'],
   ['His brothers became jealous and threw him into a well. A caravan found him and sold him in Egypt.','غار إخوته منه فألقوه في البئر، فالتقطته قافلة وباعوه في مصر.'],
   ['He stayed honest and patient, even when he was falsely accused and put in prison. There he explained people\'s dreams.','بقي أمينًا صابرًا حتى حين اتُّهم ظلمًا وسُجن، وهناك فسّر أحلام الناس.'],
   ['He explained the king\'s dream about seven years of plenty and seven of famine. He was put in charge of the storehouses, and he forgave his brothers.','فسّر حلم الملك عن سبع سنين رخاء وسبع جدب، فجُعل على خزائن الأرض، وعفا عن إخوته.']],
  qs:[
   {q:['What did Yusuf see in his dream?','ماذا رأى يوسف في منامه؟'],o:[['Eleven stars, sun and moon','أحد عشر كوكبًا والشمس والقمر'],['A flood','طوفانًا'],['A fire','نارًا'],['A lion','أسدًا']],c:0},
   {q:['Where did his brothers throw him?','أين ألقاه إخوته؟'],o:[['Into a well','في البئر'],['Into the sea','في البحر'],['Into a cave','في كهف'],['Into a river','في نهر']],c:0},
   {q:['In which country was he sold?','في أي بلد بيع؟'],o:[['Egypt','مصر'],['Iraq','العراق'],['Yemen','اليمن'],['Syria','الشام']],c:0},
   {q:['What did the king\'s dream warn about?','عمّ حذّر حلم الملك؟'],o:[['Years of plenty then famine','سنوات رخاء ثم جدب'],['A war','حربًا'],['A flood','طوفانًا'],['An earthquake','زلزالًا']],c:0},
   {q:['How did Yusuf treat his brothers in the end?','كيف عامل يوسف إخوته في النهاية؟'],o:[['He forgave them','عفا عنهم'],['He punished them','عاقبهم'],['He ignored them','تجاهلهم'],['He sent them away','طردهم']],c:0}]},

{ id:'ayyub', icon:'🌿', c1:'#3f7d58', c2:'#1d4d33', name:['Ayyub (Job)','أيوب'],
  story:[
   ['Ayyub was a good and thankful servant of Allah. He had health, wealth and a loving family.','كان أيوب عبدًا صالحًا شاكرًا لله، أعطاه الله الصحة والمال والأهل.'],
   ['Allah tested him with illness and loss for many years. He never complained against Allah.','ابتلاه الله بالمرض وفقد الكثير سنوات طويلة، ولم يشتكِ من قضاء الله.'],
   ['He called on his Lord: "Hardship has touched me, and You are the Most Merciful of the merciful."','دعا ربه: أني مسني الضر وأنت أرحم الراحمين.'],
   ['Allah told him to strike the ground with his foot. A spring came out to drink and wash, and he was healed.','فأمره الله أن يضرب الأرض برجله، فنبع ماء يغتسل ويشرب منه فشُفي، وعوّضه الله خيرًا.']],
  qs:[
   {q:['What is Ayyub known for?','بماذا اشتُهر أيوب؟'],o:[['Patience','الصبر'],['Building','البناء'],['Travelling','السفر'],['Fighting','القتال']],c:0},
   {q:['How was Ayyub tested?','بماذا ابتُلي أيوب؟'],o:[['Illness and loss','المرض وفقد الأموال'],['Prison','السجن'],['Exile','النفي'],['Hunger only','الجوع فقط']],c:0},
   {q:['How did he ask Allah for help?','كيف طلب العون من الله؟'],o:[['By calling on Him with humility','بالدعاء بتواضع'],['By complaining to people','بالشكوى للناس'],['By staying silent','بالصمت'],['By running away','بالهرب']],c:0},
   {q:['What came out when he struck the ground?','ماذا خرج حين ضرب الأرض؟'],o:[['A spring of water','عين ماء'],['Gold','ذهب'],['A tree','شجرة'],['Fire','نار']],c:0},
   {q:['What was the result of his patience?','ما نتيجة صبره؟'],o:[['Allah healed him','شفاه الله'],['He lost more','خسر أكثر'],['He left his home','هجر بيته'],['Nothing changed','لم يتغير شيء']],c:0}]},

{ id:'shuayb', icon:'⚖️', c1:'#4a6fa5', c2:'#26426e', name:['Shuayb','شعيب'],
  story:[
   ['The people of Madyan cheated in trade. They gave less than the full weight and measure.','كان أهل مدين يغشّون في التجارة، فيُنقصون المكيال والميزان.'],
   ['Shuayb told them: "Give full measure and weight, and do not cheat people of their goods."','قال لهم شعيب: أوفوا الكيل والميزان ولا تبخسوا الناس أشياءهم.'],
   ['Some leaders said, "Do you want us to leave what our fathers worshipped?" and they refused to change.','قال بعض كبرائهم: أتأمرنا أن نترك ما يعبد آباؤنا؟ ولم يتغيروا.'],
   ['A violent earthquake struck them. Shuayb and the believers were saved.','فأخذتهم الرجفة، ونجّى الله شعيبًا والذين آمنوا معه.']],
  qs:[
   {q:['Which people was Shuayb sent to?','إلى أي قوم أُرسل شعيب؟'],o:[['Madyan','مدين'],['Ad','عاد'],['Thamud','ثمود'],['Saba','سبأ']],c:0},
   {q:['What was their main wrong?','ما خطؤهم الأكبر؟'],o:[['Cheating in weights and measures','الغش في الكيل والميزان'],['Stealing animals','سرقة المواشي'],['Not farming','ترك الزراعة'],['Wasting water','إضاعة الماء']],c:0},
   {q:['What did Shuayb tell them to do?','ماذا أمرهم شعيب؟'],o:[['Be fair and honest','العدل والأمانة'],['Leave the town','ترك البلد'],['Stop trading','ترك التجارة'],['Give all money away','التصدق بكل المال']],c:0},
   {q:['What struck them?','ماذا أصابهم؟'],o:[['An earthquake','رجفة'],['A flood','طوفان'],['A snow storm','ثلج'],['A plague of locusts','جراد']],c:0},
   {q:['Which value does this story teach?','أي قيمة تعلمها القصة؟'],o:[['Honesty in business','الأمانة في التجارة'],['Speed','السرعة'],['Wealth','الثراء'],['Silence','الصمت']],c:0}]}
);
