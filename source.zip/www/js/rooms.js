// رسم الغرف حسب الديكور اللي تدار (المشهد 400×300)
(function(){
'use strict';
const TAU = Math.PI * 2;
function rr(g, x, y, w, h, r){ g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
function lin(g, x0, y0, x1, y1, stops){ const gr = g.createLinearGradient(x0, y0, x1, y1); stops.forEach(([o, c]) => gr.addColorStop(o, c)); return gr; }
const art = (g, i, x, y, s) => { g.save(); g.translate(x, y); Art.draw(g, i, s); g.restore(); };

// ---------- المجلس ----------
function majlis(g, d){
  // الجدار والأرضية
  g.fillStyle = lin(g, 0, 0, 0, 190, [[0, '#f3e3c3'], [1, '#e6cfa1']]); g.fillRect(0, 0, 400, 190);
  g.fillStyle = lin(g, 0, 190, 0, 300, [[0, '#d9b98a'], [1, '#c39a64']]); g.fillRect(0, 190, 400, 110);
  g.fillStyle = 'rgba(0,0,0,.08)'; g.fillRect(0, 186, 400, 6);
  // نافذة مقوسة
  g.fillStyle = '#9fd3e8'; g.strokeStyle = '#8a6a3a'; g.lineWidth = 5;
  g.beginPath(); g.moveTo(170, 140); g.lineTo(170, 70); g.arc(200, 70, 30, Math.PI, 0); g.lineTo(230, 140); g.closePath(); g.fill(); g.stroke();
  g.beginPath(); g.moveTo(200, 40); g.lineTo(200, 140); g.moveTo(170, 95); g.lineTo(230, 95); g.stroke();
  if(d.wall){
    g.strokeStyle = 'rgba(31,106,99,.5)'; g.lineWidth = 3;
    for(let x = 10; x < 400; x += 40){ g.beginPath(); g.moveTo(x, 20); g.lineTo(x + 20, 8); g.lineTo(x + 40, 20); g.stroke(); }
    g.fillStyle = '#1f6a63'; g.fillRect(0, 26, 400, 5); g.fillStyle = '#e8b84a'; g.fillRect(0, 31, 400, 3);
    g.fillStyle = 'rgba(31,106,99,.25)'; for(let x = 20; x < 400; x += 40){ g.beginPath(); g.arc(x, 176, 5, 0, TAU); g.fill(); }
  }
  if(d.curtain){
    [[132, 1], [268, -1]].forEach(([x, s]) => {
      g.fillStyle = lin(g, x - 30, 0, x + 30, 0, [[0, '#8e2160'], [.5, '#c23a7c'], [1, '#7a1f52']]);
      g.beginPath(); g.moveTo(x - 32 * s, 34); g.lineTo(x + 30 * s, 34); g.quadraticCurveTo(x + 6 * s, 100, x + 22 * s, 168); g.lineTo(x - 32 * s, 168); g.closePath(); g.fill();
      g.fillStyle = '#e8b84a'; g.fillRect(x - 32 * s - (s < 0 ? 0 : 0), 34, 62 * s, 4);
    });
  }
  if(d.carpet){
    g.fillStyle = '#9a1f2e'; g.beginPath(); g.moveTo(70, 205); g.lineTo(330, 205); g.lineTo(380, 290); g.lineTo(20, 290); g.closePath(); g.fill();
    g.strokeStyle = '#e8b84a'; g.lineWidth = 4; g.beginPath(); g.moveTo(84, 212); g.lineTo(316, 212); g.lineTo(358, 282); g.lineTo(42, 282); g.closePath(); g.stroke();
    g.fillStyle = '#1f6a63'; for(let i = 0; i < 5; i++){ const x = 110 + i * 45; g.beginPath(); g.moveTo(x, 235); g.lineTo(x + 12, 248); g.lineTo(x, 261); g.lineTo(x - 12, 248); g.closePath(); g.fill(); }
  }
  if(d.seats){
    [[10, 150, 120], [270, 150, 120]].forEach(([x, y, w]) => {
      g.fillStyle = '#7a1f52'; rr(g, x, y + 30, w, 28, 8); g.fill();
      g.fillStyle = lin(g, 0, y, 0, y + 34, [[0, '#d64a86'], [1, '#a8306f']]); rr(g, x, y, w, 36, 10); g.fill();
      g.fillStyle = '#e8b84a'; g.fillRect(x + 4, y + 30, w - 8, 3);
    });
  }
  if(d.cushions){
    [[30, 146], [70, 146], [290, 146], [330, 146]].forEach(([x, y]) => {
      g.fillStyle = lin(g, x, y, x + 34, y + 30, [[0, '#3fb3a3'], [1, '#1f6a63']]); rr(g, x, y - 18, 34, 30, 9); g.fill();
      g.strokeStyle = '#e8b84a'; g.lineWidth = 2; g.stroke();
    });
  }
  if(d.table){
    g.fillStyle = '#6a3a12'; g.fillRect(150, 236, 8, 26); g.fillRect(242, 236, 8, 26);
    g.fillStyle = lin(g, 140, 0, 260, 0, [[0, '#8a5a24'], [.5, '#c08a4a'], [1, '#7a4a18']]); rr(g, 136, 226, 128, 14, 5); g.fill();
    art(g, 2, 178, 200, 46); art(g, 6, 220, 214, 26); art(g, 6, 244, 214, 24);
  }
  if(d.lantern){
    g.strokeStyle = '#6a4a20'; g.lineWidth = 2; g.beginPath(); g.moveTo(200, 0); g.lineTo(200, 20); g.stroke();
    art(g, 9, 200, 44, 56);
    const gl = g.createRadialGradient(200, 50, 4, 200, 50, 60); gl.addColorStop(0, 'rgba(255,220,120,.45)'); gl.addColorStop(1, 'rgba(255,220,120,0)');
    g.fillStyle = gl; g.beginPath(); g.arc(200, 50, 60, 0, TAU); g.fill();
  }
  if(d.incense){
    g.fillStyle = '#6a3a12'; rr(g, 340, 176, 44, 30, 4); g.fill();
    art(g, 7, 362, 158, 42); art(g, 3, 380, 168, 22);
  }
}

// ---------- المطبخ ----------
function kitchen(g, d){
  g.fillStyle = lin(g, 0, 0, 0, 200, [[0, '#f6ead6'], [1, '#ead6b4']]); g.fillRect(0, 0, 400, 200);
  g.fillStyle = '#c9a77a'; g.fillRect(0, 200, 400, 100);
  if(d.floor){
    for(let y = 200; y < 300; y += 25) for(let x = (y / 25 % 2) * 25; x < 400; x += 50){ g.fillStyle = '#2a8a7e'; g.fillRect(x, y, 25, 25); g.fillStyle = '#f2ecdf'; g.fillRect(x + 25, y, 25, 25); }
  }
  if(d.window){
    g.fillStyle = '#a8dcef'; g.strokeStyle = '#7a5a2a'; g.lineWidth = 5;
    g.beginPath(); g.rect(160, 34, 80, 70); g.fill(); g.stroke();
    g.beginPath(); g.moveTo(200, 34); g.lineTo(200, 104); g.moveTo(160, 69); g.lineTo(240, 69); g.stroke();
    art(g, 10, 222, 82, 34);
  }
  if(d.counter){
    g.fillStyle = '#7a4e2a'; g.fillRect(0, 150, 400, 56);
    g.fillStyle = '#5a3418'; for(let x = 10; x < 400; x += 80){ g.fillRect(x, 160, 64, 40); g.fillStyle = '#e8b84a'; g.fillRect(x + 28, 176, 8, 3); g.fillStyle = '#5a3418'; }
    g.fillStyle = lin(g, 0, 140, 0, 152, [[0, '#ffffff'], [1, '#d9d6cf']]); g.fillRect(0, 140, 400, 12);
  }
  if(d.shelf){
    g.fillStyle = '#8a5a24'; g.fillRect(20, 60, 120, 8); g.fillRect(260, 60, 120, 8);
    art(g, 6, 40, 46, 26); art(g, 6, 66, 46, 26); art(g, 2, 110, 38, 36);
  }
  if(d.pots){
    [[290, 44, 26], [330, 42, 30], [366, 46, 22]].forEach(([x, y, r]) => {
      g.fillStyle = lin(g, x - r, 0, x + r, 0, [[0, '#9a4a1a'], [.4, '#f2a060'], [1, '#8a3a10']]);
      g.beginPath(); g.ellipse(x, y, r * .6, r * .5, 0, 0, TAU); g.fill(); g.fillStyle = '#5a2a0a'; g.fillRect(x - r * .7, y - r * .45, r * 1.4, 3);
    });
  }
  if(d.spices){
    ['#d9822b', '#c0392b', '#e9c46a', '#6a994e', '#8d5524'].forEach((c, i) => {
      const x = 70 + i * 30; g.fillStyle = 'rgba(255,255,255,.75)'; rr(g, x, 112, 22, 28, 5); g.fill();
      g.fillStyle = c; g.fillRect(x + 3, 124, 16, 13); g.fillStyle = '#8a5a24'; g.fillRect(x + 2, 108, 18, 6);
    });
    art(g, 13, 300, 120, 40); art(g, 1, 340, 128, 22);
  }
  if(d.lamp){
    g.strokeStyle = '#8a6a3a'; g.lineWidth = 2; g.beginPath(); g.moveTo(200, 0); g.lineTo(200, 14); g.stroke();
    g.fillStyle = '#e8b84a'; g.beginPath(); g.ellipse(200, 18, 34, 7, 0, 0, TAU); g.fill();
    for(let i = -2; i <= 2; i++){ g.fillStyle = '#fff2b0'; g.beginPath(); g.arc(200 + i * 14, 26, 5, 0, TAU); g.fill(); }
    const gl = g.createRadialGradient(200, 24, 4, 200, 24, 70); gl.addColorStop(0, 'rgba(255,230,140,.4)'); gl.addColorStop(1, 'rgba(255,230,140,0)'); g.fillStyle = gl; g.beginPath(); g.arc(200, 24, 70, 0, TAU); g.fill();
  }
  if(d.plants){
    [[18, 236], [382, 236]].forEach(([x, y]) => {
      g.fillStyle = '#b5653a'; g.beginPath(); g.moveTo(x - 16, y); g.lineTo(x + 16, y); g.lineTo(x + 11, y + 30); g.lineTo(x - 11, y + 30); g.closePath(); g.fill();
      g.fillStyle = '#2f9e44'; for(let k = 0; k < 7; k++){ const a = -Math.PI / 2 + (k - 3) * .35; g.beginPath(); g.ellipse(x + Math.cos(a) * 18, y - 14 + Math.sin(a) * 12, 6, 15, a + Math.PI / 2, 0, TAU); g.fill(); }
    });
  }
}

// ---------- الحديقة ----------
function garden(g, d){
  g.fillStyle = lin(g, 0, 0, 0, 170, [[0, '#7fc8f8'], [1, '#d8f0ff']]); g.fillRect(0, 0, 400, 170);
  g.fillStyle = '#f4d58d'; g.beginPath(); g.arc(340, 40, 22, 0, TAU); g.fill();
  g.fillStyle = '#e2c48a'; g.fillRect(0, 170, 400, 130);
  // سور
  g.fillStyle = '#f0e0c0'; g.fillRect(0, 130, 400, 44); g.fillStyle = '#d9c39a'; for(let x = 0; x < 400; x += 40) g.fillRect(x, 124, 26, 10);
  if(d.grass){ g.fillStyle = lin(g, 0, 174, 0, 300, [[0, '#7cc36a'], [1, '#4f9a45']]); g.fillRect(0, 174, 400, 126); }
  if(d.path){ g.fillStyle = '#e9dcc0'; g.beginPath(); g.moveTo(180, 174); g.lineTo(220, 174); g.lineTo(270, 300); g.lineTo(130, 300); g.closePath(); g.fill();
    g.strokeStyle = 'rgba(150,120,80,.4)'; g.lineWidth = 2; for(let y = 190; y < 300; y += 22){ const k = (y - 174) / 126; g.beginPath(); g.moveTo(180 - k * 50, y); g.lineTo(220 + k * 50, y); g.stroke(); } }
  if(d.palm){ art(g, 10, 60, 120, 150); art(g, 10, 350, 130, 120); }
  if(d.tent){
    g.fillStyle = '#5a2a12'; g.beginPath(); g.moveTo(250, 120); g.lineTo(390, 120); g.lineTo(380, 175); g.lineTo(260, 175); g.closePath(); g.fill();
    g.fillStyle = '#f2e3c4'; for(let x = 262; x < 380; x += 20) g.fillRect(x, 124, 10, 48);
    g.fillStyle = '#9a1f2e'; g.fillRect(250, 116, 140, 8);
  }
  if(d.fountain){
    g.fillStyle = '#d9d2c2'; g.beginPath(); g.ellipse(200, 236, 56, 16, 0, 0, TAU); g.fill();
    g.fillStyle = '#5ab4e5'; g.beginPath(); g.ellipse(200, 232, 48, 11, 0, 0, TAU); g.fill();
    g.fillStyle = '#d9d2c2'; g.fillRect(194, 196, 12, 36); g.beginPath(); g.ellipse(200, 198, 18, 5, 0, 0, TAU); g.fill();
    g.strokeStyle = 'rgba(120,200,255,.9)'; g.lineWidth = 2; for(const s of [-1, 1]){ g.beginPath(); g.moveTo(200, 192); g.quadraticCurveTo(200 + s * 24, 170, 200 + s * 34, 228); g.stroke(); }
  }
  if(d.swing){
    g.strokeStyle = '#6a3a12'; g.lineWidth = 6; g.beginPath(); g.moveTo(96, 250); g.lineTo(110, 150); g.lineTo(170, 150); g.lineTo(184, 250); g.stroke();
    g.lineWidth = 2; g.strokeStyle = '#8a6a3a'; g.beginPath(); g.moveTo(124, 150); g.lineTo(124, 210); g.moveTo(156, 150); g.lineTo(156, 210); g.stroke();
    g.fillStyle = '#c23a7c'; rr(g, 116, 208, 48, 10, 4); g.fill();
  }
  if(d.flowers){ for(let i = 0; i < 9; i++) art(g, 4, 20 + i * 45, 276 - (i % 2) * 8, 30); }
  if(d.lights){
    g.strokeStyle = '#6a5a3a'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(0, 60); g.quadraticCurveTo(100, 100, 200, 66); g.quadraticCurveTo(300, 100, 400, 60); g.stroke();
    for(let i = 0; i <= 12; i++){ const x = i * 33.3, y = i <= 6 ? 60 + Math.sin(i / 6 * Math.PI) * 20 : 66 + Math.sin((i - 6) / 6 * Math.PI) * 20;
      const gl = g.createRadialGradient(x, y + 4, 1, x, y + 4, 9); gl.addColorStop(0, '#fff6b0'); gl.addColorStop(1, 'rgba(255,220,100,0)'); g.fillStyle = gl; g.beginPath(); g.arc(x, y + 4, 9, 0, TAU); g.fill(); }
  }
}

const DRAW = [majlis, kitchen, garden];
function draw(g, room, doneKeys){
  const d = {}; doneKeys.forEach(k => { d[k] = true; });
  g.save(); DRAW[Math.min(room, DRAW.length - 1)](g, d); g.restore();
}
window.Rooms = { draw };
})();
