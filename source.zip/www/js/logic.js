// Twist Out — level generation, rules and solvability checker (shared by game + tests)
(function(root){
'use strict';
const W = 360, BOARD_TOP = 140, BOARD_BOT = 560, SR = 13; // screw radius

function mulberry(seed){ let s = seed|0; return () => { s = s + 0x6D2B79F5 | 0; let t = Math.imul(s ^ s >>> 15, 1 | s); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

// point inside rotated rect (with margin)
function inPlate(p, x, y, m){
  const dx = x - p.x, dy = y - p.y, c = Math.cos(-p.a), s = Math.sin(-p.a);
  const lx = dx*c - dy*s, ly = dx*s + dy*c;
  return Math.abs(lx) < p.w/2 + m && Math.abs(ly) < p.h/2 + m;
}

function params(level){
  return {
    plates: Math.min(4 + Math.floor(level*0.7), 18),
    colors: Math.min(3 + Math.floor((level-1)/4), 7),
    buffer: 5,
  };
}

function generate(level, attempt){
  const P = params(level);
  const rnd = mulberry(level*9973 + (attempt||0)*131 + 7);
  const plates = [], screws = [];
  let tries = 0;
  for(let i=0;i<P.plates;i++){
    const long = rnd() < .7;
    const w = long ? 150 + rnd()*110 : 80 + rnd()*50;
    const h = long ? 44 + rnd()*14 : 70 + rnd()*30;
    const a = (rnd()-.5) * (long ? 1.6 : .8);
    const spreadX = 100, spreadY = (BOARD_BOT-BOARD_TOP)/2 - 60;
    const x = W/2 + (rnd()*2-1)*spreadX;
    const y = (BOARD_TOP+BOARD_BOT)/2 + (rnd()*2-1)*spreadY;
    const p = { id:i, x, y, w, h, a, hue: Math.floor(rnd()*5), alive:true };
    { const c0 = Math.cos(a), s0 = Math.sin(a); let okc = true;
      for(const [qx,qy] of [[-w/2,-h/2],[w/2,-h/2],[w/2,h/2],[-w/2,h/2]]){ const cx = x + qx*c0 - qy*s0, cy = y + qx*s0 + qy*c0; if(cx < 12 || cx > W-12 || cy < BOARD_TOP+4 || cy > BOARD_BOT-4){ okc = false; break; } }
      if(!okc){ i--; if(++tries > 400) break; continue; } }
    // screw slots along the long axis
    const n = long ? (w > 200 ? 4 : 3) : 2;
    const slots = [];
    if(long){ for(let k=0;k<n;k++){ const lx = -w/2 + 22 + k*((w-44)/(n-1)); slots.push([lx, 0]); } }
    else { slots.push([0, -h/2+20]); slots.push([0, h/2-20]); }
    const c = Math.cos(p.a), s = Math.sin(p.a);
    p.screws = [];
    for(const [lx,ly] of slots){
      const sx = p.x + lx*c - ly*s, sy = p.y + lx*s + ly*c;
      if(sx < 24 || sx > W-24 || sy < BOARD_TOP+10 || sy > BOARD_BOT-10) continue;
      if(screws.some(o => Math.hypot(o.x-sx, o.y-sy) < SR*2.3)) continue;
      const sc = { id: screws.length, plate:i, x:sx, y:sy, color:-1, alive:true };
      screws.push(sc); p.screws.push(sc.id);
    }
    if(p.screws.length) plates.push(p);
  }
  plates.forEach((p,i) => { p.id = i; p.screws.forEach(sid => screws[sid].plate = i); });
  // trim to multiple of 3 (remove from plates with most screws)
  while(screws.filter(s=>s.alive).length % 3){
    const p = plates.slice().sort((a,b)=>b.screws.length-a.screws.length)[0];
    const sid = p.screws.pop(); screws[sid].alive = false;
  }
  const live = screws.filter(s=>s.alive);
  // colors: counts multiples of 3
  const n = live.length, k = Math.min(P.colors, n/3);
  const bag = [];
  let triples = n/3;
  for(let c=0;c<k;c++){ bag.push(c,c,c); triples--; }
  while(triples-- > 0){ const c = Math.floor(rnd()*k); bag.push(c,c,c); }
  for(let i=bag.length-1;i>0;i--){ const j = Math.floor(rnd()*(i+1)); [bag[i],bag[j]] = [bag[j],bag[i]]; }
  live.forEach((s,i) => s.color = bag[i]);
  const finalScrews = live.map((s,i) => ({...s, id:i}));
  const map = {}; live.forEach((s,i)=> map[s.id]=i);
  plates.forEach(p => p.screws = p.screws.filter(sid => map[sid]!==undefined).map(sid => map[sid]));
  return { level, plates, screws: finalScrews, buffer: P.buffer, colors: k, rndSeed: level*7 + (attempt||0) };
}

// ---- rules ----
function accessible(st, s){
  if(!s.alive) return false;
  const own = st.plates[s.plate];
  for(let i=s.plate+1;i<st.plates.length;i++){
    const p = st.plates[i];
    if(p.alive && inPlate(p, s.x, s.y, SR*0.55)) return false;
  }
  return true;
}
function remainingOf(st, c){ return st.screws.filter(s=>s.alive && s.color===c).length + st.buf.filter(b=>b===c).length; }
function pickBoxColor(st, exclude){
  let best = -1, score = -1;
  for(let c=0;c<st.colors;c++){
    const rem = remainingOf(st,c) - st.boxes.filter(b=>b && b.color===c).reduce((a,b)=>a+(3-b.n),0);
    if(rem < 3) continue;
    const sc = st.buf.filter(b=>b===c).length*10 + st.screws.filter(s=>s.alive && s.color===c && accessible(st,s)).length + (c===exclude?-100:0);
    if(sc > score){ score = sc; best = c; }
  }
  return best;
}
function newState(lv){
  const st = { plates: lv.plates.map(p=>({...p, screws:p.screws.slice(), alive:true})), screws: lv.screws.map(s=>({...s})), cap: lv.buffer, buf: [], boxes:[null,null], colors: lv.colors, done:0 };
  for(let i=0;i<2;i++) spawnBox(st,i);
  return st;
}
function spawnBox(st, i){
  const other = st.boxes[1-i]; const c = pickBoxColor(st, other ? other.color : -1);
  st.boxes[i] = c < 0 ? null : { color:c, n:0 };
  if(st.boxes[i]) drainBuffer(st, i);
}
function drainBuffer(st, i){
  const b = st.boxes[i]; if(!b) return [];
  const moved = [];
  for(let k=0;k<st.buf.length && b.n<3;){
    if(st.buf[k]===b.color){ st.buf.splice(k,1); b.n++; moved.push(b.color); } else k++;
  }
  if(b.n===3){ st.done++; spawnBox(st,i); }
  return moved;
}
// apply a tap; returns {ok, to:'box'|'buf', box:i, fell:[plateIds], win, lose}
function tap(st, sid){
  const s = st.screws[sid];
  if(!accessible(st,s)) return { ok:false, blocked:true };
  let bi = st.boxes.findIndex(b => b && b.color===s.color && b.n<3);
  if(bi < 0 && st.buf.length >= st.cap) return { ok:false, full:true };
  s.alive = false;
  const p = st.plates[s.plate]; p.screws = p.screws.filter(x=>x!==sid);
  const fell = []; if(!p.screws.length && p.alive){ p.alive = false; fell.push(p.id); }
  let res;
  if(bi >= 0){ const b = st.boxes[bi]; b.n++; res = { ok:true, to:'box', box:bi, color:s.color, filled: b.n===3 }; if(b.n===3){ st.done++; spawnBox(st,bi); } }
  else { st.buf.push(s.color); res = { ok:true, to:'buf', color:s.color }; }
  res.fell = fell;
  res.win = !st.screws.some(x=>x.alive) && !st.buf.length;
  res.lose = !res.win && isStuck(st);
  return res;
}
function isStuck(st){
  if(st.buf.length < st.cap) return !st.screws.some(s=>s.alive && accessible(st,s)) && st.screws.some(s=>s.alive);
  return !st.screws.some(s => s.alive && accessible(st,s) && st.boxes.some(b=>b && b.color===s.color && b.n<3));
}
// greedy solver for validation
function solvable(lv, cap){
  const st = newState({...lv, buffer: cap});
  for(let guard=0; guard<500; guard++){
    if(!st.screws.some(x=>x.alive) && !st.buf.length) return true;
    const acc = st.screws.filter(s=>s.alive && accessible(st,s));
    if(!acc.length) return false;
    const fit = acc.filter(s=>st.boxes.some(b=>b && b.color===s.color && b.n<3));
    let pick;
    const plateLeft = s => st.plates[s.plate].screws.length;
    if(fit.length) pick = fit.sort((a,b)=>plateLeft(a)-plateLeft(b))[0];
    else {
      if(st.buf.length >= st.cap) return false;
      const bc = c => st.buf.filter(b=>b===c).length;
      pick = acc.sort((a,b)=> (bc(b.color)-bc(a.color)) || (plateLeft(a)-plateLeft(b)))[0];
    }
    const r = tap(st, pick.id);
    if(!r.ok) return false;
  }
  return false;
}
function buildLevel(level){
  const cap = level <= 3 ? 3 : 4; // validate with fewer slots than the player gets
  for(let a=0;a<60;a++){
    const lv = generate(level, a);
    if(lv.screws.length < 6) continue;
    if(solvable(lv, cap)) return lv;
  }
  return generate(level, 0);
}
const api = { W, BOARD_TOP, BOARD_BOT, SR, inPlate, buildLevel, newState, tap, accessible, solvable, generate, isStuck, drainBuffer };
if(typeof module !== 'undefined') module.exports = api; else root.TW = api;
})(typeof window !== 'undefined' ? window : globalThis);
