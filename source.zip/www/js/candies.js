// Sweet Pop — procedurally drawn candy sprites (original art)
(function(){
'use strict';
const S = 128;
const COLORS = [
  { base:'#ff3b5c', light:'#ffb3c0', dark:'#b3123a' }, // red ball
  { base:'#ff9a1c', light:'#ffd9a3', dark:'#c25e00' }, // orange square
  { base:'#ffd83b', light:'#fff4b8', dark:'#c99a00' }, // yellow drop
  { base:'#3fd25a', light:'#b8f5c4', dark:'#168a30' }, // green gem
  { base:'#3aa0ff', light:'#b8dcff', dark:'#1462c2' }, // blue capsule
  { base:'#b05cff', light:'#e2c2ff', dark:'#6e22c2' }, // purple flower
];
function shapePath(x, t){
  const c = S / 2;
  x.beginPath();
  if(t === 0){ x.arc(c, c, 46, 0, Math.PI * 2); }
  else if(t === 1){ const r = 18, a = 22, b = 106; x.moveTo(a + r, a); x.arcTo(b, a, b, b, r); x.arcTo(b, b, a, b, r); x.arcTo(a, b, a, a, r); x.arcTo(a, a, b, a, r); }
  else if(t === 2){ x.moveTo(c, 14); x.bezierCurveTo(c + 22, 44, c + 46, 62, c + 44, 82); x.arc(c, 80, 44, 0.05, Math.PI - 0.05); x.bezierCurveTo(c - 46, 62, c - 22, 44, c, 14); }
  else if(t === 3){ for(let i = 0; i < 6; i++){ const a = Math.PI / 6 + i * Math.PI / 3; const px = c + Math.cos(a) * 50, py = c + Math.sin(a) * 50; i ? x.lineTo(px, py) : x.moveTo(px, py); } }
  else if(t === 4){ const r = 32, a = 16, b = 112; x.moveTo(a + r, c - r); x.lineTo(b - r, c - r); x.arc(b - r, c, r, -Math.PI / 2, Math.PI / 2); x.lineTo(a + r, c + r); x.arc(a + r, c, r, Math.PI / 2, Math.PI * 1.5); }
  else { for(let i = 0; i <= 120; i++){ const a = i / 120 * Math.PI * 2 - Math.PI / 2, rr = 41 + 9 * Math.cos(5 * (a + Math.PI / 2)); const px = c + Math.cos(a) * rr, py = c + 2 + Math.sin(a) * rr; i ? x.lineTo(px, py) : x.moveTo(px, py); } }
  x.closePath();
}
function body(x, t){
  const col = COLORS[t];
  x.save();
  x.shadowColor = 'rgba(0,0,0,.28)'; x.shadowBlur = 8; x.shadowOffsetY = 5;
  shapePath(x, t);
  const g = x.createRadialGradient(S * .38, S * .32, 6, S / 2, S / 2, 64);
  g.addColorStop(0, col.light); g.addColorStop(.45, col.base); g.addColorStop(1, col.dark);
  x.fillStyle = g; x.fill();
  x.restore();
  x.save(); shapePath(x, t); x.lineWidth = 3; x.strokeStyle = col.dark; x.stroke(); x.restore();
}
function gloss(x){
  x.save(); x.globalAlpha = .55; x.fillStyle = '#fff';
  x.beginPath(); x.ellipse(S * .38, S * .3, 16, 9, -0.5, 0, Math.PI * 2); x.fill();
  x.globalAlpha = .35; x.beginPath(); x.arc(S * .62, S * .7, 5, 0, Math.PI * 2); x.fill();
  x.restore();
}
const K = window.CANDY_SCALE || 1.6;
function mk(draw){ const c = document.createElement('canvas'); c.width = c.height = Math.round(S * K); const x = c.getContext('2d'); x.scale(K, K); draw(x); return c; }
function normal(t){ return mk(x => { body(x, t); gloss(x); }); }
function striped(t, dir){
  return mk(x => {
    body(x, t);
    x.save(); shapePath(x, t); x.clip();
    x.fillStyle = 'rgba(255,255,255,.85)';
    for(let i = -2; i < 8; i++){
      if(dir === 'h') x.fillRect(0, 14 + i * 20, S, 8);
      else x.fillRect(14 + i * 20, 0, 8, S);
    }
    x.restore();
    x.save(); shapePath(x, t); x.lineWidth = 3; x.strokeStyle = COLORS[t].dark; x.stroke(); x.restore();
    gloss(x);
  });
}
function wrapped(t){
  const col = COLORS[t];
  return mk(x => {
    // wrapper twists
    x.fillStyle = col.light; x.strokeStyle = col.dark; x.lineWidth = 3;
    for(const s of [-1, 1]){
      x.beginPath(); x.moveTo(64 + s * 36, 64); x.lineTo(64 + s * 62, 36); x.lineTo(64 + s * 56, 64); x.lineTo(64 + s * 62, 92); x.closePath(); x.fill(); x.stroke();
    }
    x.save(); x.shadowColor = 'rgba(0,0,0,.28)'; x.shadowBlur = 8; x.shadowOffsetY = 5;
    x.beginPath(); x.arc(64, 64, 40, 0, Math.PI * 2);
    const g = x.createRadialGradient(50, 46, 4, 64, 64, 48); g.addColorStop(0, '#fff'); g.addColorStop(.35, col.light); g.addColorStop(1, col.base);
    x.fillStyle = g; x.fill(); x.restore();
    x.beginPath(); x.arc(64, 64, 40, 0, Math.PI * 2); x.lineWidth = 3; x.strokeStyle = col.dark; x.stroke();
    // shiny wrapper pattern
    x.save(); x.beginPath(); x.arc(64, 64, 40, 0, Math.PI * 2); x.clip();
    x.strokeStyle = 'rgba(255,255,255,.6)'; x.lineWidth = 4;
    for(let i = -3; i <= 3; i++){ x.beginPath(); x.moveTo(30 + i * 16, 20); x.lineTo(60 + i * 16, 110); x.stroke(); }
    x.restore();
    gloss(x);
  });
}
const bomb = mk(x => {
  x.save(); x.shadowColor = 'rgba(0,0,0,.35)'; x.shadowBlur = 8; x.shadowOffsetY = 5;
  x.beginPath(); x.arc(64, 64, 48, 0, Math.PI * 2);
  const g = x.createRadialGradient(48, 44, 4, 64, 64, 56); g.addColorStop(0, '#a0674a'); g.addColorStop(.5, '#5a321e'); g.addColorStop(1, '#2e170c');
  x.fillStyle = g; x.fill(); x.restore();
  const cols = ['#ff3b5c', '#ff9a1c', '#ffd83b', '#3fd25a', '#3aa0ff', '#b05cff', '#ffffff'];
  let seed = 7; const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
  for(let i = 0; i < 34; i++){
    const a = rnd() * Math.PI * 2, r = Math.sqrt(rnd()) * 40, px = 64 + Math.cos(a) * r, py = 64 + Math.sin(a) * r;
    x.save(); x.translate(px, py); x.rotate(rnd() * Math.PI); x.fillStyle = cols[i % cols.length];
    x.beginPath(); x.ellipse(0, 0, 6, 2.4, 0, 0, Math.PI * 2); x.fill(); x.restore();
  }
  x.save(); x.globalAlpha = .35; x.fillStyle = '#fff'; x.beginPath(); x.ellipse(46, 40, 14, 8, -0.6, 0, Math.PI * 2); x.fill(); x.restore();
});
const cache = {};
function get(t, s){
  if(s === 'b' || t < 0) return bomb;
  const k = t + (s || '');
  if(!cache[k]) cache[k] = !s ? normal(t) : s === 'w' ? wrapped(t) : striped(t, s);
  return cache[k];
}
window.CANDY = { get, COLORS, SIZE:S };
})();
