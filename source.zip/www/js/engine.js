// مجلسي — منطق لعبة الدمج (بلا واجهة، كيخدم فالمتصفح وفـ Node)
(function(root){
'use strict';
const COLS = 7, ROWS = 7, CELLS = COLS * ROWS, MAX_TIER = 6;
const ENERGY_MAX = 100, ENERGY_EVERY = 120000; // +1 كل دقيقتين
const CHAINS = ['c', 'd', 's', 'j'];
const NAMES = {
  c: ['فنجان', 'فنجانان', 'دلّة', 'دلّة وفنجان', 'صينية قهوة', 'طقم الضيافة'],
  d: ['تمرة', 'تمرتان', 'صحن تمر', 'لقيمات', 'صينية حلويات', 'سلة هدايا'],
  s: ['وردة', 'باقة ورد', 'عطر', 'مبخرة', 'صينية عطور', 'صندوق العود'],
  j: ['لؤلؤة', 'لؤلؤتان', 'خاتم', 'إسوارة', 'طقم ذهب', 'صندوق المجوهرات'],
};
const GEN_NAMES = { c: 'صندوق القهوة', d: 'سلة التمر', s: 'صندوق العطور', j: 'صندوق اللؤلؤ' };

// الغرف ومهام الديكور (التكلفة بالنجوم)
const ROOMS = [
  { name: 'المجلس', tasks: [
    ['carpet', 'فرش الزربية', 1], ['seats', 'الجلسة الأرضية', 2], ['cushions', 'المساند', 2], ['curtain', 'الستائر', 3],
    ['lantern', 'الفانوس', 3], ['table', 'طاولة القهوة', 4], ['incense', 'ركن البخور', 4], ['wall', 'نقوش الجدار', 5] ] },
  { name: 'المطبخ', tasks: [
    ['floor', 'البلاط', 3], ['counter', 'الرخامة', 4], ['shelf', 'الرفوف', 4], ['pots', 'القدور النحاسية', 5],
    ['window', 'النافذة', 5], ['spices', 'جرار البهارات', 6], ['lamp', 'الثريا', 6], ['plants', 'النباتات', 7] ] },
  { name: 'الحديقة', tasks: [
    ['grass', 'العشب', 5], ['path', 'الممر', 6], ['palm', 'النخلة', 6], ['fountain', 'النافورة', 7],
    ['swing', 'المرجيحة', 7], ['flowers', 'الورود', 8], ['lights', 'الأضواء', 8], ['tent', 'الخيمة', 10] ] },
];
// متى كتتفتح كل سلسلة (عدد المهام المنجزة فالمجموع)
const UNLOCK = { c: 0, d: 0, s: 3, j: 9 };

function rng(seed){ let s = (seed >>> 0) || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }

const isGen = it => !!it && it[0] === 'G';
const chainOf = it => isGen(it) ? it[1] : it[0];
const tierOf = it => isGen(it) ? 0 : +it.slice(1);
const nameOf = it => isGen(it) ? GEN_NAMES[it[1]] : NAMES[it[0]][tierOf(it) - 1];
const sellValue = it => isGen(it) ? 0 : Math.pow(2, tierOf(it) - 1);

function tasksDone(S){ return S.done.length; }
function unlockedChains(S){ return CHAINS.filter(c => tasksDone(S) >= UNLOCK[c]); }

function newState(now){
  const board = new Array(CELLS).fill(null);
  board[3 * COLS + 1] = 'Gc'; board[3 * COLS + 5] = 'Gd';
  board[2 * COLS + 2] = 'c1'; board[2 * COLS + 4] = 'd1'; board[4 * COLS + 3] = 'c1';
  const S = { v: 1, board, energy: ENERGY_MAX, energyAt: now || 0, coins: 50, stars: 0, xp: 0, served: 0, done: [], orders: [], seq: 1, seed: 12345 };
  S.orders = [makeOrder(S, true), makeOrder(S, true), makeOrder(S)];
  return S;
}

// طلب جديد حسب التقدم
function makeOrder(S, easy){
  const r = rng(S.seed + S.seq * 7919); S.seq++;
  const chains = unlockedChains(S);
  const maxT = easy ? 2 : Math.min(MAX_TIER, 2 + Math.floor(S.served / 4));
  const minT = easy ? 1 : Math.max(1, maxT - 2);
  const n = !easy && S.served >= 6 && r() < .4 ? 2 : 1;
  const req = [];
  for(let i = 0; i < n; i++){
    // كنفضلو السلاسل الجداد شوية
    const c = chains[Math.floor(r() * chains.length)];
    let t = minT + Math.floor(r() * (maxT - minT + 1));
    if(n === 2) t = Math.max(1, t - 1);
    req.push(c + t);
  }
  const coins = req.reduce((a, it) => a + 4 * Math.pow(2, tierOf(it) - 1), 0) + 2;
  const stars = req.reduce((a, it) => a + (tierOf(it) >= 4 ? 2 : 1), 0);
  const guest = Math.floor(r() * 6);
  return { id: S.seq, req, coins, stars, guest };
}

function emptyCells(S){ const out = []; S.board.forEach((it, i) => { if(!it) out.push(i); }); return out; }
const rc = i => [Math.floor(i / COLS), i % COLS];

function regen(S, now){
  if(S.energy >= ENERGY_MAX){ S.energyAt = now; return 0; }
  const k = Math.floor((now - S.energyAt) / ENERGY_EVERY);
  if(k > 0){ const add = Math.min(k, ENERGY_MAX - S.energy); S.energy += add; S.energyAt += k * ENERGY_EVERY; if(S.energy >= ENERGY_MAX) S.energyAt = now; return add; }
  return 0;
}
function nextEnergyIn(S, now){ return S.energy >= ENERGY_MAX ? 0 : Math.max(0, ENERGY_EVERY - (now - S.energyAt)); }

// الضغط على المولد: كيخرج قطعة فأقرب خانة خاوية
function tapGen(S, i, rand, now){
  rand = rand || Math.random;
  const it = S.board[i];
  if(!isGen(it)) return { ok: false };
  if(S.energy <= 0) return { ok: false, why: 'energy' };
  const empty = emptyCells(S);
  if(!empty.length) return { ok: false, why: 'full' };
  const [r0, c0] = rc(i);
  empty.sort((a, b) => { const [ra, ca] = rc(a), [rb, cb] = rc(b); return (Math.abs(ra - r0) + Math.abs(ca - c0)) - (Math.abs(rb - r0) + Math.abs(cb - c0)) || rand() - .5; });
  const to = empty[0];
  const tier = rand() < .12 ? 2 : 1;
  S.board[to] = it[1] + tier;
  if(S.energy >= ENERGY_MAX) S.energyAt = now || 0;
  S.energy--;
  return { ok: true, to, item: S.board[to] };
}

// تحريك أو دمج
function move(S, a, b){
  if(a === b) return { ok: false };
  const A = S.board[a], B = S.board[b];
  if(!A) return { ok: false };
  if(!B){ S.board[b] = A; S.board[a] = null; return { ok: true, kind: 'move' }; }
  if(A === B && !isGen(A) && tierOf(A) < MAX_TIER){
    const up = chainOf(A) + (tierOf(A) + 1);
    S.board[b] = up; S.board[a] = null;
    S.xp++;
    return { ok: true, kind: 'merge', item: up };
  }
  S.board[a] = B; S.board[b] = A;
  return { ok: true, kind: 'swap' };
}

// واش الطلب جاهز؟ كترجع الخانات اللي غادي تستعمل
function findForOrder(S, o){
  const used = [];
  for(const it of o.req){
    const i = S.board.findIndex((x, k) => x === it && !used.includes(k));
    if(i < 0) return null;
    used.push(i);
  }
  return used;
}
function serve(S, oi){
  const o = S.orders[oi]; if(!o) return null;
  const cells = findForOrder(S, o); if(!cells) return null;
  cells.forEach(k => { S.board[k] = null; });
  S.coins += o.coins; S.stars += o.stars; S.served++;
  S.orders[oi] = makeOrder(S);
  return { cells, coins: o.coins, stars: o.stars, order: o };
}
function sell(S, i){
  const it = S.board[i]; if(!it || isGen(it)) return 0;
  const v = sellValue(it); S.board[i] = null; S.coins += v; return v;
}

// الديكور
function currentRoom(S){
  let k = S.done.length;
  for(let r = 0; r < ROOMS.length; r++){ if(k < ROOMS[r].tasks.length) return r; k -= ROOMS[r].tasks.length; }
  return ROOMS.length; // كلشي سالا
}
function nextTask(S){
  const r = currentRoom(S); if(r >= ROOMS.length) return null;
  const t = ROOMS[r].tasks.find(t => !S.done.includes(t[0]));
  return t ? { room: r, key: t[0], name: t[1], cost: t[2] } : null;
}
function doTask(S){
  const t = nextTask(S); if(!t || S.stars < t.cost) return null;
  S.stars -= t.cost; S.done.push(t.key);
  // مولد جديد ملي كتتفتح سلسلة
  const newly = CHAINS.filter(c => UNLOCK[c] === S.done.length);
  const gens = [];
  for(const c of newly){
    if(S.board.includes('G' + c)) continue;
    const e = emptyCells(S);
    const at = e.length ? e[Math.floor(e.length / 2)] : -1;
    if(at >= 0){ S.board[at] = 'G' + c; gens.push(at); }
    else S.pendingGen = (S.pendingGen || []).concat('G' + c);
  }
  // كل طلب ساهل كيتبدل باش يبان النوع الجديد
  return { task: t, gens, roomDone: currentRoom(S) !== t.room };
}
function placePending(S){
  if(!S.pendingGen || !S.pendingGen.length) return [];
  const placed = [];
  while(S.pendingGen.length){ const e = emptyCells(S); if(!e.length) break; const g = S.pendingGen.shift(); S.board[e[0]] = g; placed.push(e[0]); }
  return placed;
}

const Engine = { COLS, ROWS, CELLS, MAX_TIER, ENERGY_MAX, ENERGY_EVERY, CHAINS, NAMES, ROOMS, UNLOCK,
  isGen, chainOf, tierOf, nameOf, sellValue, unlockedChains, newState, makeOrder, emptyCells, regen, nextEnergyIn,
  tapGen, move, findForOrder, serve, sell, currentRoom, nextTask, doTask, placePending, rng };
if(typeof module !== 'undefined' && module.exports) module.exports = Engine; else root.Engine = Engine;
})(typeof window !== 'undefined' ? window : globalThis);
