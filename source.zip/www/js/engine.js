// زينة — منطق لعبة Tile Match (بلا واجهة، كيخدم فالمتصفح وفـ Node)
(function(root){
'use strict';
const TRAY = 7;

// مولد أرقام عشوائية ثابت
function rng(seed){
  let s = (seed >>> 0) || 1;
  return () => { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
}

// القطعة كتغطي 2×2 من نص الوحدات؛ A كتغطي B إلا كانت فوقها وكيتقاطعو
const overlaps = (a, b) => Math.abs(a.x - b.x) < 2 && Math.abs(a.y - b.y) < 2;

// كنحسبو شكون كيغطي شكون مرة وحدة
function buildCover(tiles){
  tiles.forEach(t => { t.above = []; t.below = []; });
  for(const a of tiles) for(const b of tiles){
    if(a !== b && a.z > b.z && overlaps(a, b)){ b.above.push(a.id); a.below.push(b.id); }
  }
}

function create(level){
  const tiles = level.tiles.map((p, i) => ({ id: i, x: p[0], y: p[1], z: p[2], t: p[3], state: 'board' }));
  buildCover(tiles);
  return { tiles, tray: [], history: [], cleared: 0, total: tiles.length, picks: 0, over: false, won: false };
}

function clone(S){
  return {
    tiles: S.tiles.map(t => Object.assign({}, t)),
    tray: S.tray.slice(), history: S.history.slice(), cleared: S.cleared, total: S.total, picks: S.picks, over: S.over, won: S.won,
  };
}

const isFree = (S, t) => t.state === 'board' && t.above.every(id => S.tiles[id].state !== 'board');
const freeTiles = S => S.tiles.filter(t => isFree(S, t));
const boardTiles = S => S.tiles.filter(t => t.state === 'board');

// كنحطو القطعة فالشريط حدا اللي كيشبهوها
function insertTray(S, id){
  const t = S.tiles[id].t;
  let at = -1;
  for(let i = S.tray.length - 1; i >= 0; i--) if(S.tiles[S.tray[i]].t === t){ at = i + 1; break; }
  if(at < 0) at = S.tray.length;
  S.tray.splice(at, 0, id);
  return at;
}

// كترجع { ok, slot, cleared:[ids], won, lost }
function pick(S, id){
  if(S.over) return { ok: false };
  const tile = S.tiles[id];
  if(!tile || !isFree(S, tile)) return { ok: false };
  tile.state = 'tray';
  const slot = insertTray(S, id);
  S.history.push(id); S.picks++;
  const same = S.tray.filter(i => S.tiles[i].t === tile.t);
  let cleared = [];
  if(same.length >= 3){
    cleared = same.slice(0, 3);
    cleared.forEach(i => { S.tiles[i].state = 'gone'; });
    S.tray = S.tray.filter(i => !cleared.includes(i));
    S.history = S.history.filter(i => !cleared.includes(i));
    S.cleared += 3;
  }
  let won = false, lost = false;
  if(S.cleared === S.total){ S.over = true; S.won = won = true; }
  else if(S.tray.length >= TRAY){ S.over = true; lost = true; }
  return { ok: true, slot, cleared, won, lost };
}

// رجوع آخر قطعة للوحة
function undo(S){
  if(!S.history.length) return null;
  const id = S.history.pop();
  S.tray = S.tray.filter(i => i !== id);
  S.tiles[id].state = 'board';
  S.over = false;
  return id;
}

// كنرجعو حتى n قطع من الشريط للوحة (مكافأة الفيديو)
function rescue(S, n){
  const back = [];
  for(let k = 0; k < n && S.history.length; k++) back.push(undo(S));
  S.over = false;
  return back;
}

// خلط الأنواع بين القطع اللي باقية فاللوحة
function shuffle(S, rand){
  rand = rand || Math.random;
  const B = boardTiles(S), types = B.map(t => t.t);
  for(let i = types.length - 1; i > 0; i--){ const j = Math.floor(rand() * (i + 1)); [types[i], types[j]] = [types[j], types[i]]; }
  B.forEach((t, i) => { t.t = types[i]; });
}

// المغناطيس: كيكمل نوع واحد (3 قطع) من أي بلاصة
function magnet(S){
  if(S.over) return null;
  let type = null;
  const cnt = {};
  S.tray.forEach(i => { const t = S.tiles[i].t; cnt[t] = (cnt[t] || 0) + 1; });
  let bestN = 0;
  for(const k in cnt) if(cnt[k] > bestN){ bestN = cnt[k]; type = +k; }
  if(type === null){
    const free = freeTiles(S);
    if(!free.length) return null;
    type = free[0].t;
  }
  const inTray = S.tray.filter(i => S.tiles[i].t === type);
  const need = 3 - inTray.length;
  // كنفضلو القطع الفوقانية
  const cand = boardTiles(S).filter(t => t.t === type).sort((a, b) => b.z - a.z);
  if(cand.length < need) return null;
  const taken = cand.slice(0, need).map(t => t.id);
  const ids = inTray.concat(taken);
  ids.forEach(i => { S.tiles[i].state = 'gone'; });
  S.tray = S.tray.filter(i => !ids.includes(i));
  S.history = S.history.filter(i => !ids.includes(i));
  S.cleared += 3;
  if(S.cleared === S.total){ S.over = true; S.won = true; }
  return { type, ids, fromBoard: taken, won: S.won };
}

// ---------- توليد المستويات ----------
// كنحسبو ترتيب حيدان صالح، ومن بعد كنعطيو الأنواع ثلاثيات على هاد الترتيب => المستوى ديما قابل للحل
function assignTypes(positions, ntypes, open, seed){
  const rand = rng(seed);
  const tiles = positions.map((p, i) => ({ id: i, x: p[0], y: p[1], z: p[2], state: 'board' }));
  buildCover(tiles);
  const S = { tiles };
  const order = [];
  while(order.length < tiles.length){
    const free = tiles.filter(t => isFree(S, t));
    // كنختارو بزاف من الفوق باش يكون الترتيب طبيعي
    const t = free[Math.floor(rand() * free.length)];
    t.state = 'gone'; order.push(t.id);
  }
  // open = 0 => توزيع عشوائي كامل (الصعوبة كتقاس بالمحاكاة)
  if(!open){
    const ts = [];
    for(let i = 0; i < tiles.length / 3; i++){ const t = i % ntypes; ts.push(t, t, t); }
    for(let i = ts.length - 1; i > 0; i--){ const j = Math.floor(rand() * (i + 1)); [ts[i], ts[j]] = [ts[j], ts[i]]; }
    return positions.map((p, i) => [p[0], p[1], p[2], ts[i]]);
  }
  // open = شحال من نوع مفتوح فنفس الوقت (1 سهل، 3 صعيب)
  const types = new Array(tiles.length);
  let openList = []; // [type, remaining]
  const bag = [];
  const newType = () => {
    if(!bag.length){ for(let i = 0; i < ntypes; i++) bag.push(i); for(let i = bag.length - 1; i > 0; i--){ const j = Math.floor(rand() * (i + 1)); [bag[i], bag[j]] = [bag[j], bag[i]]; } }
    return bag.pop();
  };
  let idx = 0;
  for(; idx < order.length; idx++){
    const remainingSlots = order.length - idx;
    const committed = openList.reduce((a, o) => a + o[1], 0);
    const canOpen = openList.length < open && remainingSlots - committed >= 3;
    let choice;
    if(!openList.length || (canOpen && rand() < .45)){
      choice = [newType(), 3]; openList.push(choice);
    } else choice = openList[Math.floor(rand() * openList.length)];
    types[order[idx]] = choice[0];
    choice[1]--;
    if(choice[1] === 0) openList = openList.filter(o => o !== choice);
  }
  return positions.map((p, i) => [p[0], p[1], p[2], types[i]]);
}

// لاعب آلي كيشوف غير القطع الحرة
function botPlay(level, rand, skill){
  rand = rand || Math.random;
  const S = create(level);
  while(!S.over){
    const free = freeTiles(S);
    if(!free.length) break;
    const cnt = {};
    S.tray.forEach(i => { const t = S.tiles[i].t; cnt[t] = (cnt[t] || 0) + 1; });
    const freeCnt = {};
    free.forEach(t => { freeCnt[t.t] = (freeCnt[t.t] || 0) + 1; });
    let bestT = null, bv = -1e9;
    for(const t of free){
      let v = (cnt[t.t] || 0) * 10 + (freeCnt[t.t] || 0) * 3;
      if((cnt[t.t] || 0) + (freeCnt[t.t] || 0) >= 3) v += 25;
      if(S.tray.length >= 5 && !cnt[t.t]) v -= 20;
      v += t.above.length * 0 + t.below.length * (skill || 0) * .6;
      v += rand() * 4;
      if(v > bv){ bv = v; bestT = t; }
    }
    pick(S, bestT.id);
  }
  return S.won;
}

const Engine = { TRAY, rng, create, clone, isFree, freeTiles, boardTiles, pick, undo, rescue, shuffle, magnet, assignTypes, botPlay, overlaps };
if(typeof module !== 'undefined' && module.exports) module.exports = Engine;
else root.Engine = Engine;
})(typeof window !== 'undefined' ? window : globalThis);
