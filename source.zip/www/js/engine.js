// دانة — محرك لعبة المطابقة (منطق خالص بلا رسم، كيخدم حتى فـ Node للتجربة)
(function(root){
'use strict';
const W = 8, H = 8;
const key = (r, c) => r * W + c;
const rc = k => [Math.floor(k / W), k % W];

// ---------- أرقام عشوائية بحالة قابلة للنسخ ----------
function rand(S){
  let a = S.rs = (S.rs + 0x6D2B79F5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
const randInt = (S, n) => Math.floor(rand(S) * n);

function newTile(S, t, sp){ return { id: S.nextId++, t, sp: sp || '' }; }
function inside(S, r, c){ return r >= 0 && r < H && c >= 0 && c < W && S.mask[r][c]; }
function tileAt(S, r, c){ return inside(S, r, c) ? S.tiles[r][c] : null; }

// ---------- المطابقات ----------
function findRuns(S){
  const runs = [];
  for(let r = 0; r < H; r++){
    let c = 0;
    while(c < W){
      const t = S.tiles[r][c];
      if(!t || t.t < 0){ c++; continue; }
      let e = c + 1;
      while(e < W && S.tiles[r][e] && S.tiles[r][e].t === t.t) e++;
      if(e - c >= 3){ const cells = []; for(let i = c; i < e; i++) cells.push(key(r, i)); runs.push({ dir: 'h', t: t.t, cells }); }
      c = e;
    }
  }
  for(let c = 0; c < W; c++){
    let r = 0;
    while(r < H){
      const t = S.tiles[r][c];
      if(!t || t.t < 0){ r++; continue; }
      let e = r + 1;
      while(e < H && S.tiles[e][c] && S.tiles[e][c].t === t.t) e++;
      if(e - r >= 3){ const cells = []; for(let i = r; i < e; i++) cells.push(key(i, c)); runs.push({ dir: 'v', t: t.t, cells }); }
      r = e;
    }
  }
  return runs;
}

// واش كاين مطابقة كتمس هاد الخانة؟ (سريعة، للبحث على الحركات)
function lineAt(S, r, c){
  const t = S.tiles[r][c]; if(!t || t.t < 0) return false;
  let n = 1;
  for(let i = c - 1; i >= 0 && S.tiles[r][i] && S.tiles[r][i].t === t.t; i--) n++;
  for(let i = c + 1; i < W && S.tiles[r][i] && S.tiles[r][i].t === t.t; i++) n++;
  if(n >= 3) return true;
  n = 1;
  for(let i = r - 1; i >= 0 && S.tiles[i][c] && S.tiles[i][c].t === t.t; i--) n++;
  for(let i = r + 1; i < H && S.tiles[i][c] && S.tiles[i][c].t === t.t; i++) n++;
  return n >= 3;
}

function swapCells(S, a, b){
  const t = S.tiles[a[0]][a[1]]; S.tiles[a[0]][a[1]] = S.tiles[b[0]][b[1]]; S.tiles[b[0]][b[1]] = t;
}

// كل الحركات الممكنة
function allMoves(S){
  const out = [];
  for(let r = 0; r < H; r++) for(let c = 0; c < W; c++){
    const A = tileAt(S, r, c); if(!A) continue;
    for(const [dr, dc] of [[0, 1], [1, 0]]){
      const r2 = r + dr, c2 = c + dc, B = tileAt(S, r2, c2); if(!B) continue;
      let ok = false;
      if(A.sp === 'c' || B.sp === 'c' || (A.sp && B.sp)) ok = true;
      else { swapCells(S, [r, c], [r2, c2]); ok = lineAt(S, r, c) || lineAt(S, r2, c2); swapCells(S, [r, c], [r2, c2]); }
      if(ok) out.push([[r, c], [r2, c2]]);
    }
  }
  return out;
}
function findMove(S){
  for(let r = 0; r < H; r++) for(let c = 0; c < W; c++){
    const A = tileAt(S, r, c); if(!A) continue;
    for(const [dr, dc] of [[0, 1], [1, 0]]){
      const r2 = r + dr, c2 = c + dc, B = tileAt(S, r2, c2); if(!B) continue;
      if(A.sp === 'c' || B.sp === 'c' || (A.sp && B.sp)) return [[r, c], [r2, c2]];
      swapCells(S, [r, c], [r2, c2]); const ok = lineAt(S, r, c) || lineAt(S, r2, c2); swapCells(S, [r, c], [r2, c2]);
      if(ok) return [[r, c], [r2, c2]];
    }
  }
  return null;
}

// ---------- التفجير ----------
function mostCommonType(S){
  const n = new Array(S.ntypes).fill(0);
  for(let r = 0; r < H; r++) for(let c = 0; c < W; c++){ const t = S.tiles[r][c]; if(t && t.t >= 0) n[t.t]++; }
  let best = 0; for(let i = 1; i < n.length; i++) if(n[i] > n[best]) best = i;
  return best;
}
function areaOf(S, r, c, sp, colorT){
  const out = [];
  if(sp === 'h'){ for(let i = 0; i < W; i++) if(inside(S, r, i)) out.push(key(r, i)); }
  else if(sp === 'v'){ for(let i = 0; i < H; i++) if(inside(S, i, c)) out.push(key(i, c)); }
  else if(sp === 'b'){ for(let i = -1; i <= 1; i++) for(let j = -1; j <= 1; j++) if(inside(S, r + i, c + j)) out.push(key(r + i, c + j)); }
  else if(sp === 'c'){
    const t = colorT == null ? mostCommonType(S) : colorT;
    for(let i = 0; i < H; i++) for(let j = 0; j < W; j++){ const x = S.tiles[i][j]; if(x && x.t === t) out.push(key(i, j)); }
    out.push(key(r, c));
  }
  return out;
}

// كيمسح مجموعة خانات، وكيفجر الخاصين لي فيها (سلسلة)، ومن بعد كيحط الخاصين الجداد
function blast(S, keys, creations, fired){
  const clear = new Set(keys);
  fired = fired || new Set();
  const explosions = [];
  const queue = [...clear];
  while(queue.length){
    const k = queue.shift();
    const [r, c] = rc(k), t = S.tiles[r][c];
    if(!t || !t.sp || fired.has(t.id)) continue;
    fired.add(t.id);
    explosions.push({ r, c, sp: t.sp });
    for(const k2 of areaOf(S, r, c, t.sp)) if(!clear.has(k2)){ clear.add(k2); queue.push(k2); }
  }
  const cleared = [], sandCleared = [];
  for(const k of clear){
    const [r, c] = rc(k), t = S.tiles[r][c];
    if(!t) continue;
    if(t.t >= 0) S.collected[t.t]++;
    cleared.push({ id: t.id, r, c, t: t.t, sp: t.sp });
    S.tiles[r][c] = null;
    if(S.sand[r][c]){ S.sand[r][c] = 0; S.sandLeft--; sandCleared.push(k); }
  }
  const created = [];
  for(const cr of creations || []){
    const [r, c] = rc(cr.key);
    if(S.tiles[r][c]) continue;
    const nt = newTile(S, cr.t, cr.sp); S.tiles[r][c] = nt;
    created.push({ id: nt.id, r, c, t: nt.t, sp: nt.sp });
  }
  const points = Math.round(cleared.length * 60 * (1 + 0.5 * S.combo) + created.length * 120);
  S.score += points;
  return { type: 'clear', cleared, created, explosions, sandCleared, points, combo: S.combo };
}

// كيلقى المطابقات، كيقرر شنو الخاصين لي يتخلقو، وكيمسح
function resolve(S, prefer){
  const runs = findRuns(S);
  if(!runs.length) return null;
  // كنجمعو المطابقات لي كيتقاطعو (L و T)
  const parent = runs.map((_, i) => i);
  const find = i => parent[i] === i ? i : (parent[i] = find(parent[i]));
  const owner = new Map();
  runs.forEach((run, i) => run.cells.forEach(k => { if(owner.has(k)) parent[find(i)] = find(owner.get(k)); else owner.set(k, i); }));
  const groups = new Map();
  runs.forEach((run, i) => { const g = find(i); if(!groups.has(g)) groups.set(g, []); groups.get(g).push(run); });
  const keys = new Set(), creations = [];
  for(const grp of groups.values()){
    const cells = new Set(); grp.forEach(run => run.cells.forEach(k => cells.add(k)));
    cells.forEach(k => keys.add(k));
    const longest = grp.reduce((a, b) => b.cells.length > a.cells.length ? b : a);
    const hasH = grp.some(x => x.dir === 'h'), hasV = grp.some(x => x.dir === 'v');
    let sp = '';
    if(longest.cells.length >= 5) sp = 'c';
    else if(hasH && hasV) sp = 'b';
    else if(longest.cells.length === 4) sp = longest.dir === 'h' ? 'v' : 'h';
    if(!sp) continue;
    let pos = null;
    if(prefer) for(const p of prefer) if(cells.has(p)){ pos = p; break; }
    if(pos == null && sp === 'b'){
      const hs = new Set(); grp.filter(x => x.dir === 'h').forEach(x => x.cells.forEach(k => hs.add(k)));
      for(const x of grp) if(x.dir === 'v') for(const k of x.cells) if(hs.has(k)){ pos = k; break; }
    }
    if(pos == null) pos = longest.cells[Math.floor(longest.cells.length / 2)];
    creations.push({ key: pos, t: sp === 'c' ? -1 : longest.t, sp });
  }
  return blast(S, [...keys], creations);
}

// الطيحان والتعبئة
function gravity(S){
  const moves = [], spawns = [];
  for(let c = 0; c < W; c++){
    const cells = [];
    for(let r = 0; r < H; r++) if(S.mask[r][c]) cells.push(r);
    if(!cells.length) continue;
    let w = cells.length - 1;
    for(let i = cells.length - 1; i >= 0; i--){
      const t = S.tiles[cells[i]][c];
      if(!t) continue;
      if(i !== w){ S.tiles[cells[w]][c] = t; S.tiles[cells[i]][c] = null; moves.push({ id: t.id, c, from: cells[i], to: cells[w] }); }
      w--;
    }
    for(let j = 0; w >= 0; w--, j++){
      const nt = newTile(S, randInt(S, S.ntypes));
      S.tiles[cells[w]][c] = nt;
      spawns.push({ id: nt.id, t: nt.t, sp: '', c, from: cells[0] - 1 - j, to: cells[w] });
    }
  }
  return { type: 'fall', moves, spawns };
}

function cascade(S, prefer, events){
  for(;;){
    const ev = resolve(S, prefer);
    if(!ev) break;
    events.push(ev, gravity(S));
    S.combo++; prefer = null;
  }
}

function shuffle(S){
  const pos = [], tl = [];
  for(let r = 0; r < H; r++) for(let c = 0; c < W; c++){ const t = tileAt(S, r, c); if(t && !t.sp){ pos.push([r, c]); tl.push(t); } }
  for(let tries = 0; tries < 200; tries++){
    for(let i = tl.length - 1; i > 0; i--){ const j = randInt(S, i + 1); [tl[i], tl[j]] = [tl[j], tl[i]]; }
    pos.forEach(([r, c], i) => { S.tiles[r][c] = tl[i]; });
    if(tries > 100) tl.forEach(t => { t.t = randInt(S, S.ntypes); });
    if(!findRuns(S).length && findMove(S)) break;
  }
  return { type: 'shuffle', moves: pos.map(([r, c]) => ({ id: S.tiles[r][c].id, r, c, t: S.tiles[r][c].t })) };
}

function finishTurn(S, events){
  if(!findMove(S)) events.push(shuffle(S));
}

// ---------- أفعال اللاعب ----------
function swap(S, a, b){
  if(Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) !== 1) return null;
  const A = tileAt(S, a[0], a[1]), B = tileAt(S, b[0], b[1]);
  if(!A || !B || S.moves <= 0) return null;
  const events = [{ type: 'swap', a, b, ida: A.id, idb: B.id }];
  swapCells(S, a, b);
  S.combo = 0;
  const special = A.sp === 'c' || B.sp === 'c' || (A.sp && B.sp);
  if(!special){
    if(!lineAt(S, a[0], a[1]) && !lineAt(S, b[0], b[1])){ swapCells(S, a, b); return { valid: false, events }; }
    S.moves--;
    cascade(S, [key(b[0], b[1]), key(a[0], a[1])], events);
    finishTurn(S, events);
    return { valid: true, events };
  }
  S.moves--;
  // A دابا فـ b و B فـ a
  const kb = key(b[0], b[1]), ka = key(a[0], a[1]);
  const fired = new Set([A.id, B.id]);
  let keys = [kb, ka];
  if(A.sp === 'c' && B.sp === 'c'){
    for(let r = 0; r < H; r++) for(let c = 0; c < W; c++) if(tileAt(S, r, c)) keys.push(key(r, c));
  } else if(A.sp === 'c' || B.sp === 'c'){
    const C = A.sp === 'c' ? A : B, O = C === A ? B : A;
    if(!O.sp){
      for(let r = 0; r < H; r++) for(let c = 0; c < W; c++){ const t = tileAt(S, r, c); if(t && t.t === O.t) keys.push(key(r, c)); }
    } else {
      const conv = [];
      for(let r = 0; r < H; r++) for(let c = 0; c < W; c++){
        const t = tileAt(S, r, c);
        if(t && t.t === O.t && !t.sp){ t.sp = O.sp === 'b' ? 'b' : (rand(S) < .5 ? 'h' : 'v'); conv.push({ id: t.id, sp: t.sp }); keys.push(key(r, c)); }
      }
      fired.delete(O.id);
      events.push({ type: 'convert', list: conv });
    }
  } else {
    const [r, c] = b, sps = [A.sp, B.sp];
    const striped = s => s === 'h' || s === 'v';
    if(striped(sps[0]) && striped(sps[1])){ keys.push(...areaOf(S, r, c, 'h'), ...areaOf(S, r, c, 'v')); }
    else if(sps.includes('b') && (striped(sps[0]) || striped(sps[1]))){
      for(let d = -1; d <= 1; d++){ for(let i = 0; i < W; i++) if(inside(S, r + d, i)) keys.push(key(r + d, i)); for(let i = 0; i < H; i++) if(inside(S, i, c + d)) keys.push(key(i, c + d)); }
    } else {
      for(let i = -2; i <= 2; i++) for(let j = -2; j <= 2; j++) if(inside(S, r + i, c + j)) keys.push(key(r + i, c + j));
    }
  }
  const ev = blast(S, [...new Set(keys)], [], fired);
  ev.combo = 0; ev.big = true;
  events.push(ev, gravity(S));
  S.combo = 1;
  cascade(S, null, events);
  finishTurn(S, events);
  return { valid: true, events };
}

// المطرقة: كتكسر خانة وحدة
function hammer(S, r, c){
  if(!tileAt(S, r, c)) return null;
  S.combo = 0;
  const events = [blast(S, [key(r, c)], [])];
  events.push(gravity(S));
  S.combo = 1;
  cascade(S, null, events);
  finishTurn(S, events);
  return { valid: true, events };
}

// ---------- الأهداف ----------
function goalsLeft(S, L){
  return L.goals.map(g => {
    if(g.k === 't') return Math.max(0, g.n - S.collected[g.t]);
    if(g.k === 'sand') return Math.max(0, S.sandLeft);
    if(g.k === 'score') return Math.max(0, g.n - S.score);
    return 0;
  });
}
function isWon(S, L){ return goalsLeft(S, L).every(x => x === 0); }
function isLost(S, L){ return S.moves <= 0 && !isWon(S, L); }
function stars(score, L){ return score >= L.s3 ? 3 : score >= L.s2 ? 2 : 1; }

// ---------- البداية ----------
function create(L, seed){
  const S = {
    mask: L.mask.map(row => [...row].map(ch => ch !== '.')),
    tiles: [], sand: [], ntypes: L.ntypes, rs: seed | 0, nextId: 1,
    score: 0, moves: L.moves, collected: new Array(6).fill(0), sandLeft: 0, combo: 0,
  };
  for(let r = 0; r < H; r++){
    S.tiles.push(new Array(W).fill(null));
    S.sand.push(new Array(W).fill(0));
    for(let c = 0; c < W; c++) if(S.mask[r][c] && L.sand && L.sand[r] && L.sand[r][c] === 's'){ S.sand[r][c] = 1; S.sandLeft++; }
  }
  for(let tries = 0; tries < 100; tries++){
    for(let r = 0; r < H; r++) for(let c = 0; c < W; c++){
      if(!S.mask[r][c]){ S.tiles[r][c] = null; continue; }
      let t, k = 0;
      do { t = randInt(S, S.ntypes); k++; }
      while(k < 30 && ((c >= 2 && S.tiles[r][c-1] && S.tiles[r][c-2] && S.tiles[r][c-1].t === t && S.tiles[r][c-2].t === t) ||
                       (r >= 2 && S.tiles[r-1][c] && S.tiles[r-2][c] && S.tiles[r-1][c].t === t && S.tiles[r-2][c].t === t)));
      S.tiles[r][c] = newTile(S, t);
    }
    if(!findRuns(S).length && findMove(S)) break;
  }
  return S;
}

function clone(S){
  return {
    mask: S.mask, ntypes: S.ntypes, rs: S.rs, nextId: S.nextId, score: S.score, moves: S.moves,
    collected: S.collected.slice(), sandLeft: S.sandLeft, combo: S.combo,
    tiles: S.tiles.map(row => row.map(t => t ? { id: t.id, t: t.t, sp: t.sp } : null)),
    sand: S.sand.map(row => row.slice()),
  };
}

const api = { W, H, create, clone, swap, hammer, allMoves, findMove, findRuns, goalsLeft, isWon, isLost, stars, shuffle, finishTurn, key, rc, rand };
if(typeof module !== 'undefined' && module.exports) module.exports = api;
else root.Engine = api;
})(typeof window !== 'undefined' ? window : globalThis);
