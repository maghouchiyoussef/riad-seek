// Desert Dash — hand-drawn sprites (original art) + runner renderer
(function(){
'use strict';
function mk(w, h, draw){
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const x = c.getContext('2d'); draw(x, w, h); return c;
}
function rr(x, a, b, w, h, r){ x.beginPath(); x.moveTo(a + r, b); x.arcTo(a + w, b, a + w, b + h, r); x.arcTo(a + w, b + h, a, b + h, r); x.arcTo(a, b + h, a, b, r); x.arcTo(a, b, a + w, b, r); x.closePath(); }
function lg(x, x0, y0, x1, y1, stops){ const g = x.createLinearGradient(x0, y0, x1, y1); stops.forEach((s, i) => g.addColorStop(s[0], s[1])); return g; }
function ell(x, cx, cy, rx, ry, fill){ x.fillStyle = fill; x.beginPath(); x.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2); x.fill(); }

/* ---------- camel (front view, facing the runner) : 2.2u wide x 2.6u tall ---------- */
const camel = mk(220, 260, (x) => {
  const fur = '#c98f52', fur2 = '#a8703a', fur3 = '#e2b07a';
  ell(x, 110, 254, 80, 7, 'rgba(0,0,0,.18)');
  // back legs
  x.fillStyle = fur2; rr(x, 56, 168, 22, 86, 10); x.fill(); rr(x, 142, 168, 22, 86, 10); x.fill();
  // body seen from the front (wide) with hump + blanket on top
  ell(x, 110, 140, 74, 36, fur2);
  ell(x, 110, 104, 50, 34, fur);
  x.save(); x.beginPath(); x.ellipse(110, 104, 50, 34, 0, Math.PI, 0); x.clip();
  x.fillStyle = '#b3202f'; x.fillRect(56, 70, 108, 40);
  x.fillStyle = '#1b1b1b'; x.fillRect(56, 88, 108, 8);
  x.fillStyle = '#f4e3c1'; for(let i = 0; i < 8; i++){ x.beginPath(); x.moveTo(60 + i * 14, 92); x.lineTo(66 + i * 14, 88); x.lineTo(72 + i * 14, 92); x.lineTo(66 + i * 14, 96); x.closePath(); x.fill(); }
  x.fillStyle = '#ffd23f'; x.fillRect(56, 100, 108, 4);
  x.restore();
  // front legs
  x.fillStyle = fur; rr(x, 80, 150, 22, 104, 11); x.fill(); rr(x, 118, 150, 22, 104, 11); x.fill();
  ell(x, 91, 208, 13, 8, fur2); ell(x, 129, 208, 13, 8, fur2);
  x.fillStyle = '#5a3a1e'; rr(x, 78, 244, 26, 11, 5); x.fill(); rr(x, 116, 244, 26, 11, 5); x.fill();
  // chest
  ell(x, 110, 152, 40, 26, fur);
  ell(x, 110, 156, 24, 16, fur3);
  // neck
  x.fillStyle = fur; x.beginPath(); x.moveTo(94, 150); x.quadraticCurveTo(88, 92, 97, 54); x.lineTo(123, 54); x.quadraticCurveTo(132, 92, 126, 150); x.closePath(); x.fill();
  x.fillStyle = fur3; x.beginPath(); x.moveTo(104, 146); x.quadraticCurveTo(100, 98, 106, 62); x.lineTo(114, 62); x.quadraticCurveTo(120, 98, 116, 146); x.closePath(); x.fill();
  // decorated neck band with tassels
  x.fillStyle = '#b3202f'; rr(x, 90, 112, 40, 12, 4); x.fill();
  x.fillStyle = '#ffd23f'; for(let i = 0; i < 4; i++){ x.beginPath(); x.arc(96 + i * 9.5, 118, 2.5, 0, 7); x.fill(); }
  const tc = ['#ffd23f', '#2f7fd1', '#1e9a52', '#ff8a1c', '#ffd23f'];
  for(let i = 0; i < 5; i++){ x.fillStyle = tc[i]; x.beginPath(); x.moveTo(92 + i * 9, 124); x.lineTo(98 + i * 9, 124); x.lineTo(95 + i * 9, 138); x.closePath(); x.fill(); }
  // head
  ell(x, 110, 40, 26, 24, fur);
  ell(x, 110, 58, 18, 14, fur3);
  ell(x, 85, 28, 8, 5, fur2); ell(x, 135, 28, 8, 5, fur2);
  ell(x, 99, 37, 6, 7, '#fff'); ell(x, 121, 37, 6, 7, '#fff');
  ell(x, 100, 38, 3.6, 4.4, '#2a1a0e'); ell(x, 122, 38, 3.6, 4.4, '#2a1a0e');
  ell(x, 101, 36, 1.3, 1.5, '#fff'); ell(x, 123, 36, 1.3, 1.5, '#fff');
  x.strokeStyle = '#7a5230'; x.lineWidth = 2.2; x.lineCap = 'round';
  x.beginPath(); x.moveTo(92, 27); x.quadraticCurveTo(99, 25, 105, 28); x.moveTo(128, 27); x.quadraticCurveTo(121, 25, 115, 28); x.stroke();
  ell(x, 104, 58, 2.4, 1.6, '#6b4423'); ell(x, 116, 58, 2.4, 1.6, '#6b4423');
  x.strokeStyle = '#6b4423'; x.beginPath(); x.arc(110, 61, 6, 0.25, Math.PI - 0.25); x.stroke();
  x.strokeStyle = '#d0263a'; x.lineWidth = 3; x.beginPath(); x.ellipse(110, 50, 21, 8, 0, 0.1, Math.PI - 0.1); x.stroke();
});

/* resting camel (side view) for scenery : 3.4u x 1.8u */
const camelRest = mk(340, 180, (x) => {
  const fur = '#c98f52', fur2 = '#a8703a';
  ell(x, 170, 150, 120, 26, 'rgba(0,0,0,.15)');
  x.fillStyle = fur2; rr(x, 70, 120, 200, 34, 16); x.fill();
  ell(x, 165, 110, 92, 42, fur);
  ell(x, 160, 74, 42, 34, fur);
  x.fillStyle = '#b3202f'; rr(x, 115, 82, 96, 40, 10); x.fill();
  x.fillStyle = '#ffd23f'; x.fillRect(115, 98, 96, 6);
  x.fillStyle = '#1b1b1b'; x.fillRect(115, 106, 96, 5);
  x.fillStyle = fur; x.beginPath(); x.moveTo(240, 110); x.quadraticCurveTo(275, 80, 268, 40); x.lineTo(292, 36); x.quadraticCurveTo(300, 90, 258, 128); x.closePath(); x.fill();
  ell(x, 296, 40, 30, 17, fur);
  ell(x, 286, 34, 4, 4, '#2a1a0e');
  ell(x, 274, 26, 7, 4, fur2);
  x.strokeStyle = fur2; x.lineWidth = 6; x.lineCap = 'round'; x.beginPath(); x.moveTo(76, 112); x.quadraticCurveTo(58, 120, 62, 140); x.stroke();
});

/* palm tree : 3u x 5u */
const palm = mk(240, 400, (x) => {
  // trunk
  for(let i = 0; i < 14; i++){
    const y = 390 - i * 24, w = 26 - i * 0.6, off = Math.sin(i * 0.25) * 6;
    x.fillStyle = i % 2 ? '#8a5a2b' : '#a06a34';
    x.beginPath(); x.moveTo(120 - w / 2 + off, y); x.lineTo(120 + w / 2 + off, y); x.lineTo(120 + w / 2 - 2 + off, y - 26); x.lineTo(120 - w / 2 + 2 + off, y - 26); x.closePath(); x.fill();
  }
  // dates
  ['#b5651d', '#d9822b', '#c26a1e'].forEach((c, i) => { ell(x, 108 + i * 12, 82 + (i % 2) * 6, 7, 9, c); ell(x, 114 + i * 10, 92, 6, 8, c); });
  // fronds
  const fr = (ang, len, col) => {
    x.save(); x.translate(124, 66); x.rotate(ang);
    x.fillStyle = col; x.beginPath(); x.moveTo(0, 0);
    x.quadraticCurveTo(len * 0.5, -len * 0.35, len, len * 0.15);
    x.quadraticCurveTo(len * 0.5, -len * 0.08, 0, 6); x.closePath(); x.fill();
    x.strokeStyle = 'rgba(0,60,0,.35)'; x.lineWidth = 2;
    for(let k = 0.15; k < 0.95; k += 0.1){ x.beginPath(); x.moveTo(len * k, -len * 0.22 * Math.sin(k * 3.1)); x.lineTo(len * k + 8, len * 0.05 + 10); x.stroke(); }
    x.restore();
  };
  const angs = [-3.0, -2.5, -2.0, -1.2, -0.6, -0.1, 0.4];
  angs.forEach((a, i) => fr(a, 110 + (i % 2) * 12, i % 2 ? '#2e8b3e' : '#3fa84f'));
  ell(x, 124, 66, 14, 12, '#2e7a36');
});

/* bedouin tent : 4u x 2.6u */
const tent = mk(320, 210, (x) => {
  ell(x, 160, 200, 150, 10, 'rgba(0,0,0,.15)');
  x.fillStyle = '#3a2a22'; x.beginPath(); x.moveTo(10, 200); x.lineTo(40, 70); x.lineTo(110, 40); x.lineTo(160, 60); x.lineTo(210, 40); x.lineTo(280, 70); x.lineTo(310, 200); x.closePath(); x.fill();
  x.save(); x.clip();
  for(let i = 0; i < 9; i++){ x.fillStyle = i % 2 ? '#5a4232' : '#2b1d16'; x.fillRect(0, 40 + i * 20, 320, 10); }
  x.fillStyle = '#b3202f'; x.fillRect(0, 150, 320, 12);
  x.fillStyle = '#f4e3c1'; for(let i = 0; i < 16; i++){ x.beginPath(); x.moveTo(i * 20, 156); x.lineTo(i * 20 + 6, 150); x.lineTo(i * 20 + 12, 156); x.lineTo(i * 20 + 6, 162); x.fill(); }
  x.restore();
  x.fillStyle = '#1a120d'; x.beginPath(); x.moveTo(130, 200); x.lineTo(160, 110); x.lineTo(190, 200); x.closePath(); x.fill();
  x.fillStyle = '#ffb000'; ell(x, 160, 185, 10, 6, '#ffb000');
  x.strokeStyle = '#6b4a2e'; x.lineWidth = 4; [[40, 70, 5, 205], [280, 70, 315, 205]].forEach(([a, b, c, d]) => { x.beginPath(); x.moveTo(a, b); x.lineTo(c, d); x.stroke(); });
});

/* market cart (front view) : 2.2u x 2.3u */
const cart = mk(220, 230, (x) => {
  ell(x, 110, 222, 100, 8, 'rgba(0,0,0,.18)');
  // awning poles
  x.fillStyle = '#6b4a2e'; x.fillRect(22, 30, 8, 150); x.fillRect(190, 30, 8, 150);
  // awning
  for(let i = 0; i < 8; i++){ x.fillStyle = i % 2 ? '#fff4e0' : '#1e9a52'; x.beginPath(); x.moveTo(10 + i * 25, 30); x.lineTo(35 + i * 25, 30); x.lineTo(35 + i * 25, 52); x.quadraticCurveTo(22 + i * 25, 62, 10 + i * 25, 52); x.closePath(); x.fill(); }
  x.fillStyle = '#145f33'; x.fillRect(8, 22, 204, 10);
  // body
  x.fillStyle = lg(x, 0, 120, 0, 200, [[0, '#b07a45'], [1, '#7a4f26']]); rr(x, 14, 120, 192, 70, 8); x.fill();
  x.strokeStyle = 'rgba(0,0,0,.25)'; x.lineWidth = 2; for(let i = 1; i < 4; i++){ x.beginPath(); x.moveTo(14, 120 + i * 17); x.lineTo(206, 120 + i * 17); x.stroke(); }
  // produce piles
  const pile = (cx, col, hi) => { for(let r = 0; r < 3; r++) for(let k = 0; k <= 2 - r; k++){ const px = cx - (2 - r) * 9 + k * 18, py = 116 - r * 14; ell(x, px, py, 10, 9, col); ell(x, px - 3, py - 3, 3, 2.5, hi); } };
  pile(52, '#ff8a1c', '#ffd1a0'); pile(110, '#e63946', '#ffb3b8'); pile(168, '#ffd23f', '#fff3b0');
  // wheels
  ell(x, 48, 196, 24, 24, '#3a2614'); ell(x, 48, 196, 14, 14, '#8a5a2b'); ell(x, 48, 196, 5, 5, '#3a2614');
  ell(x, 172, 196, 24, 24, '#3a2614'); ell(x, 172, 196, 14, 14, '#8a5a2b'); ell(x, 172, 196, 5, 5, '#3a2614');
});

/* car (rear view) : 2.2u x 1.8u, per color */
const carCache = {};
function car(col){
  if(carCache[col]) return carCache[col];
  return carCache[col] = mk(220, 180, (x) => {
    ell(x, 110, 172, 104, 9, 'rgba(0,0,0,.22)');
    // wheels
    x.fillStyle = '#151515'; rr(x, 16, 128, 34, 46, 8); x.fill(); rr(x, 170, 128, 34, 46, 8); x.fill();
    // body
    x.fillStyle = lg(x, 0, 70, 0, 160, [[0, col], [1, shadeHex(col, .7)]]); rr(x, 8, 82, 204, 80, 22); x.fill();
    // cabin
    x.fillStyle = shadeHex(col, .9); x.beginPath(); x.moveTo(40, 86); x.lineTo(62, 26); x.quadraticCurveTo(110, 16, 158, 26); x.lineTo(180, 86); x.closePath(); x.fill();
    // rear window
    x.fillStyle = lg(x, 0, 30, 0, 80, [[0, '#9fd0ff'], [1, '#2c4a85']]); x.beginPath(); x.moveTo(54, 80); x.lineTo(70, 36); x.quadraticCurveTo(110, 28, 150, 36); x.lineTo(166, 80); x.closePath(); x.fill();
    x.fillStyle = 'rgba(255,255,255,.35)'; x.beginPath(); x.moveTo(76, 40); x.lineTo(96, 38); x.lineTo(82, 76); x.lineTo(62, 76); x.closePath(); x.fill();
    // lights
    x.fillStyle = '#ff3b3b'; rr(x, 16, 100, 40, 18, 6); x.fill(); rr(x, 164, 100, 40, 18, 6); x.fill();
    x.fillStyle = '#ffb3b3'; rr(x, 20, 103, 14, 8, 3); x.fill(); rr(x, 186, 103, 14, 8, 3); x.fill();
    // plate + bumper
    x.fillStyle = '#2a2a2a'; rr(x, 12, 140, 196, 16, 8); x.fill();
    x.fillStyle = '#f5f5f5'; rr(x, 82, 118, 56, 18, 3); x.fill();
    x.fillStyle = '#1b1b1b'; x.font = 'bold 12px Arial'; x.textAlign = 'center'; x.fillText('DD 777', 110, 132);
  });
}
function shadeHex(hex, k){
  const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
  r = Math.max(0, Math.min(255, r * k)) | 0; g = Math.max(0, Math.min(255, g * k)) | 0; b = Math.max(0, Math.min(255, b * k)) | 0;
  return '#' + ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1);
}

/* birds: falcon (desert) and seagull (port), 2 frames */
function bird(kind, up){
  return mk(120, 70, (x) => {
    const body = kind === 'falcon' ? '#7a5230' : '#ffffff', wing = kind === 'falcon' ? '#5a3a1e' : '#d9dde3', tip = kind === 'falcon' ? '#2a1a0e' : '#3a3f4a';
    x.fillStyle = wing; x.beginPath();
    if(up){ x.moveTo(60, 38); x.quadraticCurveTo(30, 0, 4, 10); x.quadraticCurveTo(30, 20, 52, 44); x.moveTo(60, 38); x.quadraticCurveTo(90, 0, 116, 10); x.quadraticCurveTo(90, 20, 68, 44); }
    else { x.moveTo(60, 38); x.quadraticCurveTo(30, 50, 4, 60); x.quadraticCurveTo(32, 36, 52, 34); x.moveTo(60, 38); x.quadraticCurveTo(90, 50, 116, 60); x.quadraticCurveTo(88, 36, 68, 34); }
    x.fill();
    x.fillStyle = tip; x.beginPath(); x.arc(up ? 8 : 8, up ? 11 : 58, 5, 0, 7); x.arc(up ? 112 : 112, up ? 11 : 58, 5, 0, 7); x.fill();
    ell(x, 60, 40, 10, 16, body);
    ell(x, 60, 24, 8, 8, body);
    x.fillStyle = kind === 'falcon' ? '#ffd23f' : '#ff9a1c'; x.beginPath(); x.moveTo(57, 18); x.lineTo(63, 18); x.lineTo(60, 12); x.fill();
  });
}
const birds = { falcon: [bird('falcon', true), bird('falcon', false)], gull: [bird('gull', true), bird('gull', false)] };

/* ---------- runner (seen from behind) ---------- */
function shade(hex, k){ return shadeHex(hex, k); }
function drawRunner(c, cx, cy, sc, ph, mode, gender, O){
  const girl = gender === 'girl';
  const robe = girl ? O.g.robe : O.robe, robe2 = girl ? O.g.robe2 : O.robe2;
  const skin = '#c98b5e';
  c.save(); c.translate(cx, cy);
  const slide = mode === 'slide', jump = mode === 'jump', idle = mode === 'idle';
  const s = Math.sin(ph), bob = mode === 'run' ? Math.abs(Math.cos(ph)) * 0.07 : 0;
  c.scale(sc, sc * (slide ? 0.62 : 1));
  // ground shadow
  c.fillStyle = 'rgba(0,0,0,.22)'; c.beginPath(); c.ellipse(0, 0, 0.55, 0.13, 0, 0, 7); c.fill();
  c.translate(0, -bob);
  if(slide) c.rotate(0);
  // ---- legs & shoes ----
  const shoe = girl ? O.g.trim : '#f5f5f5', sole = '#3a3a3a';
  const legs = [-1, 1].map(side => {
    const lift = jump ? (side < 0 ? 0.32 : 0.18) : idle ? 0 : Math.max(0, side < 0 ? s : -s) * 0.3;
    return { side, lift };
  });
  for(const L of legs){
    const lx = L.side * 0.16, top = -0.62, foot = -L.lift;
    c.fillStyle = girl ? '#2b2433' : '#ece6d8';
    c.beginPath(); c.moveTo(lx - 0.1, top); c.lineTo(lx + 0.1, top); c.lineTo(lx + 0.085, foot - 0.08); c.lineTo(lx - 0.085, foot - 0.08); c.closePath(); c.fill();
    // shoe (heel seen from behind, sole visible when lifted)
    c.fillStyle = shoe; c.beginPath(); c.ellipse(lx, foot - 0.05, 0.11, 0.075, 0, 0, 7); c.fill();
    if(L.lift > 0.05){ c.fillStyle = sole; c.beginPath(); c.ellipse(lx, foot - 0.02, 0.1, 0.04 + L.lift * 0.08, 0, 0, 7); c.fill(); }
  }
  // ---- arms (behind body edges) ----
  const armSw = jump || idle ? 0 : s;
  const arm = (side) => {
    c.save(); c.translate(side * 0.45, -1.44);
    const rot = jump ? -side * 2.4 : slide ? -side * 1.1 : -side * 0.16;
    const len = jump || slide ? 0.58 : 0.5 + (side < 0 ? -armSw : armSw) * 0.08;
    c.rotate(rot);
    c.fillStyle = lg(c, -0.1, 0, 0.1, 0, [[0, robe2], [1, robe]]);
    c.beginPath(); c.moveTo(-0.1, 0); c.lineTo(0.1, 0); c.lineTo(0.12, len); c.lineTo(-0.12, len); c.closePath(); c.fill();
    if(girl){ c.fillStyle = O.g.trim; c.fillRect(-0.12, len - 0.06, 0.24, 0.05); }
    c.fillStyle = skin; c.beginPath(); c.arc(0, len + 0.06, 0.075, 0, 7); c.fill();
    c.restore();
  };
  // ---- robe ----
  const hem = -0.36 - (girl ? 0.02 : 0), sway = idle ? 0 : s * 0.05;
  c.fillStyle = lg(c, -0.5, 0, 0.5, 0, [[0, robe2], [0.35, robe], [0.65, robe], [1, robe2]]);
  c.beginPath();
  c.moveTo(-0.44, -1.4); c.quadraticCurveTo(-0.42, -1.56, -0.2, -1.6); c.lineTo(0.2, -1.6); c.quadraticCurveTo(0.42, -1.56, 0.44, -1.4);
  c.lineTo(0.52 + sway, hem); c.quadraticCurveTo(0.26, hem + 0.05, 0, hem - 0.01); c.quadraticCurveTo(-0.26, hem + 0.05, -0.52 + sway, hem); c.closePath(); c.fill();
  // folds
  c.strokeStyle = 'rgba(0,0,0,.12)'; c.lineWidth = 0.03;
  c.beginPath(); c.moveTo(-0.18, -1.2); c.quadraticCurveTo(-0.22 + sway, -0.8, -0.28 + sway, hem + 0.02); c.stroke();
  c.beginPath(); c.moveTo(0.16, -1.2); c.quadraticCurveTo(0.2 + sway, -0.8, 0.26 + sway, hem + 0.02); c.stroke();
  if(girl){
    // abaya trim + embroidery dots
    c.fillStyle = O.g.trim; c.fillRect(-0.53 + sway, hem - 0.07, 1.06, 0.06);
    for(let i = -4; i <= 4; i++){ c.beginPath(); c.arc(i * 0.11 + sway, hem - 0.13, 0.018, 0, 7); c.fill(); }
  } else {
    c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = 0.03; c.beginPath(); c.moveTo(-0.5 + sway, hem - 0.04); c.lineTo(0.5 + sway, hem - 0.04); c.stroke();
  }
  arm(-1); arm(1);
  // ---- head ----
  if(girl){
    const hc = O.g.head;
    c.fillStyle = shade(hc, .82);
    c.beginPath(); c.moveTo(-0.29, -1.72); c.quadraticCurveTo(-0.44 - sway, -1.3, -0.32 - sway * 2, -0.98);
    c.quadraticCurveTo(0, -0.9, 0.32 - sway * 2, -0.98); c.quadraticCurveTo(0.44 - sway, -1.3, 0.29, -1.72); c.closePath(); c.fill();
    c.fillStyle = lg(c, -0.3, -2.1, 0.3, -1.5, [[0, shade(hc, 1.18)], [1, hc]]);
    c.beginPath(); c.ellipse(0, -1.84, 0.26, 0.28, 0, 0, 7); c.fill();
    c.strokeStyle = shade(hc, .7); c.lineWidth = 0.03;
    for(const k of [-0.16, 0, 0.16]){ c.beginPath(); c.moveTo(k * 0.8, -1.62); c.quadraticCurveTo(k * 1.3 - sway, -1.3, k * 1.4 - sway * 2, -1.0); c.stroke(); }
    c.beginPath(); c.arc(0, -1.82, 0.22, 0.3, 2.8); c.stroke();
    c.fillStyle = O.g.trim; c.beginPath(); c.arc(0.2, -1.74, 0.04, 0, 7); c.fill();
  } else {
    const hc = O.head;
    // ghutra drape
    c.save();
    c.beginPath(); c.moveTo(-0.3, -1.84); c.quadraticCurveTo(-0.46, -1.42, -0.38 - sway, -1.08);
    c.lineTo(0 - sway, -0.92); c.lineTo(0.38 - sway, -1.08); c.quadraticCurveTo(0.46, -1.42, 0.3, -1.84); c.closePath();
    c.fillStyle = hc; c.fill(); c.clip();
    c.fillStyle = O.check; c.globalAlpha = 0.8;
    for(let i = -12; i <= 12; i++) for(let j = 0; j < 20; j++){ if((i + j) % 2) continue; c.fillRect(i * 0.045 - 0.012, -1.92 + j * 0.05, 0.026, 0.026); }
    c.globalAlpha = 1;
    c.fillStyle = 'rgba(0,0,0,.08)'; c.beginPath(); c.moveTo(0 - sway, -0.92); c.lineTo(-0.38 - sway, -1.08); c.lineTo(-0.2, -1.5); c.closePath(); c.fill();
    c.restore();
    // crown
    c.save(); c.beginPath(); c.ellipse(0, -1.88, 0.29, 0.25, 0, 0, 7); c.fillStyle = hc; c.fill(); c.clip();
    c.fillStyle = O.check; c.globalAlpha = 0.8;
    for(let i = -8; i <= 8; i++) for(let j = 0; j < 12; j++){ if((i + j) % 2) continue; c.fillRect(i * 0.045 - 0.012, -2.16 + j * 0.05, 0.026, 0.026); }
    c.globalAlpha = 1; c.fillStyle = 'rgba(255,255,255,.25)'; c.beginPath(); c.ellipse(-0.08, -1.98, 0.12, 0.08, -0.3, 0, 7); c.fill();
    c.restore();
    // agal + tassels
    c.strokeStyle = O.band; c.lineWidth = 0.045;
    c.beginPath(); c.ellipse(0, -1.97, 0.25, 0.07, 0, 0, 7); c.stroke();
    c.beginPath(); c.ellipse(0, -1.9, 0.27, 0.075, 0, 0, 7); c.stroke();
    c.lineWidth = 0.022; c.beginPath(); c.moveTo(0.03, -1.84); c.quadraticCurveTo(0.04 - sway, -1.72, 0.03 - sway, -1.6); c.moveTo(0.08, -1.84); c.quadraticCurveTo(0.09 - sway, -1.72, 0.085 - sway, -1.62); c.stroke();
    c.fillStyle = O.band; c.beginPath(); c.arc(0.03 - sway, -1.59, 0.025, 0, 7); c.arc(0.085 - sway, -1.61, 0.025, 0, 7); c.fill();
  }
  c.restore();
}

window.SPR = { camel, camelRest, palm, tent, cart, car, birds, drawRunner, shadeHex };
})();
