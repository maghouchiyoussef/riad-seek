// رسومات عناصر الدمج: كل درجة مركبة من رسومات Art (ستة درجات لكل سلسلة)
(function(){
'use strict';
const TAU = Math.PI * 2;
// أرقام Art: 0 لؤلؤة 1 تمرة 2 دلّة 3 عطر 4 وردة 5 زمرد 6 فنجان 7 مبخرة 8 خاتم 9 فانوس 10 نخلة 11 إسوارة 12 صدفة 13 لقيمات
const COMP = {
  c: [ [[6, 0, .02, .8]], [[6, -.2, .06, .62], [6, .2, -.04, .62]], [[2, 0, 0, .92]], [[2, -.12, -.05, .82], [6, .24, .2, .44]],
       [[2, -.16, -.12, .7], [6, .2, .08, .4], [6, -.02, .22, .38]], [[2, 0, -.16, .62], [6, -.26, .16, .38], [6, .26, .16, .38], [6, 0, .25, .36]] ],
  d: [ [[1, 0, 0, .8]], [[1, -.16, .02, .62], [1, .16, -.02, .62]], [[1, -.16, .02, .46], [1, .14, .02, .46], [1, 0, -.08, .46]], [[13, 0, 0, .9]],
       [[13, -.1, -.08, .64], [1, .22, .14, .38], [1, .02, .2, .36]], [[13, -.14, -.02, .5], [1, .2, -.06, .36], [10, .18, -.2, .4], [1, .0, .2, .34]] ],
  s: [ [[4, 0, 0, .78]], [[4, -.16, .06, .6], [4, .16, .04, .6], [4, 0, -.14, .54]], [[3, 0, 0, .9]], [[7, 0, 0, .92]],
       [[3, -.18, -.04, .62], [7, .2, -.02, .58]], [[7, -.16, -.12, .52], [3, .2, -.08, .5], [4, 0, .2, .4]] ],
  j: [ [[0, 0, 0, .74]], [[0, -.17, .04, .56], [0, .17, -.02, .56]], [[8, 0, 0, .9]], [[11, 0, 0, .95]],
       [[11, 0, .12, .62], [8, -.16, -.14, .5], [0, .22, -.14, .36]], [[5, 0, -.14, .5], [8, -.22, .12, .42], [0, .22, .14, .34], [11, 0, .22, .4]] ],
};
const PLATE = { 3: 'plate', 5: 'tray', 6: 'box' };

function plate(g, s){
  g.save(); g.fillStyle = 'rgba(80,40,10,.15)'; g.beginPath(); g.ellipse(0, s * .3, s * .4, s * .08, 0, 0, TAU); g.fill();
  g.fillStyle = '#ffffff'; g.strokeStyle = '#c9b48a'; g.lineWidth = s * .02;
  g.beginPath(); g.ellipse(0, s * .2, s * .42, s * .15, 0, 0, TAU); g.fill(); g.stroke();
  g.strokeStyle = '#2a8a7e'; g.lineWidth = s * .015; g.beginPath(); g.ellipse(0, s * .2, s * .34, s * .11, 0, 0, TAU); g.stroke();
  g.restore();
}
function tray(g, s){
  g.save();
  const gr = g.createLinearGradient(-s * .45, 0, s * .45, 0);
  gr.addColorStop(0, '#9c6a14'); gr.addColorStop(.35, '#ffe9a3'); gr.addColorStop(.6, '#f1c14b'); gr.addColorStop(1, '#a8741a');
  g.fillStyle = 'rgba(80,40,10,.18)'; g.beginPath(); g.ellipse(0, s * .32, s * .44, s * .08, 0, 0, TAU); g.fill();
  g.fillStyle = gr; g.strokeStyle = '#7a4e0c'; g.lineWidth = s * .02;
  g.beginPath(); g.ellipse(0, s * .22, s * .46, s * .16, 0, 0, TAU); g.fill(); g.stroke();
  g.strokeStyle = 'rgba(122,78,12,.5)'; g.lineWidth = s * .012; g.beginPath(); g.ellipse(0, s * .21, s * .38, s * .12, 0, 0, TAU); g.stroke();
  g.restore();
}
function box(g, s){
  g.save();
  const x = -s * .44, y = -s * .1, w = s * .88, h = s * .48;
  const gr = g.createLinearGradient(0, y, 0, y + h); gr.addColorStop(0, '#a3245a'); gr.addColorStop(1, '#5a0f30');
  g.fillStyle = 'rgba(60,10,30,.2)'; g.beginPath(); g.ellipse(0, y + h + s * .02, s * .44, s * .06, 0, 0, TAU); g.fill();
  g.fillStyle = gr; g.strokeStyle = '#3e0820'; g.lineWidth = s * .02;
  g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, s * .06) : g.rect(x, y, w, h); g.fill(); g.stroke();
  g.fillStyle = '#e8b84a'; g.fillRect(x, y + h * .18, w, s * .035); g.fillRect(-s * .03, y, s * .06, h);
  g.restore();
}
function glow(g, s, c){
  const gr = g.createRadialGradient(0, 0, s * .1, 0, 0, s * .5);
  gr.addColorStop(0, c); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.beginPath(); g.arc(0, 0, s * .5, 0, TAU); g.fill();
}
const GLOW = { c: 'rgba(255,214,120,.55)', d: 'rgba(255,190,120,.5)', s: 'rgba(220,170,255,.5)', j: 'rgba(160,230,255,.55)' };

function drawItem(g, chain, tier, s){
  const kind = PLATE[tier];
  if(tier >= 4) glow(g, s, GLOW[chain]);
  if(kind === 'plate') plate(g, s); else if(kind === 'tray') tray(g, s); else if(kind === 'box') box(g, s);
  for(const [a, x, y, k] of COMP[chain][tier - 1]){ g.save(); g.translate(x * s, y * s); Art.draw(g, a, s * k); g.restore(); }
  if(tier === 6){ Art.sparkle(g, s * .34, -s * .34, s * .07, .95); Art.sparkle(g, -s * .36, -s * .2, s * .045, .9); }
}

// المولد: صندوق خشبي فوقه أول عنصر
const GEN_ICON = { c: 6, d: 1, s: 4, j: 0 };
function drawGen(g, chain, s){
  g.save();
  g.fillStyle = 'rgba(60,30,8,.25)'; g.beginPath(); g.ellipse(0, s * .36, s * .4, s * .07, 0, 0, TAU); g.fill();
  const wood = g.createLinearGradient(0, -s * .1, 0, s * .36); wood.addColorStop(0, '#b0702e'); wood.addColorStop(1, '#6a3a12');
  g.fillStyle = wood; g.strokeStyle = '#3e1f06'; g.lineWidth = s * .022;
  g.beginPath(); g.roundRect ? g.roundRect(-s * .4, -s * .04, s * .8, s * .4, s * .05) : g.rect(-s * .4, -s * .04, s * .8, s * .4); g.fill(); g.stroke();
  g.fillStyle = '#e8b84a'; g.strokeStyle = '#8a5a10'; g.lineWidth = s * .012;
  [-.3, .26].forEach(x => { g.fillRect(x * s, -s * .04, s * .05, s * .4); });
  g.beginPath(); g.arc(0, s * .14, s * .055, 0, TAU); g.fill(); g.stroke();
  g.strokeStyle = 'rgba(62,31,6,.4)'; g.lineWidth = s * .012;
  [.06, .22].forEach(y => { g.beginPath(); g.moveTo(-s * .38, y * s); g.lineTo(s * .38, y * s); g.stroke(); });
  g.restore();
  g.save(); g.translate(0, -s * .2); Art.draw(g, GEN_ICON[chain], s * .52); g.restore();
  Art.sparkle(g, s * .32, -s * .3, s * .06, .95);
}

function image(it, px){
  const c = document.createElement('canvas'); c.width = c.height = px;
  const g = c.getContext('2d'); g.translate(px / 2, px / 2);
  if(it[0] === 'G') drawGen(g, it[1], px); else drawItem(g, it[0], +it.slice(1), px);
  return c;
}
window.Items = { drawItem, drawGen, image };
})();
